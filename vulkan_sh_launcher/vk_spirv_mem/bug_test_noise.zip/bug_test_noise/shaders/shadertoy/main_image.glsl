
void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    vec2 uv = fragCoord.xy;
    vec3 color = vec3(0.0);
    float time = 1.;
    vec2 ipos = floor(uv);
    float pct = 1.0;
    vec2 pv=mod(ipos ,vec2(1.));
    pct *= pv.y;
    if ((ipos.y > 0.0) || (ipos.x < fract(time))) {
        color = vec3(pct);
    }
    fragColor = vec4(color, 1.0);
}
