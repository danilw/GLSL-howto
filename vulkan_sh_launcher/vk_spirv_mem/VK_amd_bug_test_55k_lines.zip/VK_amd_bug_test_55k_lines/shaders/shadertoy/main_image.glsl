// self https://www.shadertoy.com/view/3sX3zN

#define SS(x, y, z) smoothstep(x, y, z)
#define res (iResolution.xy / iResolution.y)

const vec3 gc= vec3(0x38, 0x38, 0x38) / float(0xff);
const vec3 wc= vec3(0xfc, 0xfc, 0xfc) / float(0xff);
const vec3 gc2= vec3(0x47, 0x47, 0x47) / float(0xff);

float sdCircle( vec2 p, float r )
{
  return length(p) - r;
}

float pattern_bg(vec2 p){
    float d=0.;
    p=vec2(mod(p.x+0.01*(floor((mod(p.y,0.04)-0.02)/0.02)),0.02)-0.01,mod(p.y,0.02)-0.01);
    d=SS(-0.001,0.001,sdCircle(p,0.0035));
    return d;
}

vec3 gr_bg(vec2 p){
    vec3 col=mix(gc2,wc,SS(0.,0.2,abs(mod(p.x-0.2,.4)-0.2)));
    col=mix(0.2*col,wc,SS(0.,0.3,abs(mod(p.x+0.1,.6)-0.3)));
    return col;
}

float rand(vec2 co){
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

vec4 main_c_bg(vec2 p){
    vec3 col=vec3(0.);
    float d=pattern_bg(p);
    col=mix(vec3(0.),gc,d);
    float vignetteAmt = 1.-dot(p,p);
    col *= vignetteAmt;
    col += (rand(p)-.5)*.07;
    col*=SS(-0.04,0.1,abs(abs(p.y)-.3));
    col=mix(col,sqrt(gr_bg(p)*(1.-SS(-0.04,0.1,abs(abs(p.y)-.3)))),-step(0.3+0.002,abs(p.y))+step(0.3-0.002,abs(p.y)));
    return vec4(col,1.);
}


void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    vec2 uv = fragCoord/iResolution.xy;
    vec3 col = texture(iChannel0,uv).rgb;
    #ifndef NOCOMPILE
    ivec2 ipx = ivec2(fragCoord-0.5);
    if(max(ipx.x+5,ipx.y)<11)col =main_c_bg(fragCoord/iResolution.y-res/2.).rgb;//hide used value pixels
    #else
    col =col+(1.-col.r)*main_c_bg(fragCoord/iResolution.y-res/2.).rgb;
    #endif
    fragColor = vec4(col,1.0);
}
