
// test shader

// using https://www.shadertoy.com/view/MdXcD2
// self https://www.shadertoy.com/view/ftfXDN

#define use_double

#ifndef use_double

#define xfloat float
#define xvec2 vec2
#define xvec3 vec3
#define xvec4 vec4
#define xmat2 mat2
#define xmat3 mat3
#define xmat4 mat4

#else

#define xfloat double
#define xvec2 dvec2
#define xvec3 dvec3
#define xvec4 dvec4
#define xmat2 dmat2
#define xmat3 dmat3
#define xmat4 dmat4

#endif


xfloat triangle(xfloat x) {
  x -= 1.0;
    x /= 4.0;
    x -= floor(x);
    x *= 4.0;
    x -= 2.0;
  x = abs(x);
    x -= 1.;
    return x;
}

xfloat square(xfloat x) {
    x /= 4.0;
    x -= floor(x);
  return 1.0 - 2.0 * step(0.5, x);
}

xvec3 palette(xfloat i) {
  xfloat x = 0.5 + 0.5*triangle(i / 30.0);
    return xvec3(2.0 * x, 2.0 * x - 0.5, 2.0 * x - 1.0);
}

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
  xvec2 pos = (2.0 * fragCoord.xy - iResolution.xy) / max(iResolution.x, iResolution.y);
    xvec2 im = iMouse.xy/iResolution.xy;
    if(iMouse.z<=0.)im*=0.;
#ifdef use_double
    xfloat zoom = 1000000000000000.0 * smoothstep(0.0, 1.0, 0.5 + 0.5 * triangle(iTime / 10.0 + 1.0));
#else
    xfloat zoom = 1000000.0 * smoothstep(0.0, 1.0, 0.5 + 0.5 * triangle(iTime / 10.0 + 1.0));
#endif
    xvec2 z0 = xvec2(-0.9050010009999222, 0.2500021)+10.*im/zoom;

  
    xvec2 z = 2.0 / zoom * pos + z0;

    xfloat t = 0.*iTime / 2.0;
    xfloat r = length(pos);
    xfloat blend = clamp(2.0 * triangle(t) - square(t + 1.0) * r * 0.5, 0.0, 1.0);
    
    xvec2 c = mix(z,z0,smoothstep(0.0, 1.0, blend));
    
    for(int i = 0; i < 256; i++) {
        z = xvec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y);
        z += c;
        if(dot(z,z) > 4.0) {    
        fragColor = vec4(palette(float(i)),1.0);
            return;
        }
    }

    fragColor = vec4(0.0);
}
