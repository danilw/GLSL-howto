
// look comment, expected -20 or 3248488448
// GPU OpenGL result one of values -19.999998 or 3248488447
// GPU Vulkan result one of values -19.999998 other -20.000001 or 3248488447 and 3248488449

vec3 print_n(in vec2 uv ,float val);
int PrintUInt( in vec2 uv, in uint value, const int maxDigits);

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    
    float val0 = 0.4/(0.1*0.4-0.2*0.3);
    float val1 = 0.4/(0.1*0.4-0.2*(0.3+min(iTime,0.)));
    float val2 = 0.4/(0.1*(0.4+min(iTime,0.))-0.2*0.3);
    
    
    vec2 uv = fragCoord/iResolution.y;
    fragColor =vec4(print_n(uv+vec2(-0.95,-0.75),val0),1.);
    fragColor+=vec4(print_n(uv+vec2(-0.95,-0.50),val1),1.);
    fragColor+=vec4(print_n(uv+vec2(-0.95,-0.25),val2),1.);
    
    fragColor+=float(PrintUInt(uv*15.+vec2(-0.95,-11.25),floatBitsToUint(val0),10));
    fragColor+=float(PrintUInt(uv*15.+vec2(-0.95,-7.5),floatBitsToUint(val1),10));
    fragColor+=float(PrintUInt(uv*15.+vec2(-0.95,-3.75),floatBitsToUint(val2),10));
}



const mat3 fontb=mat3(vec3(480599.0,139810.0,476951.0),vec3(476999.0,350020.0,464711.0),vec3(464727.0,476228.0,481111.0));
const mat3 powers = mat3(vec3(1., 10., 100.), vec3(1000., 10000., 100000.), vec3(1000000., 10000000., 100000000.));
float getarr(in mat3 arr, int idx){idx=max(idx,0);return arr[(idx/3)%3][idx%3];}

int get_fvalue(float val, int idx){
    for(int i=0;i<idx+1;i++){
        val=(val-floor(val/10.)*10.)*10.;
    }
    return int(val/10.);
}

float print_num(vec2 uv, float value, int num) {
  if(uv.y < 0.0 || uv.y >= 1.0) return 0.0;
    if(uv.x < -6.0 || uv.x >= 10.0) return 0.0;
  float bits = 0.0;
  int di = - int(floor(uv.x))+ 1;
  if(-di <= num) {
    float pw = getarr(powers,di);
    float val = abs(value);
    float pivot = max(val, 1.5) * 10.0;
    if(pivot < pw) {
      if(value < 0.0 && pivot >= pw * 0.1) bits = 1792.0;
    } else {
            if(di == 0) {
                if(num > 0) bits = 2.0;
            } else {
                int idx=0;
                if(di < 0)idx=get_fvalue(val,int(-di));else idx=(int(val*10.) / int(pw))%10;
                if(idx<=9 && idx>=0)bits = idx<9?getarr(fontb,idx):481095.0;
            }
        }
  } else return 0.;
  return floor(mod(bits / exp2(floor(fract(uv.x) * 4.0) + floor(uv.y * 5.0) * 4.0), 2.0));
}



vec3 print_n(in vec2 uv ,float val){
    int numbers = 6;
    vec2 font = vec2(15.);
    float d = print_num(uv*font, val, numbers);
    return vec3(1.0, 1.0, 1.0)* d;
}


const uint[] ufont = uint[](0x75557u, 0x22222u, 0x74717u, 0x74747u, 0x11574u, 0x71747u, 0x71757u, 0x74444u, 0x75757u, 0x75747u);
const uint[] upowers = uint[](1u, 10u, 100u, 1000u, 10000u, 100000u, 1000000u, 10000000u, 100000000u, 1000000000u);

int PrintUInt( in vec2 uv, in uint value, const int maxDigits )
{
    if( abs(uv.y-0.5)<0.5 )
    {
        int iu = int(floor(uv.x));
        if( iu>=0 && iu<maxDigits )
        {
            uint n = (value/upowers[uint(clamp(maxDigits-iu-1,0,9))]) % 10u;
            uv.x = fract(uv.x);
            uvec2 p = uvec2(floor(uv*vec2(4.0,5.0)));
            return int((ufont[n] >> (p.x+p.y*4u)) & 1u);
        }
    }
    return 0;
}


