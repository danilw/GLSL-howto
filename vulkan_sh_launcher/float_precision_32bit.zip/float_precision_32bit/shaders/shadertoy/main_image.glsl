
// look comment, expected -20

//self https://www.shadertoy.com/view/sllXW8

vec3 print_n(in vec2 uv ,float val);

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    
    float val0 = 0.4/(0.1*0.4-0.2*0.3);
    float val1 = 0.4/(0.1*0.4-0.2*(0.3+min(iTime,0.)));
    float val2 = 0.4/(0.1*(0.4+min(iTime,0.))-0.2*0.3);
    
    
    vec2 uv = fragCoord/iResolution.xy;
    fragColor =vec4(print_n(uv+vec2(-0.5,-0.75),val0),1.);
    fragColor+=vec4(print_n(uv+vec2(-0.5,-0.50),val1),1.);
    fragColor+=vec4(print_n(uv+vec2(-0.5,-0.25),val2),1.);
}



const mat3 fontb=mat3(vec3(480599.0,139810.0,476951.0),vec3(476999.0,350020.0,464711.0),vec3(464727.0,476228.0,481111.0));

int get_fvalue(float val, int idx){
    for(int i=0;i<idx+1;i++){
        val=(val-floor(val/10.)*10.)*10.;
    }
    return int(val/10.);
}

const int[] powers = int[](1, 10, 100, 1000, 10000, 100000, 1000000, 10000000);

float print_num(vec2 uv, float value, int num) {
  if(uv.y < 0.0 || uv.y >= 1.0) return 0.0;
    if(uv.x < -6.0 || uv.x >= 10.0) return 0.0;
  float bits = 0.0;
  int di = - int(floor(uv.x))+ 1;
  if(-di <= num) {
    float pw = float(powers[clamp(di,0,7)]);
    float val = abs(value);
    float pivot = max(val, 1.5) * 10.0;
    if(pivot < pw) {
      if(value < 0.0 && pivot >= pw * 0.1) bits = 1792.0;
    } else {
            if(di == 0) {
                if(num > 0) bits = 2.0;
            } else {
                int idx=0;
                if(di < 0)idx=get_fvalue(val,int(-di));else idx=(int(val*10.) / int(pw))%10;
                if(idx<=9 && idx>=0)bits = idx<9?fontb[idx/3][idx%3]:481095.0;
            }
        }
  } else return 0.;
  return floor(mod(bits / pow(2.0, floor(fract(uv.x) * 4.0) + floor(uv.y * 5.0) * 4.0), 2.0));
}


vec3 print_n(in vec2 uv ,float val){
    int numbers = 6;
        vec2 font = vec2(50.)/vec2(1280,720);
    float d = print_num(uv/font, val, numbers);
        return vec3(1.0, 1.0, 1.0)* d;
}



