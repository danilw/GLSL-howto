
// test shader
// move mouse to middle of screeen

// test for https://www.shadertoy.com/view/4lXfzn
// and https://www.shadertoy.com/view/sllXW8


//self https://www.shadertoy.com/view/ftXXW4

#define use_double

#ifdef use_double
dvec3 getColor( in double t )
{
    return dvec3(t+.25);
}

vec3 colorAniso(vec2 p) {
    dmat2 J = inverse(dmat2(dFdx(p),dFdy(p)));
    J = transpose(J)*J;
    double d = determinant(J), t = J[0][0]+J[1][1],
          D = sqrt((t*t-4.*d)), //D = sqrt(abs(t*t-4.*d)), // fix
          V = (t-D)/2., v = (t+D)/2.,
          M = 1./sqrt(V), m = 1./sqrt(v); float l =log2(float(m)*iResolution.y);
    dvec2 A = M * normalize(dvec2( -J[0][1] , J[0][0]-V ));
    dvec3 O = dvec3(0);
    for (double i = -7.5; i<8.; i++)
        if(p.y<0.)
        O+=clamp(getColor(length(p+(i/16.)*A)),0.,1.);
        else
        O += textureLod(iTextures[0], vec2(p+(i/16.)*A), float(l)).rgb;
    return vec3(O/16.);
}

#else
vec3 getColor( in float t )
{
    return vec3(t+.25);
}

vec3 colorAniso(vec2 p) {
    mat2 J = inverse(mat2(dFdx(p),dFdy(p)));
    J = transpose(J)*J;
    float d = determinant(J), t = J[0][0]+J[1][1],
          D = sqrt((t*t-4.*d)), //D = sqrt(abs(t*t-4.*d)), // fix
          V = (t-D)/2., v = (t+D)/2.,
          M = 1./sqrt(V), m = 1./sqrt(v), l =log2(m*iResolution.y);
    vec2 A = M * normalize(vec2( -J[0][1] , J[0][0]-V ));
    vec3 O = vec3(0);
    for (float i = -7.5; i<8.; i++)
        if(p.y<0.)
        O+=clamp(getColor(length(p+(i/16.)*A)),0.,1.);
        else
        O += textureLod(iTextures[0], p+(i/16.)*A, l).rgb;
    return O/16.;
}
#endif






// intersection scene

#define AA 0

#define MAX_DIST 1000.
#define MIN_DIST .001

#define bgcol vec4(0.4)

mat3 rotx(float a){float s = sin(a);float c = cos(a);return mat3(vec3(1.0, 0.0, 0.0), vec3(0.0, c, s), vec3(0.0, -s, c));  }
mat3 roty(float a){float s = sin(a);float c = cos(a);return mat3(vec3(c, 0.0, s), vec3(0.0, 1.0, 0.0), vec3(-s, 0.0, c));}
mat3 rotz(float a){float s = sin(a);float c = cos(a);return mat3(vec3(c, s, 0.0), vec3(-s, c, 0.0), vec3(0.0, 0.0, 1.0 ));}


struct Ray
{
    vec3 pos;
    vec3 dir;
};

Ray SetCamera(vec2 uv)
{
    vec3 ro = vec3(0.,1.,0.);
    vec2 im=(iMouse.xy/iResolution.y-0.5*iResolution.xy/iResolution.y);
    if(iMouse.z<=0.)im=vec2(0.);
    vec2 m = im*3.1415926-3.1415926*0.5;
    m.y = -m.y;
    float fov=70.;
    float aspect = iResolution.x / iResolution.y;
    float screenSize = (1.0 / (tan(((180.-fov)* (3.1415926 / 180.0)) / 2.0)));
    vec3 rd = normalize(vec3(uv*screenSize, 1./aspect));
    mat3 rotX = mat3(1.0, 0.0, 0.0, 0.0, cos(m.y), sin(m.y), 0.0, -sin(m.y), cos(m.y));
    mat3 rotY = mat3(cos(m.x), 0.0, -sin(m.x), 0.0, 1.0, 0.0, sin(m.x), 0.0, cos(m.x));

    rd = (rotY * rotX) * rd;
    return Ray(ro,rd);
}

bool PlaneIntersect(vec4 Plane, vec3 ro, vec3 rd, out float t, out vec3 norm) {
    norm=vec3(0.,1.,0.);
    t=-1.;
    float dd = dot(rd, Plane.xyz);
    if (dd == 0.0) return false;
    float t1 = -(dot(ro, Plane.xyz) + Plane.w) / dd;
    if (t1 < 0.0) return false;
    norm = normalize(Plane.xyz);
    t = t1;
    return true;
}

bool ParallelogramIntersect( in vec3 ro, in vec3 rd, in vec3 v0, in vec3 v1, in vec3 v2, in vec3 v3, out float tx, out vec3 norm)
{
    vec3 a = v0 - v1;
    vec3 b = v2 - v0;
    vec3 p = v0 - ro;
    vec3 n = cross( a, b );
    vec3 q = cross( rd, p );
    float i = 1.0/dot( rd, n );
    float u = dot( q, a )*i;
    float v = dot( q, b )*i;
    float t = dot( n, p )*i;
    tx=-1.;
    norm=vec3(0.,1.,0.);
    if( u<0.0 || u>1.0 || v<0.0 || v>1.0 ) return false;
    vec3 normx = vec3( t, u, v );
    if( normx.x>MIN_DIST && normx.x<MAX_DIST )
    {
    tx = normx.x;
    vec3 nor = normalize( cross(v2-v1,v1-v3) );
    norm = faceforward( nor, rd, nor );
    return true;
    }
    return false;
}

vec4 calcColor_procedural_AA(vec3 ro, vec3 rd, float d)
{
    vec3 p = (ro+rd*d);
    vec3 tc=colorAniso(p.xz*01.01);
    return vec4(tc,1.); 
}

vec3 color_grid(vec2 p,float d) {
    vec2 e = min(vec2(1.0), fwidth(p)); 
    vec2 l = smoothstep(vec2(1.0), 1.0 - e, fract(p)) + smoothstep(vec2(0.0), e, fract(p)) - (1.0 - e);
    return mix(vec3(0.4), vec3(0.8) * (l.x + l.y) * 0.5, exp(-d*0.01));
}
vec4 calcColortb(vec3 ro, vec3 rd, float d) {
    vec2 p = (ro+rd*d).xz;
    return vec4(vec3(color_grid(p,d)),1.);
}


#define OBJ_SKY 0
#define OBJ_BALL 1
#define OBJ_FLOOR 2
#define OBJ_WALL 3

struct HitInfo {
    float t;
    vec3 norm;
    vec4 color;
    int obj_type;
};

void ParallelogramIntersectMin(vec3 ro, vec3 rd, in vec3 v0, in vec3 v1, in vec3 v2, inout bool result, 
                               inout HitInfo hit, int OBJ) {
    float tnew;
    vec3 normnew;
    vec3 v3 = v1 + v2 - v0;
    if (ParallelogramIntersect(ro, rd, v0, v1, v2, v3, tnew, normnew)) {
        if (tnew < hit.t) {
            hit.t = tnew;
            hit.norm = normnew;
            hit.color= calcColor_procedural_AA(ro,rd,hit.t);
            hit.obj_type = OBJ;
            result = true;
        }
    }
}

void GroundIntersectMin(vec3 ro, vec3 rd, inout bool result, inout HitInfo hit) {
    float tnew;
    vec3 normnew;
    vec4 pp=vec4(0.0,01.,0.0,0.);
    if (PlaneIntersect(pp, ro, rd, tnew, normnew)) {
        if (tnew < hit.t) {
            hit.t = tnew;
            hit.norm = normnew;
            hit.color = calcColortb(ro,rd,hit.t);
            hit.obj_type = OBJ_FLOOR;
            result = true;
        }
    }
}

bool minDist(vec3 ro, vec3 rd, out HitInfo hit)
{
    hit.t = MAX_DIST;
    hit.obj_type = OBJ_SKY;
    hit.color=bgcol;
    bool result = false;

    vec3 v0 = vec3(-1.,-1.,-1.); 
    vec3 v1 =  vec3(1.,-1.,-1.); 
    vec3 v2 =  vec3(-1.,-1.,1.); 

    GroundIntersectMin(ro, rd, result, hit);

    ParallelogramIntersectMin(ro+vec3(0.,-1.5,0.), rd, v0, v1, v2, result, hit,OBJ_WALL);

    return result;
}

const float eps = 1e-3;

vec3 render(Ray r)
{
    vec3 col = vec3(0.0);
    vec3 objectcolor = vec3(1.0);
    vec3 mask = vec3(1.0);
    HitInfo hit;
    hit.color=vec4(0.);
    {
        if(minDist(r.pos, r.dir, hit)){
            objectcolor = hit.color.rgb;
            vec3 p = r.pos + r.dir * hit.t + hit.norm*eps;
            col = objectcolor;
        }else col = bgcol.rgb;
    }
    return col;
 }

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{   
    vec3 ret_col = vec3(0.0);
    #if AA>1
    for( int mx=0; mx<AA; mx++ )
    for( int nx=0; nx<AA; nx++ )
    {
    vec2 o = vec2(float(mx),float(nx)) / float(AA) - 0.5;
    vec2 uv = (fragCoord+o)/iResolution.xy * 2.0 - 1.0;
    #else
    vec2 uv = fragCoord/iResolution.xy * 2.0 - 1.0;
    #endif
    uv.y *= iResolution.y/iResolution.x;
    vec3 col = render(SetCamera(uv));
    ret_col += col;
    #if AA>1
    }
    ret_col /= float(AA*AA);
    #endif
    fragColor = vec4( clamp(pow(ret_col, vec3(0.4545)),vec3(0.),vec3(1.)), 1.0 );
}
