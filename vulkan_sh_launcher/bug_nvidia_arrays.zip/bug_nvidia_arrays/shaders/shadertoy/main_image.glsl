
#define is_TRUE (iTime > -1.)
#define is_ZER0 min(iTime, 0.)

// self https://www.shadertoy.com/view/7sl3zn

// Vulkan


// RESULT:
// BUG - white screen color
// NO BUG - purple screen color


// line 98- OpenGL compability (this shader result BUG in OpenGL and Vulkan)
// line 101- Vulkan only


// Vulkan trigger same bug but not same code
// length(rd) alway * is_ZER0
// ro unused
// and magic function magic_mat3
// removing any line of this code make bug no longer work in Vulkan


// this magic mat3 needed to trigger bug on Vulkan, editing any of its values make bug not work
mat3 magic_mat3()
{
    return mat3(vec3(is_ZER0, is_ZER0, 0.0), vec3(is_ZER0, is_ZER0, 0.0), vec3(1.0));
}

vec4 bug_vulkan(in vec3 ro, in vec3 rd)
{
    vec3 col = vec3(0.);


    vec4[3] colx = vec4[3](vec4(0.), vec4(0.), vec4(0.));
    int[3] order = int[3](0, 1, 2);

    for (int i = 0; i < 3; i++)
    {
        // removing any of this lines (ro unused in this code) make bug not work
        if (length(rd) * is_ZER0 > 1.) // this false
        {
            ro *= magic_mat3();
            rd *= magic_mat3();
        }

        float tnew = 1. + length(rd) * is_ZER0;

        {
            if (tnew > 0.)
            {
                vec4 tcol = vec4(0.);
                vec4 tcolsi = vec4(0.);
                tcol = vec4(0., 1., 0., 1.);

                if (tcol.a > 0.0)
                {

                    colx[i] = tcol;
                    colx[i].rgb = vec3(1., 0., 1.);
                }
            }
        }
    }
    return vec4(colx[order[0 + int(is_ZER0)]]);
}

void mainImage(out vec4 fragColor, in vec2 fragCoord)
{
    vec2 uv = fragCoord / iResolution.xy;

    vec3 rd = vec3(uv, 1.);
    float t = 1.;
    vec3 ro = vec3(1.);

    fragColor = vec4(0.);

    if (is_TRUE)
    {

        vec4[2] colo = vec4[2](vec4(0.), vec4(0.));

        for (int j = 0; j < 2; j++)
        {
            {
                vec4 tcol = bug_vulkan(ro, rd);
                if (is_TRUE)
                {
                    colo[j] = tcol;
                }
            }
        }

        // this does work even in OpenGL
        // if uncomment this line this shader will result BUG even in OpenGL
        vec3 col = colo[0].rgb + colo[1].rgb * is_ZER0;
        
        // in Vulkan it result bug color, in OpenGL not bug
        //vec3 col = colo[0].rgb;

        fragColor = vec4(col, 1.);
    }
}
