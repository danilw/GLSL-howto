
// self https://www.shadertoy.com/view/NlXXWS

// Bug is:
// using break in loop adds precision to operation (real time and const precalculated)
// same with return

// expected is 0

// real result +-0.00000000297 in this case

const float float_one = 0.999; //or 0.9999 or 1.0
const float float_tenth = 0.1;

// --------bug code--------

float map_precompiled_if()
{
    float d = 1.;
    for( int i=0; i<1; i++ )
    {
        d *= float_tenth;
        if(d>0.)
        break;
    }
    return d;
}


float map_precompiled_noif()
{
    float d = 1.;
    for( int i=0; i<1; i++ )
    {
        d *= float_tenth;
        //if(d>0.)
        break;
    }
    return d;
}

float map_precompiled_no_break()
{
    float d = 1.;
    for( int i=0; i<1; i++ )
    {
        d *= float_tenth;
        //if(d>0.)
        //break;
    }
    return d;
}

float map_realtime()
{
    float d = 1.;
    for( int i=0; i<1+int(min(iTime,0.)); i++ )
    {
        d *= float_tenth+min(iTime,0.);
        if(d>0.)
        break;
    }
    return d;
}

float map_realtime_no_break()
{
    float d = 1.;
    for( int i=0; i<1+int(min(iTime,0.)); i++ )
    {
        d *= float_tenth+min(iTime,0.);
        //if(d>0.)
        //break;
    }
    return d;
}


int PrintUInt( in vec2 uv, in uint value, const int maxDigits);

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    
    //right column
    float val0 = float_one*map_precompiled_if()-float_one*float_tenth;
    float val1 = float_one*map_precompiled_noif()-float_one*float_tenth;
    float val2 = float_one*map_precompiled_no_break()-float_one*float_tenth;
    
    float val3 = (float_one+min(iTime,0.))*map_realtime()-
                    (float_one+min(iTime,0.))*(float_tenth+min(iTime,0.));
    
    float val4 = (float_one+min(iTime,0.))*map_realtime_no_break()-
                    (float_one+min(iTime,0.))*(float_tenth+min(iTime,0.));
    
    //left top
    float val5 = float_one*map_precompiled_noif()-
                    (float_one+min(iTime,0.))*(float_tenth+min(iTime,0.));
    
    float val6 = float_one*map_precompiled_noif()-
                    float_one*(float_tenth+min(iTime,0.));
    
    
    
    vec2 res = iResolution.xy/iResolution.y;
    vec2 uv = fragCoord/iResolution.y-0.5*res;
    
    float d=0.;
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2.,-5.75),floatBitsToUint(val0),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2.,-2.75),floatBitsToUint(val1),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2., 0.00),floatBitsToUint(val2),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2., 2.75),floatBitsToUint(val3),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2., 5.75),floatBitsToUint(val4),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(12.,-5.75),floatBitsToUint(val5),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(12.,-2.75),floatBitsToUint(val6),10)),0.,1.);
    fragColor=vec4(d);
    fragColor.a=1.;
}



const uint[] ufont = uint[](0x75557u, 0x22222u, 0x74717u, 0x74747u, 0x11574u, 0x71747u, 0x71757u, 0x74444u, 0x75757u, 0x75747u);
const uint[] upowers = uint[](1u, 10u, 100u, 1000u, 10000u, 100000u, 1000000u, 10000000u, 100000000u, 1000000000u);

int PrintUInt( in vec2 uv, in uint value, const int maxDigits )
{
    if( abs(uv.y-0.5)<0.5 )
    {
        int iu = int(floor(uv.x));
        if( iu>=0 && iu<maxDigits )
        {
            uint n = (value/upowers[uint(clamp(maxDigits-iu-1,0,9))]) % 10u;
            uv.x = fract(uv.x);
            uvec2 p = uvec2(floor(uv*vec2(4.0,5.0)));
            return int((ufont[n] >> (p.x+p.y*4u)) & 1u);
        }
    }
    return 0;
}











// --------original minimal code--------


/*

// Bug result - Gray color
// No Bug result - Black color


// test realtime vs precompiled

#define fZero 0.
//#define fZero min(iTime,0.)


const float float_one = 0.999;
//const float float_one = 0.99999; // fix or 0.9999 or 1.0

const float float_tenth = 0.1;

float map()
{
    float d = 1.;
    for( int i=0; i<1+int(fZero); i++ )
    {
        d *= float_tenth+fZero;
        //return d; // fix 
        //if(d>0.) //does impact on precompiled result, comment/uncomment
        break; //adds 0.00000000297
    }
    return d;
}

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
  vec3 tcol=vec3(float_one*map()-float_one*float_tenth);
  fragColor = vec4( tcol*100000000., 1.0 );
}



*/
