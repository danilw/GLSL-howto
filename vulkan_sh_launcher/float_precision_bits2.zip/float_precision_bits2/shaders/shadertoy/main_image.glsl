
// self https://www.shadertoy.com/view/ftXSWB


const float float_one_const = 0.999; //or 0.9999 or 1.0
const float float_tenth_const = 0.1;

int PrintUInt( in vec2 uv, in uint value, const int maxDigits);

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    
    float float_one_dyn = float_one_const+min(iTime,0.);
    float float_tenth_dyn = float_tenth_const+min(iTime,0.);
    
    float val_const = float_one_const*float_tenth_const;
    
    float val_dyn = float_one_dyn*float_tenth_dyn;
    
    float val0 = val_const - val_const;
    
    float val1 = val_dyn - val_dyn;
    
    float val2 = val_const - val_dyn;
    
    float val3 = val_dyn - val_const;
    
    
    vec2 res = iResolution.xy/iResolution.y;
    vec2 uv = fragCoord/iResolution.y-0.5*res;
    
    float d=0.;
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2.,-5.75),floatBitsToUint(val0),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2.,-2.75),floatBitsToUint(val1),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2., 0.00),floatBitsToUint(val2),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(-2., 2.75),floatBitsToUint(val3),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(12.,-5.75),floatBitsToUint(val_const),10)),0.,1.);
    d+=clamp(float(PrintUInt(uv*15.+vec2(12.,-2.75),floatBitsToUint(val_dyn),10)),0.,1.);
    fragColor=vec4(d);
    fragColor.a=1.;
}



const uint[] ufont = uint[](0x75557u, 0x22222u, 0x74717u, 0x74747u, 0x11574u, 0x71747u, 0x71757u, 0x74444u, 0x75757u, 0x75747u);
const uint[] upowers = uint[](1u, 10u, 100u, 1000u, 10000u, 100000u, 1000000u, 10000000u, 100000000u, 1000000000u);

int PrintUInt( in vec2 uv, in uint value, const int maxDigits )
{
    if( abs(uv.y-0.5)<0.5 )
    {
        int iu = int(floor(uv.x));
        if( iu>=0 && iu<maxDigits )
        {
            uint n = (value/upowers[uint(clamp(maxDigits-iu-1,0,9))]) % 10u;
            uv.x = fract(uv.x);
            uvec2 p = uvec2(floor(uv*vec2(4.0,5.0)));
            return int((ufont[n] >> (p.x+p.y*4u)) & 1u);
        }
    }
    return 0;
}
