
void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    fragColor-= fragColor; //not initialized variable
    fragColor-=  max(0., length(fragCoord/iResolution.xy)-.8 ); 
    fragColor = sqrt(1.-fragColor);
}
