// this does not work in WebGL look like, because Vsynk I think

const int delta_time_pixel=1; // ID of pixel to use delta from its pixel as default delta 1 2 3 etc (st_size does not matter)

const int px_size=16; // pixel size, this value is result of pow(2,X), if it not pow2(example 20) then youl see red overlap rectangles
const int st_size=1; // step size, 1 2 3 etc
const int frame_lim=15; // frame to calculate delta
