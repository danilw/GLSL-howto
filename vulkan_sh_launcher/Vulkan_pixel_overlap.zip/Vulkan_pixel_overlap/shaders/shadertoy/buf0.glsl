
const int iId=0;

// this always return 0 and use only *0
vec3 const_op_time(vec2 uv, int j){
  vec3 tmp=vec3(0.);
  for (int i=0;i<512+int(min(iTime,0.));i++){
    uv+=float(i)+float(j);
    tmp+=sin(vec3(dot(min(uv,vec2(0.)),vec2(min(iTime+float(j)+float(i),0.)))));
  }
  return tmp;
}

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    ivec2 ipx=ivec2(fragCoord);
    vec2 uv=fragCoord/iResolution.xy;
    vec4 fc=vec4(-1.);
    int iFrame_local=int(texelFetch(iChannel0,ivec2(iResolution.xy-1.),0).r);
    int loops=int(texelFetch(iChannel0,ivec2(iResolution.xy-1.),0).g);
    bool start=int(texelFetch(iChannel0,ivec2(iResolution.xy-1.),0).b)>1;
    bool isact=int(texelFetch(iChannel0,ivec2(iResolution.xy-1.),0).a)<-1;
    if(!isact){
        iFrame_local=0;
        loops=0;
        start=false;
    }
    if((ipx.x==int(iResolution.x-1.))&&(ipx.y==int(iResolution.y-1.))){
        float stv=texelFetch(iChannel0,ivec2(iResolution.xy-1.),0).b;
        iFrame_local+=1;
        if((!start)&&(iFrame_local>20)){
            if(iTimeDelta<=1./float(frame_lim)){
                loops+=13;
            }else{
                stv=10.;
                iFrame_local=0;
            }
        }
        if(iMouse.z>0.){
            loops=0;
            iFrame_local=0;
            stv=-1.;
        }
        fragColor=vec4(float(iFrame_local),float(loops),stv,-10.);
        return;
    }
    if(iFrame_local<2){
        fragColor=fc;
        return;
    }
    ivec2 ifs=ivec2(0);
    int ifr=iFrame_local-10;
    ifr=max(ifr,0);
    int total=(int(iResolution.x+float(px_size))*int(iResolution.y))/(px_size*px_size);
    total=int(float(total)*1./float(st_size));
    total=total/1;
    if(ifr<total){
        ifs.x=px_size*st_size*((ifr+total*iId)%
                                   int(float((int(iResolution.x+float(px_size))/(px_size)))*1./float(st_size))
                                  );
        ifs.y=px_size*((ifr+total*iId)/int(float((int(iResolution.x+float(px_size))/(px_size)))*1./float(st_size)));
        ipx+=-ifs;
        if((ipx.x>=0)&&(ipx.x<px_size)&&(ipx.y>=0)&&(ipx.y<px_size)){
            for (int i=0;i<loops+int(min(iTime,0.));i++){
                uv+=float(i);
                vec3 tmp=const_op_time(uv+10.,i);
                fc = vec4(fc.rgb+tmp,iTimeDelta);
            }
            fragColor=fc;
            return;
        }
    }
    fragColor=texelFetch(iChannel0,ivec2(fragCoord),0);
}
