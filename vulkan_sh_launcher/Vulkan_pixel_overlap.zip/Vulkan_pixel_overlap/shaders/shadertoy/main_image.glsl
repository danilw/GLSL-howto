
//self https://www.shadertoy.com/view/WscfRM

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{

    ivec2 ipx=ivec2(fragCoord);
    float val=0.;
    val=texelFetch(iChannel0,ipx,0).a;
    ivec2 dp=ivec2((delta_time_pixel*px_size*st_size)%int(iResolution.x),(delta_time_pixel*px_size*st_size)/int(iResolution.x));
    float exptime=texelFetch(iChannel0,dp,0).a;
    
    float ta=val/exptime-1.;
    ta*=1.;
    vec3 col=vec3(1.,0.1,0.1)*clamp(ta,0.,1.)+vec3(0.1,1.,0.1)*clamp(-ta,0.,1.);
    fragColor=vec4(col,1.);
    if(val<0.){
      fragColor=vec4(vec3(0.),1.);
    }
}
