/*
 * SHADER COPY FROM 
 * LLM: The Tipsy Poet Created by Espeset
 * https://www.shadertoy.com/view/NctSRl
*/
/*

Created by Tonny Espeset, 2026
https://www.shadertoy.com/view/NctSRl

The Tipsy Poet

Feel free to use this code, but please keep this credit and link.

Check my other shaders at

https://www.shadertoy.com/user/Espeset

Buffer D: decode - logits, sampling, word-trie walk, pacing and the text grid; also hosts most of the int3 weight stream.
*/

// ==== Shadertoy tab: Buffer D (decode + weight host) ====
// iChannel0 = Buffer D (self), iChannel1 = Buffer A, iChannel2 = Buffer C, iChannel3 = unused
#define CH_CTL iChannel0
#define ST_BUILD 1
#define LBASE 6
#define NL_HERE 0
#define IS_LAST_DECODE 1
#define HOSTED_TEXELS 38226

ivec4 get_WD(int idx){
    ivec4 ret;
    idx=idx%3584;
    ivec2 ipx = ivec2(idx%64, idx/64);
    vec4 a = 255.5*texelFetch(iChannel3, ipx,0);
    vec4 b = 255.5*texelFetch(iChannel3, ipx+ivec2(64,0),0);
    vec4 c = 255.5*texelFetch(iChannel3, ipx+ivec2(64*2,0),0);
    vec4 d = 255.5*texelFetch(iChannel3, ipx+ivec2(64*3,0),0);
    ret = ivec4(uvec4(a)+(uvec4(b)<<8)+(uvec4(c)<<16)+(uvec4(d)<<24));
    return ret;
}

int weightScaleIdx(int g) {
    int f = 4 * g;
    int layer = f / 40960;
    int v = f - layer * 40960;
    int row;
    if (v < 12288) row = v / D_MODEL;
    else if (v < 16384) row = 3 * D_MODEL + (v - 12288) / D_MODEL;
    else if (v < 28672) row = 4 * D_MODEL + (v - 16384) / D_MODEL;
    else row = 4 * D_MODEL + FF_DIM + (v - 28672) / FF_DIM;
    return layer * 512 + row;
}
float scaleFor(int g) {
    int sidx = weightScaleIdx(g);
    int st = (OFF_SCALES >> 2) + (sidx >> 2);
    return texelFetch(iChannel1, ivec2(st & 511, st >> 9), 0)[sidx & 3];
}
vec4 bakeW(int u) {
    int g = u < 22531 ? 8189 + u : 38909 + (u - 22531);
    int bit = 12 * u;
    int k = bit >> 5;
    int sh = bit & 31;
    uint lo = uint(get_WD(k >> 2)[k & 3]);
    uint hi = uint(get_WD((k + 1) >> 2)[(k + 1) & 3]);
    uint w12 = (sh == 0 ? lo : ((lo >> uint(sh)) | (hi << uint(32 - sh)))) & 4095u;
    float sc = scaleFor(g);
    return (vec4(w12 & 7u, (w12 >> 3) & 7u, (w12 >> 6) & 7u, (w12 >> 9) & 7u) - 4.0) * sc;
}
vec4 wW(int t) { return vec4(0); }
// layers.glsl — a 2-layer slice of the transformer, instantiated once per pair of layers.
//   #define LBASE 0/2/4...; the slice with LBASE+2 == N_LAYER is the last and also runs decode.
// channels: iChannel0 = self (my KV ring), iChannel1 = ROM,
//           iChannel2 = previous slice (x_mid; unused when LBASE == 0), iChannel3 = last slice (control)
//
// layout (within my own buffer):
//   y in [0,64) x in [0,32)   K ring: x = (l - LBASE)*16 + chunk, y = slot
//   y in [0,64) x in [32,64)  V ring: same minus 32
//   y == 64     x in [0,16)   x_mid residual out (non-last slices)
//   y == 65     x in [0,16)   logits (last slice, for visuals)
//   (0,66)                    control (t, curTok, gen, trieNode)   (last slice)
//   y in [68,76)              text ring, 1024 entries               (last slice)

#ifndef GREEDY
#define GREEDY 1
#endif
#ifndef USE_TRIE
#define USE_TRIE 0
#endif
#ifndef SAMPLE_SEED
#define SAMPLE_SEED 1
#endif
#ifndef PACE_FAST
#define PACE_FAST 1
#endif
#ifndef SEED_FROM_DATE
#define SEED_FROM_DATE 0
#endif
#define SAMPLE_TEMP 0.8
#define SAMPLE_TOPK 12
#define RING_Y0 68
#define RING_SIZE 1024
// text grid: GRID_COLS x GRID_LINES cells, one texel each: (charIdx+1, entropy, lineNumber, 1)
#define GRID_Y0 80
#ifndef GRID_COLS
#define GRID_COLS 46
#endif
#define GRID_LINES 40
// where the control texels live: the last slice for B/C, this buffer itself for D
// pacing (frames per char at 60fps; ~12 cps base)
#define PACE_BASE 5.0
#define PACE_NEWLINE 22.0
#define PACE_PUNCT 8.0
#define D4 (D_MODEL / 4)
#define F4 (FF_DIM / 4)
#define KV_XV (NL_HERE * D4)
#define RMS_EPS 1.1920929e-7

// Shadertoy build: the shared prefix (emb/norms/scales/trie) lives in Buffer A (iChannel1);
// matmul weights are spread across host-tab buffers — the tab preamble defines wW(t) with its
// source ranges, plus bakeW(u) for the rows this tab hosts. Fixed 512-wide addressing.
#define WROW0 128
vec4 wS(int t) { return texelFetch(iChannel1, ivec2(t & 511, t >> 9), 0); }
vec4 gX[D4];

// forward through my two layers; K/V of this token land in gK/gV, residual in gX.
void forwardHalf(int tok, int t) {
    for (int i = 0; i < D4; i++) gX[i] = texelFetch(iChannel2, ivec2(i, 64), 0);
}

int popcnt(uint v) {
    v = v - ((v >> 1) & 0x55555555u);
    v = (v & 0x33333333u) + ((v >> 2) & 0x33333333u);
    v = (v + (v >> 4)) & 0x0f0f0f0fu;
    return int((v * 0x01010101u) >> 24);
}

uint lowbias32(uint x) {
    x ^= x >> 16;
    x *= 0x7feb352du;
    x ^= x >> 15;
    x *= 0x846ca68bu;
    x ^= x >> 16;
    return x;
}

float rand01(int gen, uint seed) {
    return float(lowbias32(uint(gen) ^ (seed * 0x9e3779b9u))) * exp2(-32.);
}

float gLogits[VOCAB];

// final rmsnorm + tied head, from gX
void computeLogits() {
    float ss = 0.;
    for (int i = 0; i < D4; i++) ss += dot(gX[i], gX[i]);
    float r = inversesqrt(ss / float(D_MODEL) + RMS_EPS);
    vec4 xf[D4];
    for (int i = 0; i < D4; i++) xf[i] = gX[i] * r * wS((OFF_NORMF >> 2) + i);
    for (int row = 0; row < VOCAB; row++) {
        float a = 0.;
        int b = (OFF_EMB >> 2) + row * D4;
        for (int cc = 0; cc < D4; cc++) a += dot(wS(b + cc), xf[cc]);
        gLogits[row] = a;
    }
}

// trie mask + decode over gLogits. returns (newTok, entropy, newTrieNode)
vec3 decodeStep(int gen, int node, uint seed) {
    float lg[VOCAB];
    for (int i = 0; i < VOCAB; i++) lg[i] = gLogits[i];
#if USE_TRIE
    // node is packed: low 16 bits = first-edge index (TRIE_LEAF = no children), bit 16 = at-word-end
    int fe = node & 0xFFFF;
    bool endok = (node >> 16) > 0;
    uint tmask = 0u;
    if (fe != TRIE_LEAF) {
        for (int e = 0; e < 30; e++) {
            vec4 ed = wS(TRIE_TEXEL0 + fe + e);
            tmask |= 1u << uint(ed.y);
            if (ed.w > 0.5) break;
        }
    }
    for (int i = 0; i < VOCAB; i++) {
        int c = charClassOf(i);
        bool ok = c >= 0 ? ((tmask >> uint(c)) & 1u) == 1u : endok;
        if (!ok) lg[i] = -1e30;
    }
#endif
    float mx = -1e30;
    for (int i = 0; i < VOCAB; i++) mx = max(mx, lg[i]);
    float denom = 0.;
    for (int i = 0; i < VOCAB; i++) denom += exp(lg[i] - mx);
    float entropy = 0.;
    for (int i = 0; i < VOCAB; i++) {
        float p = exp(lg[i] - mx) / denom;
        if (p > 1e-12) entropy -= p * log(p);
    }
#if GREEDY
    int newTok = 0;
    float best = -1e30;
    for (int i = 0; i < VOCAB; i++) { if (lg[i] > best) { best = lg[i]; newTok = i; } }
#else
    float sg[VOCAB];
    for (int i = 0; i < VOCAB; i++) sg[i] = lg[i] / SAMPLE_TEMP;
    float prev = 1e30;
    for (int n = 0; n < SAMPLE_TOPK; n++) {
        float bb = -1e30;
        for (int i = 0; i < VOCAB; i++) { if (sg[i] < prev && sg[i] > bb) bb = sg[i]; }
        prev = bb;
    }
    float smx = -1e30;
    for (int i = 0; i < VOCAB; i++) smx = max(smx, sg[i]);
    float e2[VOCAB];
    float total = 0.;
    for (int i = 0; i < VOCAB; i++) { e2[i] = sg[i] >= prev ? exp(sg[i] - smx) : 0.; total += e2[i]; }
    float target = rand01(gen, seed) * total;
    int newTok = VOCAB - 1;
    float cum = 0.;
    for (int i = 0; i < VOCAB; i++) {
        cum += e2[i];
        if (cum > target) { newTok = i; break; }
    }
#endif
    int newNode = 0;
#if USE_TRIE
    int nc = charClassOf(newTok);
    newNode = TRIE_ROOT_PACKED;
    if (nc >= 0) {
        for (int e = 0; e < 30; e++) {
            vec4 ed = wS(TRIE_TEXEL0 + fe + e);
            if (int(ed.y) == nc) { newNode = int(ed.x) | (int(ed.z) > 0 ? 0x10000 : 0); break; }
        }
    }
#endif
    return vec3(float(newTok), entropy, float(newNode));
}

void mainImage(out vec4 O, in vec2 fragCoord) {
    ivec2 p = ivec2(fragCoord);
    if (p.y >= WROW0) {
        int u = (p.y - WROW0) * 512 + p.x;
        if (p.x >= 512 || u >= HOSTED_TEXELS) { O = vec4(0); return; }
        O = bakeW(u);
        return;
    }
    bool kvTexel = p.y < WINDOW && p.x < 2 * KV_XV;
    bool logitTexel = p.y == 65 && p.x < VOCAB / 4;
    bool ctlTexel = p == ivec2(0, 66);
    bool ctl2Texel = p == ivec2(1, 66);
    bool ctl3Texel = p == ivec2(2, 66);
    bool ctl4Texel = p == ivec2(3, 66);
    bool ringTexel = p.y >= RING_Y0 && p.y < RING_Y0 + RING_SIZE / 128 && p.x < 128;
    bool gridTexel = p.y >= GRID_Y0 && p.y < GRID_Y0 + GRID_LINES && p.x < GRID_COLS;
    bool isLive = kvTexel || logitTexel || ctlTexel || ctl2Texel || ctl3Texel || ctl4Texel || ringTexel || gridTexel;
    if (iFrame == 0) {
        O = vec4(0);
#if USE_TRIE
        if (p == ivec2(0, 66)) O = vec4(0., float(TOK_NEWLINE), 0., float(TRIE_ROOT_PACKED));
#else
        if (p == ivec2(0, 66)) O = vec4(0., float(TOK_NEWLINE), 0., 0.);
#endif
        if (p == ivec2(1, 66)) O = vec4(0., 0., 0., 0.);   // cooldown, curCol, curLine, scrollY
        if (p == ivec2(3, 66)) O = vec4(-1., 0., 0., 0.);  // wordStartCol (-1 = not in a word), wordStartGen
        if (p == ivec2(2, 66)) {                            // seed, prevMouseZ, reseeds, spare
#if SEED_FROM_DATE
            uint s0 = lowbias32(uint(iDate.w * 977.0) + uint(iDate.z) * 65537u) & 0xFFFFFFu;
#else
            uint s0 = uint(SAMPLE_SEED);
#endif
            O = vec4(float(s0), 0., 0., 0.);
        }
        return;
    }
    if (!isLive) { O = texelFetch(iChannel0, p, 0); return; }

    vec4 ctl = texelFetch(CH_CTL, ivec2(0, 66), 0);
    vec4 ctl2 = texelFetch(CH_CTL, ivec2(1, 66), 0);
    vec4 ctl3 = texelFetch(CH_CTL, ivec2(2, 66), 0);
    int t = int(ctl.x);
    int curTok = int(ctl.y);
    int gen = int(ctl.z);
    int trieNode = int(ctl.w);
    int slot = t % WINDOW;
#if PACE_FAST
    bool emitNow = true;
#else
    bool emitNow = ctl2.x < 0.5;
#endif

    uint seed = uint(ctl3.x);
    int curCol = int(ctl2.y);
    int curLine = int(ctl2.z);
    vec4 ctl4 = texelFetch(CH_CTL, ivec2(3, 66), 0);
    // ctl2 and ctl3 update every frame (cooldown countdown, scroll ease, reseed watch)
    if (ctl3Texel) {
        O = vec4(float(seed), 0., 0., iTime);
        return;
    }
    if (!emitNow) {
        if (ctl2Texel) {
            // pacing is wall-clock: cooldown counts 60ths of a second, so any display Hz reads the same
            float dt60 = clamp((iTime - ctl3.w) * 60.0, 0.0, 6.0);
            float scroll = ctl2.w + (float(curLine) - ctl2.w) * (1.0 - pow(0.87, dt60));
            O = vec4(ctl2.x - dt60, ctl2.y, ctl2.z, scroll);
            return;
        }
        O = texelFetch(iChannel0, p, 0);
        return;
    }

    if (kvTexel && p.y != slot) { O = texelFetch(iChannel0, p, 0); return; }
    if (ringTexel && !kvTexel) {
        int idx = (p.y - RING_Y0) * 128 + p.x;
        if (idx != gen % RING_SIZE) { O = texelFetch(iChannel0, p, 0); return; }
    }
    if (gridTexel) {
        // live cells: the cursor, plus (when a word may relocate to the next line) the word's old cells and their landing zone
        int rowOldG = GRID_Y0 + (curLine % GRID_LINES);
        int rowNewG = GRID_Y0 + ((curLine + 1) % GRID_LINES);
        int ws4g = int(ctl4.x);
        int effWsG = ws4g < 0 ? curCol : ws4g;
        bool wrapZone = curCol == GRID_COLS - 2 && ws4g != 0;
        bool involved = (p.x == curCol && p.y == rowOldG) || (wrapZone && p.y == rowOldG && p.x >= effWsG) || (wrapZone && p.y == rowNewG && p.x <= curCol - effWsG);
        if (!involved) { O = texelFetch(iChannel0, p, 0); return; }
    }

    forwardHalf(curTok, t);

    computeLogits();
    if (logitTexel) { O = vec4(gLogits[p.x * 4], gLogits[p.x * 4 + 1], gLogits[p.x * 4 + 2], gLogits[p.x * 4 + 3]); return; }
    vec3 d = decodeStep(gen, trieNode, seed);
    int newTok = int(d.x);
    // word wrap: if a letter is about to land in the last column while a word is in progress, the whole word moves to the next line
    bool nlTok = newTok == TOK_NEWLINE;
    int wAscii = charCodeOf(newTok);
    bool wLetter = (wAscii >= 97 && wAscii <= 122) || (wAscii >= 65 && wAscii <= 90) || wAscii == 39;
    int ws4 = int(ctl4.x);
    int effWs = ws4 < 0 ? curCol : ws4;
    bool wordWrap = !nlTok && wLetter && curCol == GRID_COLS - 2 && ws4 != 0;
    if (ctlTexel) {
        O = vec4(float(t + 1), d.x, float(gen + 1), d.z);
        return;
    }
    if (ctl2Texel) {
        bool nl = nlTok;
        int col = nl ? 0 : curCol + 1;
        int line = curLine;
        if (wordWrap) { line += 1; col = curCol - effWs + 1; }
        else if (nl || col >= GRID_COLS - 1) { line += 1; col = 0; }
#if PACE_FAST
        float cool = 0.0;
#else
        float cool = PACE_BASE + rand01(gen * 7 + 3, seed) * 4.0 + d.y * 2.0;
        if (line != curLine) cool += PACE_NEWLINE;   // pause on ANY line advance (newline or wrap), so the scroll settles before the next char
        if (newTok < 13 && newTok > 1) cool += PACE_PUNCT;   // charset 2..12 = punctuation
#endif
        float dt60 = clamp((iTime - ctl3.w) * 60.0, 0.0, 6.0);
        float scroll = ctl2.w + (float(line) - ctl2.w) * (1.0 - pow(0.87, dt60));
        O = vec4(cool, float(col), float(line), scroll);
        return;
    }
    if (ctl4Texel) {
        float nws;
        float nwsGen = ctl4.y;
        if (nlTok || !wLetter) nws = -1.;
        else if (wordWrap) nws = 0.;
        else if (curCol + 1 >= GRID_COLS - 1) nws = -1.;   // unmovable word hard-broke at the edge; next line starts fresh
        else if (ws4 < 0) { nws = float(curCol); nwsGen = float(gen); }
        else nws = ctl4.x;
        O = vec4(nws, nwsGen, 0., 0.);
        return;
    }
    if (gridTexel) {
        if (nlTok) { O = texelFetch(iChannel0, p, 0); return; }
        int rowOld = GRID_Y0 + (curLine % GRID_LINES);
        int rowNew = GRID_Y0 + ((curLine + 1) % GRID_LINES);
        if (wordWrap) {
            if (p.y == rowOld && p.x >= effWs) { O = vec4(0); return; }   // clear the moved word's old cells
            int Wp = curCol - effWs;
            if (p.y == rowNew && p.x < Wp) {                              // copy the word so far from the text ring
                int idx = (int(ctl4.y) + p.x) % RING_SIZE;
                vec4 r = texelFetch(iChannel0, ivec2(idx % 128, RING_Y0 + idx / 128), 0);
                O = vec4(r.x + 1.0, r.y, float(curLine + 1), 1.);
                return;
            }
            if (p.y == rowNew && p.x == Wp) { O = vec4(float(newTok + 1), d.y, float(curLine + 1), 1.); return; }
            O = texelFetch(iChannel0, p, 0);
            return;
        }
        // no relocation this frame: only the true cursor cell writes; wrap-zone bystanders keep their value
        if (p.x != curCol || p.y != rowOld) { O = texelFetch(iChannel0, p, 0); return; }
        O = vec4(float(newTok + 1), d.y, float(curLine), 1.);
        return;
    }
    O = vec4(d.x, d.y, float(t), 1.);   // ring
}
