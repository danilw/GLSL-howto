What is it: GLSL simple bots for GPU, look source code link to see how it work. Bots burn in ~2-3 min reason explained in code.
I made it just for fun.

original shader source code https://www.shadertoy.com/view/3dlSzs
launcher source code https://github.com/danilw/vulkan-shadertoy-launcher
https://twitter.com/AruGL


Control: use Mouse to scroll
Space to pause
Arrows to move block in player mode
Keys 0 1 2 3 to set demo mode (number of bots), 0 is default
Extra keys(WARNING!) 4 to 999k bots
(do not press!) 5 (requires 2Gb VRAM) create 5.5mil bots (scroll work correct, board ID display only last 6 digits of number)

Esc to exit


UI:
Yellow number total bots, Big left number is board ID, small right is score of board.
After 20 sec white number is number of remaining bots.
Scroll mouse(drag) on left or right side to scroll board, white scroll bars also work.


Launch options:
--demo <value> where value is 0 or 1 or 2 etc to boot demo mode on start (default 0)
--frame_delay <value> where value is any number>0(not 0) set Fence wait timer (seconds), that value is seconds to wait for frame (default 5) (max 99)


AMD Vulkan driver has bug and can not launch this shader. Bugreport send.
Launching it on external GPU has OS limitation, Windows ignore "WaitForFence" timer, so it crashed on too long frame time no matter what.
OpenGL launcher can be found on shadertoy link, or launch from webbrowser.

This shader work in Nvidia as expected, so best option to launch it is Nvidia.
