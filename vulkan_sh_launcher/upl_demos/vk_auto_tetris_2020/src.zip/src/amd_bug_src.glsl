

// original below
// this mod to avoid AMD bug

void initGlobals();
const vec4 _uva[5] = vec4[5](vec4(0.0, 2.0, 2.0, 2.0), vec4(2.0, 2.0, 2.0, 4.0), vec4(2.0, 4.0, 0.0, 4.0), vec4(0.0, 4.0, 0.0, 3.0), vec4(0.0, 3.0, 2.0, 3.0));
const vec4 _uvb[5] = vec4[5](vec4(0.0, 0.0, 0.0, 4.0), vec4(0.0, 4.0, 2.0, 4.0), vec4(2.0, 4.0, 2.0, 2.0), vec4(2.0, 2.0, 0.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvd[5] = vec4[5](vec4(2.0, 0.0, 2.0, 4.0), vec4(2.0, 4.0, 0.0, 4.0), vec4(0.0, 4.0, 0.0, 2.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uve[5] = vec4[5](vec4(2.0, 4.0, 0.0, 4.0), vec4(0.0, 4.0, 0.0, 2.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(2.0, 2.0, 2.0, 3.0), vec4(2.0, 3.0, 0.0, 3.0));
const vec4 _uvf[5] = vec4[5](vec4(2.0, 0.0, 1.0, 0.0), vec4(1.0, 0.0, 1.0, 4.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvh[5] = vec4[5](vec4(0.0, 0.0, 0.0, 4.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(2.0, 2.0, 2.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvi[5] = vec4[5](vec4(1.0, 1.0, 1.0, 1.0), vec4(1.0, 2.0, 1.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvk[5] = vec4[5](vec4(0.0, 0.0, 0.0, 4.0), vec4(0.0, 4.0, 2.0, 2.0), vec4(1.0, 3.0, 2.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvl[5] = vec4[5](vec4(1.0, 0.0, 1.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvn[5] = vec4[5](vec4(0.0, 4.0, 0.0, 2.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(2.0, 2.0, 2.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvo[5] = vec4[5](vec4(0.0, 2.0, 2.0, 2.0), vec4(2.0, 2.0, 2.0, 4.0), vec4(2.0, 4.0, 0.0, 4.0), vec4(0.0, 4.0, 0.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvp[5] = vec4[5](vec4(0.0, 6.0, 0.0, 2.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(2.0, 2.0, 2.0, 4.0), vec4(2.0, 4.0, 0.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvr[5] = vec4[5](vec4(0.0, 4.0, 0.0, 2.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvs[5] = vec4[5](vec4(2.0, 2.0, 0.0, 2.0), vec4(0.0, 2.0, 0.0, 3.0), vec4(0.0, 3.0, 2.0, 3.0), vec4(2.0, 3.0, 2.0, 4.0), vec4(2.0, 4.0, 0.0, 4.0));
const vec4 _uvt[5] = vec4[5](vec4(1.0, 0.0, 1.0, 4.0), vec4(1.0, 4.0, 2.0, 4.0), vec4(0.0, 2.0, 2.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvw[5] = vec4[5](vec4(0.0, 2.0, 0.0, 4.0), vec4(0.0, 4.0, 2.0, 4.0), vec4(1.0, 4.0, 1.0, 2.0), vec4(2.0, 4.0, 2.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvy[5] = vec4[5](vec4(0.0, 2.0, 0.0, 4.0), vec4(0.0, 4.0, 2.0, 4.0), vec4(2.0, 2.0, 2.0, 6.0), vec4(2.0, 6.0, 0.0, 6.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvTt[5] = vec4[5](vec4(0.0, 0.0, 2.0, 0.0), vec4(1.0, 0.0, 1.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvdot[5] = vec4[5](vec4(1.0, 4.0, 1.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uvminus[5] = vec4[5](vec4(0.0, 2.0, 2.0, 2.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uv0[5] = vec4[5](vec4(0.34999999, 0.0, -0.34999999, 4.0), vec4(2.0, 0.0, 1.3, 4.0), vec4(0.34999999, 0.0, 2.0, 0.0), vec4(-0.34999999, 4.0, 1.3, 4.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uv1[5] = vec4[5](vec4(0.0, 2.0, 1.65, 0.0), vec4(1.65, 0.0, 1.0, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uv2[5] = vec4[5](vec4(0.34999999, 0.0, 2.0, 0.0), vec4(2.0, 0.0, 1.65, 2.0), vec4(1.65, 2.0, 0.0, 2.0), vec4(0.0, 2.0, -0.34999999, 4.0), vec4(-0.34999999, 4.0, 1.3, 4.0));
const vec4 _uv3[5] = vec4[5](vec4(0.34999999, 0.0, 2.0, 0.0), vec4(1.65, 2.0, 0.0, 2.0), vec4(-0.34999999, 4.0, 1.3, 4.0), vec4(2.0, 0.0, 1.3, 4.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uv4[5] = vec4[5](vec4(0.0, 2.0, 0.34999999, 0.0), vec4(1.65, 2.0, 0.0, 2.0), vec4(2.0, 0.0, 1.3, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uv5[5] = vec4[5](vec4(0.34999999, 0.0, 2.0, 0.0), vec4(0.34999999, 0.0, 0.0, 2.0), vec4(1.65, 2.0, 0.0, 2.0), vec4(1.65, 2.0, 1.3, 4.0), vec4(-0.34999999, 4.0, 1.3, 4.0));
const vec4 _uv6[5] = vec4[5](vec4(0.0, 2.0, 1.0, 0.0), vec4(0.0, 2.0, -0.34999999, 4.0), vec4(-0.34999999, 4.0, 1.3, 4.0), vec4(1.65, 2.0, 1.3, 4.0), vec4(1.65, 2.0, 0.0, 2.0));
const vec4 _uv7[5] = vec4[5](vec4(0.34999999, 0.0, 2.0, 0.0), vec4(2.0, 0.0, 1.3, 4.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0), vec4(0.0, 0.0, 0.0, 0.0));
const vec4 _uv8[5] = vec4[5](vec4(0.34999999, 0.0, -0.34999999, 4.0), vec4(2.0, 0.0, 1.3, 4.0), vec4(0.34999999, 0.0, 2.0, 0.0), vec4(1.65, 2.0, 0.0, 2.0), vec4(-0.34999999, 4.0, 1.3, 4.0));
const vec4 _uv9[5] = vec4[5](vec4(0.34999999, 0.0, 2.0, 0.0), vec4(0.0, 2.0, 0.34999999, 0.0), vec4(1.65, 2.0, 0.0, 2.0), vec4(2.0, 0.0, 1.3, 4.0), vec4(-0.34999999, 4.0, 1.3, 4.0));
float _uminimum_distance(in vec2 _uv, in vec2 _uw, in vec2 _up){
float _ul2 = (((_uv.x - _uw.x) * (_uv.x - _uw.x)) + ((_uv.y - _uw.y) * (_uv.y - _uw.y)));
if ((_ul2 == 0.0))
{
return distance(_up, _uv);
}
float _ut = (dot((_up - _uv), (_uw - _uv)) / _ul2);
if ((_ut < 0.0))
{
return distance(_up, _uv);
}
else
{
if ((_ut > 1.0))
{
return distance(_up, _uw);
}
}
vec2 _uprojection = (_uv + (_ut * (_uw - _uv)));
return distance(_up, _uprojection);
}
float _utextColor(in vec2 _ufrom, in vec2 _uto, in vec2 _up){
(_up *= 15.0);
float _uinkNess = 0.0;
float _unearLine = 0.0;
(_unearLine = _uminimum_distance(_ufrom, _uto, _up));
(_uinkNess += smoothstep(0.0, 1.0, (1.0 - (14.0 * (_unearLine - 0.050000001)))));
(_uinkNess += smoothstep(0.0, 2.5, (1.0 - (_unearLine + 0.25))));
return _uinkNess;
}
vec2 _ugrid(in vec2 _up){
return vec2(((_up.x / 2.0) * 0.94999999), (1.0 - ((_up.y / 2.0) * 0.64999998)));
}
float _ucount = 0.0;
float _ugtime = 0.0;
float _ut(in vec2 _ufrom, in vec2 _uto, in vec2 _up){
(_ucount++);
if ((_ucount > (_ugtime * 20.0)))
{
return 0.0;
}
return _utextColor(_ugrid(_ufrom), _ugrid(_uto), _up);
}
float _ud = 0.0;
vec2 _up;
bool _uis_end = false;
bool _uis_act = false;
ivec2 _uimid = ivec2(2, 2);
ivec2 _uidx;
void _ut_t(in vec4 _uva[5], in float _ulcount){
if ((!_uis_end))
{
(_uis_act = (all(lessThanEqual(_uidx, (_uimid + ivec2(1, 1)))) && all(greaterThanEqual(_uidx, (_uimid - ivec2(1, 1))))));
}
if (((!_uis_end) && _uis_act))
{
for (int _ui = 0; (_ui < int(_ulcount)); (_ui++))
{
(_ud += _ut(_uva[int(clamp(float(_ui), 0.0, float(4)))].xy, _uva[int(clamp(float(_ui), 0.0, float(4)))].zw, _up));
}
(_uis_end = (any(greaterThan(_uidx, (_uimid + ivec2(1, 1)))) || any(lessThan(_uidx, (_uimid - ivec2(1, 1))))));
}
else
{
(_ucount += _ulcount);
}
(_up.x += -0.082999997);
(_uimid.x += 1);
}
float _uprint_num(in int _unum){
float _ud0 = _ud;
(_ud = 0.0);
int _upa[10] = int[10](-1, -1, -1, -1, -1, -1, -1, -1, -1, -1);
for (int _ux = 0; (_ux < 10); (_ux++))
{
if ((_unum < 1))
{
break;
}
int _utv = (_unum % 10);
switch (_utv) {
case (0):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 0);
break;
case (1):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 1);
break;
case (2):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 2);
break;
case (3):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 3);
break;
case (4):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 4);
break;
case (5):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 5);
break;
case (6):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 6);
break;
case (7):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 7);
break;
case (8):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 8);
break;
case (9):
(_upa[int(clamp(float((9 - _ux)), 0.0, float(9)))] = 9);
break;
}
(_unum /= 10);
}
for (int _ux = 0; (_ux < 10); (_ux++))
{
switch (_upa[int(clamp(float(_ux), 0.0, float(9)))]) {
case (0):
{
_ut_t(_uv0, 4.0);
}
break;
case (1):
{
_ut_t(_uv1, 2.0);
}
break;
case (2):
{
_ut_t(_uv2, 5.0);
}
break;
case (3):
{
_ut_t(_uv3, 4.0);
}
break;
case (4):
{
_ut_t(_uv4, 3.0);
}
break;
case (5):
{
_ut_t(_uv5, 5.0);
}
break;
case (6):
{
_ut_t(_uv6, 5.0);
}
break;
case (7):
{
_ut_t(_uv7, 2.0);
}
break;
case (8):
{
_ut_t(_uv8, 5.0);
}
break;
case (9):
{
_ut_t(_uv9, 5.0);
}
break;
}
}
float _udn = _ud;
(_ud = _ud0);
return _udn;
}
vec4 _uloadval3(in ivec2 _uipx){
return texelFetch(iChannel2, _uipx, 0);
}
vec4 _uload_pxid(){
return _uloadval3(ivec2(0, 1));
}
const int _ufont[10] = int[10](480599, 139810, 476951, 476999, 71028, 464711, 464727, 476228, 481111, 481095);
const int _upowers[7] = int[7](1, 10, 100, 1000, 10000, 100000, 1000000);
int _uPrintInt(in vec2 _uuv, in int _uvalue, const int _umaxDigits){
if ((abs((_uuv.y - 0.5)) < 0.5))
{
int _uiu = int(floor(_uuv.x));
if (((_uiu >= 0) && (_uiu < _umaxDigits)))
{
int _un = ((_uvalue / _upowers[int(clamp(float(((_umaxDigits - _uiu) - 1)), 0.0, float(6)))]) % 10);
(_uuv.x = fract(_uuv.x));
ivec2 _up = ivec2(floor((_uuv * vec2(4.0, 5.0))));
return ((_ufont[int(clamp(float(_un), 0.0, float(9)))] >> (_up.x + (_up.y * 4))) & 1);
}
}
return 0;
}
int _ugai(){
vec2 _uttsz = vec2(textureSize(iChannel0, 0)).xy;
return (int((_uttsz.x * _uttsz.y)) / 3);
}
void mainImage(out vec4 _ufragColor, in vec2 _ufragCoord){
(_ufragColor = vec4(0.0, 0.0, 0.0, 0.0));
vec2 _ures = (iResolution.xy / iResolution.y);
vec2 _uuv = ((_ufragCoord / iResolution.y) - (0.0 * _ures));
if ((_ugai() > 101))
{
if ((iTime > 19.0))
{
int _uival = int(_uload_pxid().y);
if ((_uival == 0))
{
float _uittm = _uload_pxid().z;
(_ugtime = (iTime - _uittm));
(_uuv = (_uuv - (0.5 * _ures)));
(_uuv *= 0.56999999);
(_uuv += vec2(0.37, 0.60000002));
vec2 _uguv = ((_uuv - vec2(0.082999997, 0.69999999)) * vec2(1.0, -1.0));
(_uguv *= vec2(12.048193, 6.6666665));
(_uguv += vec2(2.0, 2.5));
(_uidx = ivec2(_uguv));
vec2 _uop = (_uuv - vec2(0.082999997, 0.69999999));
(_up = _uop);
int _uivalx = int(_uload_pxid().x);
_ut_t(_uvTt, 2.0);
_ut_t(_uvh, 3.0);
_ut_t(_uve, 5.0);
(_up.x += -0.082999997);
(_uimid.x += 1);
_ut_t(_uve, 5.0);
_ut_t(_uvn, 3.0);
_ut_t(_uvd, 4.0);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
float _utx = _ud;
(_ud = 0.0);
_ut_t(_uvw, 4.0);
_ut_t(_uvi, 2.0);
_ut_t(_uvn, 3.0);
_ut_t(_uvn, 3.0);
_ut_t(_uve, 5.0);
_ut_t(_uvr, 2.0);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
float _utx2 = _ud;
(_ud = 0.0);
float _utx3 = _uprint_num(_uivalx);
(_utx = clamp((_utx * (0.75 + (sin((((_ufragCoord.x * 3.1415927) * 0.5) - (iTime * 4.3000002))) * 0.5))), 0.0, 1.0));
(_utx2 = clamp((_utx2 * (0.75 + (sin((((_ufragCoord.x * 3.1415927) * 0.5) - (iTime * 4.3000002))) * 0.5))), 0.0, 1.0));
(_utx3 = clamp((_utx3 * (0.75 + (sin((((_ufragCoord.x * 3.1415927) * 0.5) - (iTime * 4.3000002))) * 0.5))), 0.0, 1.0));
(_ufragColor = vec4((vec3(1.0, 0.60000002, 0.25999999) * _utx), _utx));
vec2 _uxy = (_ufragCoord.xy / iResolution.xy);
(_ufragColor += vec4((vec3(0.69999999, 0.86000001, 1.0) * _utx2), _utx2));
(_ufragColor += vec4((vec3(0.30700001, 0.53600001, 0.98000002) * _utx3), _utx3));
(_ufragColor.xyz *= (vec3(0.40000001, 0.40000001, 0.30000001) + (0.5 * pow(((((100.0 * _uxy.x) * _uxy.y) * (1.0 - _uxy.x)) * (1.0 - _uxy.y)), 0.40000001))));
(_ufragColor.w *= 0.5);
(_ufragColor.xyz = (2.0 * pow(_ufragColor.xyz, vec3(2.0, 2.0, 2.0))));
return ;
}
else
{
(_uuv = (_uuv - (0.5 * _ures)));
float _ugt = mod(iTime, 20.0);
float _utx = float(_uPrintInt(((_uuv * 7.0) + vec2(2.925, 0.62)), _uival, 6));
(_ufragColor = vec4((vec3(1.0, 1.0, 1.0) * _utx), _utx));
(_ufragColor.w *= (0.69999999 + ((0.30000001 * smoothstep(0.0, 1.0, _ugt)) * smoothstep(4.0, 3.0, _ugt))));
(_ufragColor.w *= 0.75);
return ;
}
}
}
if ((iTime > 10.0))
{
return ;
}
float _utime = mod(iTime, 21.0);
(_ugtime = _utime);
vec2 _uguv = ((_uuv - vec2(0.082999997, 0.69999999)) * vec2(1.0, -1.0));
(_uguv *= vec2(12.048193, 6.6666665));
(_uguv += vec2(2.0, 2.5));
(_uidx = ivec2(_uguv));
vec3 _ucol = vec3(0.0, 0.0, 0.0);
vec2 _uop = (_uuv - vec2(0.082999997, 0.69999999));
(_up = _uop);
float _udx = 0.0;
float _ud0 = 0.0;
float _udz = 0.0;
(_ugtime = (_ugtime * 1.5));
if ((_ugai() > 101))
{
_ut_t(_uvTt, 2.0);
_ut_t(_uve, 5.0);
_ut_t(_uvt, 3.0);
_ut_t(_uvr, 2.0);
_ut_t(_uvi, 2.0);
_ut_t(_uvs, 5.0);
(_up.x += -0.082999997);
(_uimid.x += 1);
_ut_t(_uvb, 4.0);
_ut_t(_uva, 5.0);
_ut_t(_uvt, 3.0);
_ut_t(_uvt, 3.0);
_ut_t(_uvl, 1.0);
_ut_t(_uve, 5.0);
_ut_t(_uvr, 2.0);
_ut_t(_uvo, 4.0);
_ut_t(_uvy, 4.0);
_ut_t(_uva, 5.0);
_ut_t(_uvl, 1.0);
_ut_t(_uve, 5.0);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
_ut_t(_uvf, 3.0);
_ut_t(_uvo, 4.0);
_ut_t(_uvr, 2.0);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_ud0 = _ud);
(_udx = _uprint_num(_ugai()));
(_up.x += -0.082999997);
(_uimid.x += 1);
(_ud = _ud0);
_ut_t(_uvb, 4.0);
_ut_t(_uvo, 4.0);
_ut_t(_uvt, 3.0);
_ut_t(_uvs, 5.0);
(_ud0 = _ud);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
(_ugtime = (_ugtime - 1.0));
(_ud = 0.0);
_ut_t(_uvs, 5.0);
_ut_t(_uvt, 3.0);
_ut_t(_uva, 5.0);
_ut_t(_uvr, 2.0);
_ut_t(_uvt, 3.0);
(_up.x += -0.082999997);
(_uimid.x += 1);
for (int _ui = 0; (_ui < 14); (_ui++))
{
_ut_t(_uvdot, 1.0);
}
(_udz = _ud);
(_ud = _ud0);
}
else
{
_ut_t(_uvk, 3.0);
_ut_t(_uve, 5.0);
_ut_t(_uvy, 4.0);
_ut_t(_uvs, 5.0);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
(_ud0 = _ud);
(_ud = 0.0);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
_ut_t(_uv1, 2.0);
(_udz += _ud);
(_ud = 0.0);
_ut_t(_uvminus, 1.0);
(_ud0 += _ud);
(_ud = 0.0);
_ut_t(_uv1, 2.0);
_ut_t(_uv2, 5.0);
_ut_t(_uv0, 4.0);
_ut_t(_uvk, 3.0);
(_udx += _ud);
(_ud = 0.0);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
_ut_t(_uv2, 5.0);
(_udz += _ud);
(_ud = 0.0);
_ut_t(_uvminus, 1.0);
(_ud0 += _ud);
(_ud = 0.0);
_ut_t(_uv3, 4.0);
_ut_t(_uv0, 4.0);
_ut_t(_uv0, 4.0);
_ut_t(_uvk, 3.0);
(_udx += _ud);
(_ud = 0.0);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
_ut_t(_uv3, 4.0);
(_udz += _ud);
(_ud = 0.0);
_ut_t(_uvminus, 1.0);
(_ud0 += _ud);
(_ud = 0.0);
_ut_t(_uv6, 5.0);
_ut_t(_uv9, 5.0);
_ut_t(_uv1, 2.0);
_ut_t(_uvk, 3.0);
(_udx += _ud);
(_up.x = _uop.x);
(_up.y += 0.15000001);
(_uimid.x = 2);
(_uimid.y += 1);
(_ud = 0.0);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
(_up.x += -0.082999997);
(_uimid.x += 1);
_ut_t(_uvdot, 1.0);
_ut_t(_uvdot, 1.0);
_ut_t(_uvdot, 1.0);
_ut_t(_uvo, 4.0);
_ut_t(_uvr, 2.0);
(_up.x += -0.082999997);
(_uimid.x += 1);
_ut_t(_uvp, 4.0);
_ut_t(_uvl, 1.0);
_ut_t(_uva, 5.0);
_ut_t(_uvy, 4.0);
_ut_t(_uvdot, 1.0);
_ut_t(_uvdot, 1.0);
_ut_t(_uvdot, 1.0);
(_ud0 += _ud);
(_ud = 0.0);
(_ugtime = (_ugtime - 1.0));
(_ud += _ud0);
}
(_ud = clamp(_ud, 0.0, 1.0));
(_udz = clamp(_udz, 0.0, 1.0));
(_udx = clamp(_udx, 0.0, 1.0));
(_ud = clamp((_ud * (0.75 + (sin((((_ufragCoord.x * 3.1415927) * 0.5) - (_utime * 4.3000002))) * 0.5))), 0.0, 1.0));
(_udz = clamp((_udz * (0.75 + (sin((((_ufragCoord.x * 3.1415927) * 0.5) - (_utime * 4.3000002))) * 0.5))), 0.0, 1.0));
(_udx = clamp((_udx * (0.75 + (sin((((_ufragCoord.x * 3.1415927) * 0.5) - (_utime * 4.3000002))) * 0.5))), 0.0, 1.0));
(_ucol = vec3(_ud, (_ud * 0.85000002), (_ud * 0.5)));
(_ucol += vec3((_udz * 2.0), (_udz * 0.85000002), (_udz * 0.85000002)));
(_ucol += vec3((_udx * 0.85000002), (_udx * 0.85000002), _udx));
vec2 _uxy = (_ufragCoord.xy / iResolution.xy);
(_ucol *= (vec3(0.40000001, 0.40000001, 0.30000001) + (0.5 * pow(((((100.0 * _uxy.x) * _uxy.y) * (1.0 - _uxy.x)) * (1.0 - _uxy.y)), 0.40000001))));
(_ufragColor = vec4(_ucol, min(max((_ud + _udx), _udz), 1.0)));
}
void initGlobals(){
(_up = vec2(0.0, 0.0));
(_uidx = ivec2(0, 0));
}


//const int play_o0=101; //keep player board till nuber of bots

//// base on https://www.shadertoy.com/view/XdXGRB
//// Source edited by David Hoskins - 2013.

//#define font_size 15.
//#define font_spacing .083
//#define font_spacing_y .15
//#define STROKEWIDTH 0.05
//#define PI 3.14159265359

//#define A_ vec2(0.,0.)
//#define Aa_ vec2(0.35,0.)
//#define B_ vec2(1.,0.)
//#define Ba_ vec2(1.65,0.)
//#define Bb_ vec2(.35,0.)
//#define C_ vec2(2.,0.)

////#define D_ vec2(0.,1.)
//#define E_ vec2(1.,1.)
////#define F_ vec2(2.,1.)

//#define G_ vec2(0.,2.)
//#define H_ vec2(1.,2.)
//#define I_ vec2(2.,2.)
//#define Ii_ vec2(1.65,2.)

//#define J_ vec2(0.,3.)
//#define K_ vec2(1.,3.)
//#define L_ vec2(2.,3.)

//#define M_ vec2(0.,4.)
//#define Mm_ vec2(-0.35,4.)
//#define N_ vec2(1.,4.)
//#define O_ vec2(2.,4.)
//#define Oo_ vec2(1.3,4.)

////#define P_ vec2(0.,5.)
////#define Q_ vec2(1.,5.)
////#define R_ vec2(1.,5.)

//#define S_ vec2(0.,6.)
//#define T_ vec2(1.,6.)
//#define U_ vec2(2.0,6.)

////needed to make short code
//#define _sz 1
//#define _logic_fn all(lessThanEqual(idx,imid+ivec2(1)*_sz))&&all(greaterThanEqual(idx,imid-ivec2(1)*_sz))
//#define _logic_fn2 any(greaterThan(idx,imid+ivec2(1)*_sz))||any(lessThan(idx,imid-ivec2(1)*_sz))

//const vec4[5] va=vec4[](vec4(G_,I_),vec4(I_,O_),vec4(O_,M_),vec4(M_,J_),vec4(J_,L_));
//const vec4[5] vb=vec4[](vec4(A_,M_),vec4(M_,O_),vec4(O_,I_),vec4(I_,G_),vec4(0));
//const vec4[5] vc=vec4[](vec4(I_,G_),vec4(G_,M_),vec4(M_,O_),vec4(0),vec4(0));
//const vec4[5] vd=vec4[](vec4(C_,O_),vec4(O_,M_),vec4(M_,G_),vec4(G_,I_),vec4(0));
//const vec4[5] ve=vec4[](vec4(O_,M_),vec4(M_,G_),vec4(G_,I_),vec4(I_,L_),vec4(L_,J_));
//const vec4[5] vf=vec4[](vec4(C_,B_),vec4(B_,N_),vec4(G_,I_),vec4(0),vec4(0));
//const vec4[5] vg=vec4[](vec4(O_,M_),vec4(M_,G_),vec4(G_,I_),vec4(I_,U_),vec4(U_,S_));
//const vec4[5] vh=vec4[](vec4(A_,M_),vec4(G_,I_),vec4(I_,O_),vec4(0),vec4(0));
//const vec4[5] vi=vec4[](vec4(E_,E_),vec4(H_,N_),vec4(0),vec4(0),vec4(0));
//const vec4[5] vj=vec4[](vec4(E_,E_),vec4(H_,T_),vec4(T_,S_),vec4(0),vec4(0));
//const vec4[5] vk=vec4[](vec4(A_,M_),vec4(M_,I_),vec4(K_,O_),vec4(0),vec4(0));
//const vec4[5] vl=vec4[](vec4(B_,N_),vec4(0),vec4(0),vec4(0),vec4(0));
//const vec4[5] vm=vec4[](vec4(M_,G_),vec4(G_,I_),vec4(H_,N_),vec4(I_,O_),vec4(0));
//const vec4[5] vn=vec4[](vec4(M_,G_),vec4(G_,I_),vec4(I_,O_),vec4(0),vec4(0));
//const vec4[5] vo=vec4[](vec4(G_,I_),vec4(I_,O_),vec4(O_,M_),vec4(M_,G_),vec4(0));
//const vec4[5] vp=vec4[](vec4(S_,G_),vec4(G_,I_),vec4(I_,O_),vec4(O_,M_),vec4(0));
//const vec4[5] vq=vec4[](vec4(U_,I_),vec4(I_,G_),vec4(G_,M_),vec4(M_,O_),vec4(0));
//const vec4[5] vr=vec4[](vec4(M_,G_),vec4(G_,I_),vec4(0),vec4(0),vec4(0));
//const vec4[5] vs=vec4[](vec4(I_,G_),vec4(G_,J_),vec4(J_,L_),vec4(L_,O_),vec4(O_,M_));
//const vec4[5] vt=vec4[](vec4(B_,N_),vec4(N_,O_),vec4(G_,I_),vec4(0),vec4(0));
//const vec4[5] vu=vec4[](vec4(G_,M_),vec4(M_,O_),vec4(O_,I_),vec4(0),vec4(0));
//const vec4[5] vv=vec4[](vec4(G_,J_),vec4(J_,N_),vec4(N_,L_),vec4(L_,I_),vec4(0));
//const vec4[5] vw=vec4[](vec4(G_,M_),vec4(M_,O_),vec4(N_,H_),vec4(O_,I_),vec4(0));
//const vec4[5] vx=vec4[](vec4(G_,O_),vec4(I_,M_),vec4(0),vec4(0),vec4(0));
//const vec4[5] vy=vec4[](vec4(G_,M_),vec4(M_,O_),vec4(I_,U_),vec4(U_,S_),vec4(0));
//const vec4[5] vz=vec4[](vec4(G_,I_),vec4(I_,M_),vec4(M_,O_),vec4(0),vec4(0));

//const vec4[5] vTt=vec4[](vec4(A_,C_),vec4(B_,N_),vec4(0),vec4(0),vec4(0));

//const vec4[5] vdot=vec4[](vec4(N_,N_),vec4(0),vec4(0),vec4(0),vec4(0));
//const vec4[5] vminus=vec4[](vec4(G_,I_),vec4(0),vec4(0),vec4(0),vec4(0));

//const vec4[5] v0=vec4[](vec4(Aa_,Mm_),vec4(C_,Oo_),vec4(Aa_,C_),vec4(Mm_,Oo_),vec4(0));
//const vec4[5] v1=vec4[](vec4(G_,Ba_),vec4(Ba_,N_),vec4(0),vec4(0),vec4(0));
//const vec4[5] v2=vec4[](vec4(Aa_,C_),vec4(C_,Ii_),vec4(Ii_,G_),vec4(G_,Mm_),vec4(Mm_,Oo_));

//const vec4[5] v3=vec4[](vec4(Aa_,C_),vec4(Ii_,G_),vec4(Mm_,Oo_),vec4(C_,Oo_),vec4(0));
//const vec4[5] v4=vec4[](vec4(G_,Bb_),vec4(Ii_,G_),vec4(C_,Oo_),vec4(0),vec4(0));
//const vec4[5] v5=vec4[](vec4(Aa_,C_),vec4(Aa_,G_),vec4(Ii_,G_),vec4(Ii_,Oo_),vec4(Mm_,Oo_));

//const vec4[5] v6=vec4[](vec4(G_,B_),vec4(G_,Mm_),vec4(Mm_,Oo_),vec4(Ii_,Oo_),vec4(Ii_,G_));
//const vec4[5] v7=vec4[](vec4(Aa_,C_),vec4(C_,Oo_),vec4(0),vec4(0),vec4(0));
//const vec4[5] v8=vec4[](vec4(Aa_,Mm_),vec4(C_,Oo_),vec4(Aa_,C_),vec4(Ii_,G_),vec4(Mm_,Oo_));

//const vec4[5] v9=vec4[](vec4(Aa_,C_),vec4(G_,Bb_),vec4(Ii_,G_),vec4(C_,Oo_),vec4(Mm_,Oo_));

//#define _a t_t(va,5.);
//#define _b t_t(vb,4.);
//#define _c t_t(vc,3.);
//#define _d t_t(vd,4.);
//#define _e t_t(ve,5.);
//#define _f t_t(vf,3.);
//#define _g t_t(vg,5.);
//#define _h t_t(vh,3.);
//#define _i t_t(vi,2.);
//#define _j t_t(vj,3.);
//#define _k t_t(vk,3.);
//#define _l t_t(vl,1.);
//#define _m t_t(vm,4.);
//#define _n t_t(vn,3.);
//#define _o t_t(vo,4.);
//#define _p t_t(vp,4.);
//#define _q t_t(vq,4.);
//#define _r t_t(vr,2.);
//#define _s t_t(vs,5.);
//#define _t t_t(vt,3.);
//#define _u t_t(vu,3.);
//#define _v t_t(vv,4.);
//#define _w t_t(vw,4.);
//#define _x t_t(vx,2.);
//#define _y t_t(vy,4.);
//#define _z t_t(vz,3.);
//#define _dot t_t(vdot,1.);
//#define _minus t_t(vminus,1.);

//#define _T t_t(vTt,2.);

//#define _1 t_t(v1,2.);
//#define _2 t_t(v2,5.);
//#define _3 t_t(v3,4.);
//#define _4 t_t(v4,3.);
//#define _5 t_t(v5,5.);
//#define _6 t_t(v6,5.);
//#define _7 t_t(v7,2.);
//#define _8 t_t(v8,5.);
//#define _9 t_t(v9,5.);
//#define _0 t_t(v0,4.);


////space etc
//#define add p.x += -font_spacing;imid.x+=1*_sz;
//#define space add;
//#define newline p.x = op.x;p.y += font_spacing_y;imid.x=oimid.x;imid.y+=1*_sz;

//#define caret_origin vec2(font_spacing, .7)


////-----------------------------------------------------------------------------------
//float minimum_distance(vec2 v, vec2 w, vec2 p)
//{
    //float l2 = (v.x - w.x)*(v.x - w.x) + (v.y - w.y)*(v.y - w.y);
    //if (l2 == 0.0) {
        //return distance(p, v);
    //}
    //float t = dot(p - v, w - v) / l2;
    //if(t < 0.0) {
        //return distance(p, v);
    //} else if (t > 1.0) {
        //return distance(p, w);
    //}
    //vec2 projection = v + t * (w - v);
    //return distance(p, projection);
//}

////-----------------------------------------------------------------------------------
//float textColor(vec2 from, vec2 to, vec2 p)
//{
    //p *= font_size;
    //float inkNess = 0., nearLine, corner;
    //nearLine = minimum_distance(from,to,p); 
    //inkNess += smoothstep(0., 1., 1.- 14.*(nearLine - STROKEWIDTH));
    //inkNess += smoothstep(0., 2.5, 1.- (nearLine  + 5. * STROKEWIDTH)); 
    //return inkNess;
//}

//vec2 grid(vec2 p){return ( vec2( (p.x / 2.) * .95 , 1.0-((p.y / 2.) * .65) ));}

//float count = 0.0;
//float gtime=0.;

//float t(vec2 from, vec2 to, vec2 p)
//{
    //count++;
    //if (count > gtime*20.0) return 0.0;
    //return textColor(grid(from), grid(to), p);
//}

//float d=0.;
//vec2 p;
//bool is_end=false;
//bool is_act=false;
//const ivec2 oimid=ivec2(2,2)*_sz;
//ivec2 imid=oimid,idx;

//void t_t(vec4[5] va, float lcount){
    //if(!is_end){is_act=_logic_fn;}
        //if((!is_end)&&is_act){
            //for(int i=0;i<int(lcount);i++){
                //d+=t(va[i].xy,va[i].zw,p);
            //}
            //is_end=_logic_fn2;
        //} else{count+=lcount;};add;
//}

//float print_num(int num){
    //float d0=d;
    //d=0.;
    //int pa[10]=int[](-1,-1,-1,-1,-1,-1,-1,-1,-1,-1);
    //for (int x=0;x<10;x++) {
        //if(num < 1)break;
        //int tv=(num%10);
        //switch(tv){
            //case 0: pa[9-x]=0;break;
            //case 1: pa[9-x]=1;break;
            //case 2: pa[9-x]=2;break;
            //case 3: pa[9-x]=3;break;
            //case 4: pa[9-x]=4;break;
            //case 5: pa[9-x]=5;break;
            //case 6: pa[9-x]=6;break;
            //case 7: pa[9-x]=7;break;
            //case 8: pa[9-x]=8;break;
            //case 9: pa[9-x]=9;break;
        //}
        //num /= 10;
    //}
    //for (int x=0;x<10;x++) {
        //switch(pa[x]){
            //case 0: {_0;};break;
            //case 1: {_1;};break;
            //case 2: {_2;};break;
            //case 3: {_3;};break;
            //case 4: {_4;};break;
            //case 5: {_5;};break;
            //case 6: {_6;};break;
            //case 7: {_7;};break;
            //case 8: {_8;};break;
            //case 9: {_9;};break;
        //}
    //}
    //float dn=d;
    //d=d0;
    //return dn;
//}

//vec4 loadval3(ivec2 ipx) {
    //return texelFetch(iChannel2, ipx, 0);
//}

//vec4 load_pxid() {
    //return loadval3(ivec2(0, 1));
//}

//const int[] font = int[](0x75557, 0x22222, 0x74717, 0x74747, 0x11574, 0x71747, 0x71757, 0x74444, 0x75757, 0x75747);
//const int[] powers = int[](1, 10, 100, 1000, 10000, 100000, 1000000);

//int PrintInt( in vec2 uv, in int value, const int maxDigits )
//{
    //if( abs(uv.y-0.5)<0.5 )
    //{
        //int iu = int(floor(uv.x));
        //if( iu>=0 && iu<maxDigits )
        //{
            //int n = (value/powers[maxDigits-iu-1]) % 10;
            //uv.x = fract(uv.x);//(uv.x-float(iu)); 
            //ivec2 p = ivec2(floor(uv*vec2(4.0,5.0)));
            //return (font[n] >> (p.x+p.y*4)) & 1;
        //}
    //}
    //return 0;
//}

//int gai() {
    //vec2 ttsz=vec2(textureSize(iChannel0,0)).xy;
    //return int((ttsz.x * ttsz.y)) / 3;
//}

//void mainImage( out vec4 fragColor, in vec2 fragCoord )
//{
    //fragColor=vec4(0.);
    //vec2 res=(iResolution.xy / iResolution.y);
    //vec2 uv=fragCoord/iResolution.y-0.*res;
    //if(gai()>play_o0){
    //if(iTime>19.){ //19
        //int ival=int(load_pxid().y);
        //if(ival==0){
            //float ittm=load_pxid().z;
            //gtime = iTime-ittm;
            //const float zzv=0.57;
            //uv=uv-0.5*res;
            //uv*=zzv;
            //uv+=vec2(0.37,0.6);
            //vec2 guv=(uv-caret_origin)*vec2(1.,-1.);
            //guv*=1./vec2(font_spacing,font_spacing_y)*float(_sz);
            //guv+=vec2(2.,2.5)*float(_sz);
            //idx=ivec2(guv); //id start from 2, 2 is first line and simbol (*_sz)
            //vec2 op = (uv-caret_origin);
            //p = op;
            //int ivalx=int(load_pxid().x);
            //_T _h _e space _e _n _d;
            //newline;
            //float tx=d;
            //d=0.;
            //_w _i _n _n _e _r;
            //newline;
            //float tx2=d;
            //d=0.;
            //float tx3=print_num(ivalx);
            //tx=clamp(tx* (.75+sin(fragCoord.x*PI*.5-iTime*4.3)*.5), 0.0, 1.0);
            //tx2=clamp(tx2* (.75+sin(fragCoord.x*PI*.5-iTime*4.3)*.5), 0.0, 1.0);
            //tx3=clamp(tx3* (.75+sin(fragCoord.x*PI*.5-iTime*4.3)*.5), 0.0, 1.0);
            //fragColor=vec4(vec3(1.,0.6,0.26)*tx,tx);
            //vec2 xy = fragCoord.xy / iResolution.xy;

            //fragColor+=vec4(vec3(.7,0.86,01.)*tx2,tx2);
            //fragColor+=vec4(vec3(.307,0.536,0.980)*tx3,tx3);
            //fragColor.rgb *= vec3(.4, .4, .3) + 0.5*pow(100.0*xy.x*xy.y*(1.0-xy.x)*(1.0-xy.y), .4 );    
            //fragColor.a*=0.5;
            //fragColor.rgb=2.*pow(fragColor.rgb,vec3(2.));
            //return;
        //}else{
            //uv=uv-0.5*res;
            //float gt=mod(iTime,20.);
            //float tx=float(PrintInt(uv*7.+vec2(05.85*.5,-0.38+1.),ival,6));
            //fragColor=vec4(vec3(1.)*tx,tx);
            //fragColor.a*=(0.7+0.3*smoothstep(.0,1.,gt)*smoothstep(4.,3.,gt));
            //fragColor.a*=0.75;
            //return;
        //}
    //}
    //}
    //if(iTime>10.)return;
    //float time = mod(iTime, 21.0);
    //gtime = time;

    //vec2 guv=(uv-caret_origin)*vec2(1.,-1.);
    //guv*=1./vec2(font_spacing,font_spacing_y)*float(_sz);
    //guv+=vec2(2.,2.5)*float(_sz);
    //idx=ivec2(guv); //id start from 2, 2 is first line and simbol (*_sz)

    //vec3 col = vec3(0.);
    //vec2 op = uv-caret_origin;
    //p = op;

    //float dx=0.;
    //float d0=0.;
    //float dz=0.;
    //gtime=gtime*1.5;
    //if(gai()>play_o0){
        //_T _e _t _r _i _s space _b _a _t _t _l _e _r _o _y _a _l _e;
        //newline;
        //_f _o _r space;
        //d0=d;
        //dx=print_num(gai());space;
        //d=d0;
        //_b _o _t _s;
        //d0=d;
        //newline;
        //gtime=gtime-1.;
        //d=0.;
        //_s _t _a _r _t space;
        //for(int i=0;i<14;i++){_dot}

        //dz=d;
        //d=d0;
    //}else{
        //_k _e _y _s
        //newline;
        //d0=d;
        //d=0.;
        //space space space _1 ;dz+=d;d=0.;_minus;d0+=d;d=0.;
        //_1 _2 _0 _k;
        //dx+=d;
        //d=0.;
        //newline;
        //space space space _2 ;dz+=d;d=0.;_minus;d0+=d;d=0.;
        //_3 _0 _0 _k;
        //dx+=d;
        //d=0.;
        //newline;
        //space space space _3 ;dz+=d;d=0.;_minus;d0+=d;d=0.;
        //_6 _9 _1 _k;
        //dx+=d;
        //newline;
        //d=0.;
        //space space space _dot _dot _dot _o _r space _p _l _a _y _dot _dot _dot;
        //d0+=d;d=0.;
        //gtime=gtime-1.;
        //d+=d0;
    //}
    //d=clamp(d,0.,1.);
    //dz=clamp(dz,0.,1.);
    //dx=clamp(dx,0.,1.);
    //d = clamp(d* (.75+sin(fragCoord.x*PI*.5-time*4.3)*.5), 0.0, 1.0); //yellow
    //dz = clamp(dz* (.75+sin(fragCoord.x*PI*.5-time*4.3)*.5), 0.0, 1.0); //red
    //dx = clamp(dx* (.75+sin(fragCoord.x*PI*.5-time*4.3)*.5), 0.0, 1.0); //white
    ////col = vec3(d*.5, d, d*.85);
    //col = vec3(d, d*0.85, d*.5);
    //col += vec3(dz*02., dz*0.85, dz*.85);
    //col += vec3(dx*0.85, dx*0.85, dx);
    //vec2 xy = fragCoord.xy / iResolution.xy;
    //col *= vec3(.4, .4, .3) + 0.5*pow(100.0*xy.x*xy.y*(1.0-xy.x)*(1.0-xy.y), .4 );  
    //fragColor = vec4( col, min(max(d+dx,dz),1.));
    ////vec2 uv = (fragCoord.xy) / iResolution.y - res/2.0;
    ////fragColor = vec4( text_playex(r()*10.));
//}
