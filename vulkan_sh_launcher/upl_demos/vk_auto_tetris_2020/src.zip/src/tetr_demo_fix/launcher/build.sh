#!/bin/sh

gcc -DVK_USE_PLATFORM_XCB_KHR -DYARIV_SHADER -Os -s -fdata-sections -ffunction-sections -Wl,--gc-sections ../vk_utils/vk_utils.c ../vk_utils/vk_error_print.c ../vk_utils/vk_render_helper.c main.c -o VKglsl_at -lm -lxcb -lxcb-keysyms -lvulkan
