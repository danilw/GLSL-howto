//https://www.shadertoy.com/view/tsXyDH

void AMD_loop_bug() {
    for (int k = 0 ; k < 1; k++) {
        for (int i = 0 ; i < 1; i++) {
            
            if(i<1000)break; //FIRST part of bug
            
            for (int j = 0 ; j < 1; j++) {
                if (true)return; //SECOND part of bug
            }
        }
        if (true)break; //THIRD part of bug, comment any of parts and bug gone
    }
}

void mainImage(out vec4 fragColor, in vec2 fragCoord) {
    fragColor = vec4(.5); //grey color output
    AMD_loop_bug(); //bug
}
