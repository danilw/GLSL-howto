#version 450

#extension GL_ARB_separate_shader_objects: enable
#extension GL_ARB_shading_language_420pack: enable
#extension GL_GOOGLE_include_directive : enable

layout (location = 0) in vec2 frag_pos;

layout (push_constant) uniform push_constants
{
    uint ival[32];
} constants;

layout (location = 0) out vec4 out_color;

#define iResolution vec2(1920.,1080.)
#define bitsx (constants.ival)

void main2()
{
    int i=0;
    if(i==0)return;
    else return;
    // BUG ??? I have no idea how and why it work, it work only with loop(while or for)
    for (int i=0; i < 1; i++) {
    }
    return;
}

void main()
{
    vec4 uFragColor=vec4(0.);
    main2();
    out_color=uFragColor;
}
