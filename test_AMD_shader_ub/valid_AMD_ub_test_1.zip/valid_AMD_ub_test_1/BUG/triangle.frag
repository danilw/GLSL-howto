#version 450

layout (location = 0) in vec3 inColor;

layout (location = 0) out vec4 outFragColor;

float main2(int a)
{
    int i=a;
    if(i==0)return 0.;
    else return 1.;
    for (int i=0; i < 1; i++) {
        a++;
    }
    return float(a);
}

void main() 
{
  outFragColor = vec4(inColor, 1.0);
  outFragColor.r=main2(1);
}
