code from https://github.com/SaschaWillems/Vulkan/blob/master/examples/triangle/triangle.cpp
NOT CHANGED 1:1

NO_BUG no changes work on AMD

BUG does not work on AMD, only change is added

void main2()
{
    int i=0;
    if(i==0)return;
    else return;
    for (int i=0; i < 1; i++) {
    }
    return;
}

to triangle.frag
