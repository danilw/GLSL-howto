#version 450

layout (location = 0) in vec3 inColor;

layout (location = 0) out vec4 outFragColor;

void main2()
{
    int i=0;
    if(i==0)return;
    else return;
    for (int i=0; i < 1; i++) {
    }
    return;
}

void main() 
{
  outFragColor = vec4(inColor, 1.0);
  main2();
}
