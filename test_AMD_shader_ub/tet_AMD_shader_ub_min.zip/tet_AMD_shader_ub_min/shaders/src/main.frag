#version 450

#extension GL_ARB_separate_shader_objects: enable
#extension GL_ARB_shading_language_420pack: enable
#extension GL_GOOGLE_include_directive : enable

layout (location = 0) in vec2 frag_pos;

layout (push_constant) uniform push_constants
{
    uint ival[32];
} constants;

layout (location = 0) out vec4 out_color;

#define iResolution vec2(1920.,1080.)
#define bits (constants.ival)


void mainImage( out vec4 fragColor, in vec2 fragCoord );

void main()
{
    vec4 uFragColor=vec4(0.);
    vec2 fragCoord=(frag_pos.xy/2.+vec2(0.5,0.5));
    fragCoord.y=1.-fragCoord.y;
    fragCoord=floor(iResolution.xy*fragCoord)+0.5;
    mainImage(uFragColor,fragCoord);
    out_color=uFragColor;
}

float main2(in vec2 fragCoord)
{
    fragCoord=fragCoord/iResolution.xy;
    fragCoord=floor(vec2(256.,2.)*fragCoord)+0.5;
    ivec2 ipx=ivec2(fragCoord);
    if(ipx.x<0)return 0.; //just to be "sure"
    if(ipx.x<128)
    if((bits[ipx.x%2])==0x77777777u)return 1.;else return 0.; //bug
    else
    if(((ipx.x%2==0)?bits[0]:bits[1])==0x77777777u)return 1.;else return 0.; //no bug
}

void mainImage( out vec4 fragColor, in vec2 fragCoord )
{
    fragColor=vec4(0.);
    fragColor.r+=main2(fragCoord)*0.5;
}
