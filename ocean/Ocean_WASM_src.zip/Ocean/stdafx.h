#pragma once

#define GL_GLEXT_PROTOTYPES
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <string>
#include <cmath>
#include <iostream>

#include <cstdarg>
#include <vector>

#include <iomanip>
#include <fstream>
#include <sstream>
#include <memory>
#include <map>
