#include "stdafx.h"
#include "Config.h"
#include "Shader.h"
#include "Complex.h"
#include "Vector.h"
#include "FFT.h"
#include "Ocean.h"
#include "WorldPosition.h"
#include "FPSCounter.h"

#include "emscripten/html5.h"
#include <emscripten.h>
#include <random>

static const unsigned int Width  = 1280;
static const unsigned int Height = 720;

static const char Title[] = "Ocean Simulation";

static const char ConfigFile[] = "data/ocean.cfg";

const GLfloat White[4] = {1.f, 1.f, 1.f, 1.f};

/*****************************************************************************
 * Main variables
 ****************************************************************************/
bool gFullscreen;

int gWindowWidth, gWindowHeight;
float gScaleX, gScaleY;

FPSCounter gFPSCounter;

bool gShowHelp;
Position gPosition;

Ocean gOcean;
double gElapsedTime;
float gWindAmp;
Vector2 gWindDir;

glm::vec3 gLightPosition;
glm::mat4 gProjection, gView, gModel;

GEOMETRY_TYPE gGeometryType;
static const char * const GeometryTypeNames[] = {
    "Wireframe",
    "Surface"
};

/*****************************************************************************
 * Graphics functions
 ****************************************************************************/
bool Init() {
    srand(time(0));

    std::cout << "OpenGL Renderer  : " << glGetString(GL_RENDERER) << std::endl; 
    std::cout << "OpenGL Vendor    : " << glGetString(GL_VENDOR) << std::endl;
    std::cout << "OpenGL Version   : " << glGetString(GL_VERSION) << std::endl;
    std::cout << "GLSL Version     : " << glGetString(GL_SHADING_LANGUAGE_VERSION) << std::endl;

    // Load config file
    Config config;
    config.Load(ConfigFile);

    float windAmp;
    if (!config.Get("waveAmplitude", windAmp)) windAmp = 2e-5f;

    float windDirX, windDirZ;
    if (!config.Get("windDirX",      windDirX)) windDirX = 0.f;
    if (!config.Get("windDirZ",      windDirZ)) windDirZ = 12.f;

    int oceanRepeat, oceanSize;
    float oceanLen;
    if (!config.Get("oceanSize",   oceanSize))   oceanSize = 64;
    if (!config.Get("oceanLen",    oceanLen))    oceanLen = 640.f;
    if (!config.Get("oceanRepeat", oceanRepeat)) oceanRepeat = 10;

    // Ocean setup
    std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<int> uni(0, 1000);
    int cx = uni(rng);
    windDirZ+=20.f*((500.f-cx)/1000.f);
    windDirZ=std::abs(windDirZ);
    gGeometryType = GEOMETRY_SOLID;
    if (gOcean.init(oceanSize, windAmp, Vector2(windDirX, windDirZ),
        oceanLen, oceanRepeat) <= 0) {
        return false;
    }
    gOcean.geometryType(gGeometryType);
    
    // Other configurstions
    gFullscreen = false;
    gShowHelp = true;

    gWindowWidth = Width;
    gWindowHeight = Height;
    gScaleX = 2.f / (float)Width;
    gScaleY = 2.f / (float)Height;
    gPosition.resize_screen(Width, Height);

    gElapsedTime = 0.0;

    gProjection = glm::perspective(45.0f, (float)Width / (float)Height, 0.1f, 3000.0f);
    gView       = glm::mat4(1.0f);
    gModel      = glm::mat4(1.0f);

    gPosition.set_position(
        glm::vec3(0.0f, 100.0f, 0.0f), // Position
        glm::vec3(2.4f, -0.3f, 0.0f)); // Look angle

    gLightPosition = glm::vec3(gPosition.position.x + 1000.0, 100.0, gPosition.position.z - 1000.0);

    // Set up OpenGL flags
    //glShadeModel(GL_SMOOTH);

    // glClearColor(0.55f, 0.55f, 0.55f, 1.0f);
    glClearColor(0., 0.35, 0.65, 1.0);
    glClearDepth(1.0);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);

    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

    return true;
}

void Deinit() {
    gOcean.release();
}

void Error(int /*error*/, const char* description) {
    std::cout << "Error: " << description << std::endl;
}

/*****************************************************************************
 * GLUT Callback functions
 ****************************************************************************/
void Display() {
    gFPSCounter.update(glfwGetTime());

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    gView = glm::lookAt(gPosition.position, gPosition.position + gPosition.lookat, gPosition.up);

    gOcean.geometryType(gGeometryType);
    gOcean.render(gElapsedTime, gLightPosition, gProjection, gView, gModel, true);

	//std::cout << std::to_string(gFPSCounter.fps) << std::endl;
	
}

void Reshape(GLFWwindow* /*window*/, int width, int height) {
    glViewport(0, 0, width, height);
    gWindowWidth = width;
    gWindowHeight = height;
    gScaleX = 2.f / (float)width;
    gScaleY = 2.f / (float)height;
    gPosition.resize_screen(width, height);
}

void Keyboard(GLFWwindow* window, int key, int /*scancode*/, int action, int /*mods*/) {
    if (action == GLFW_PRESS) {
        switch (key) {
        case GLFW_KEY_ESCAPE:
            //glfwSetWindowShouldClose(window, GLFW_TRUE);
            break;

        case GLFW_KEY_F:
            gFullscreen = !gFullscreen;
            if (gFullscreen) {
                emscripten_run_script("fullscreen()");
            } else {
                EMSCRIPTEN_RESULT ret = emscripten_exit_fullscreen();
            }
            break;

        case GLFW_KEY_1:
            gGeometryType = GEOMETRY_LINES;
            break;

        case GLFW_KEY_2:
            gGeometryType = GEOMETRY_SOLID;
            break;
        }
    }
}

void MousePosition(GLFWwindow* window, double x, double y) {
    static bool warp = false;

    if (!warp) {
        gPosition.set_mouse_point(x, y);
        //glfwSetCursorPos(window, gWindowWidth / 2, gWindowHeight / 2);
        warp = true;
    } else {
        warp = false;
    }
}

void hidecanvas() {

    emscripten_run_script("document.getElementById('spinner').hidden = false;document.getElementById('imloader').style.display=\"\"");
}

void displaycanvas() {

    emscripten_run_script("resize_glfw_wasm()");
    emscripten_run_script("document.getElementById('spinner').hidden = true;document.getElementById('imloader').style.display=\"none\"");
}

bool once_f=false;
void Update(GLFWwindow* window) {
    static double last_time = 0.0;
    double t = glfwGetTime();
    double dt = t - last_time;
    last_time = t;

    gElapsedTime += dt * 02.5;

    if ((glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)||(glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)) {
        gPosition.move_forward(dt);
    }
    if ((glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)||(glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)) {
        gPosition.move_back(dt);
    }
    if ((glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)||(glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)) {
        gPosition.move_left(dt);
    }
    if ((glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)||(glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)) {
        gPosition.move_right(dt);
    }
    if (glfwGetKey(window, GLFW_KEY_PAGE_UP) == GLFW_PRESS) {
        gPosition.move_up(dt);
    }
    if (glfwGetKey(window, GLFW_KEY_PAGE_DOWN) == GLFW_PRESS) {
        gPosition.move_down(dt);
    }

    gLightPosition = glm::vec3(gPosition.position.x + 1000.0,
        100.0, gPosition.position.z - 1000.0);
    if((t>1.)&&(!once_f)){once_f=true;displaycanvas();}
}

GLFWwindow *window;

void mainloop() {
   Display();

   Update(window);

   glfwSwapBuffers(window);
   glfwPollEvents();
}

int main(int /*argc*/, char** /*argv*/) {
    int status = EXIT_SUCCESS;
    hidecanvas();

    glfwSetErrorCallback(Error);

    if (!glfwInit()) {
        std::cout << "Failed to load GLFW" << std::endl;
        return EXIT_FAILURE;
    }

    std::cout << "Init window context with OpenGL 3.0" << std::endl;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);
    window = glfwCreateWindow(Width, Height, Title, nullptr, nullptr);
    if (!window) {
        std::cout << "Unable to Create OpenGL 3.0 Context" << std::endl;
        status = EXIT_FAILURE;
        goto finish;
    }

    glfwSetKeyCallback(window, Keyboard);
    //glfwSetInputMode(window, GLFW_STICKY_KEYS, GLFW_TRUE);

    glfwSetCursorPosCallback(window, MousePosition);
    //glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);

    glfwSetWindowSizeCallback(window, Reshape);

    glfwMakeContextCurrent(window);
    //gladLoadGL();

    if (!Init()) {
        std::cout << "Initialization failed" << std::endl;
        status = EXIT_FAILURE;
        goto finish;
    }
    
    std::cout << std::endl << std::endl << "Controls :" << std::endl;
    std::cout << "1,2 render mode, W/A/S/D movement, PgDown/PgUp move camera, F fullscreen" << std::endl << std::endl;
    
    emscripten_set_main_loop(mainloop, 0, 1);
    

finish:
    Deinit();
    if (window) {
        glfwDestroyWindow(window);
    }
    glfwTerminate();

    return status;
}
