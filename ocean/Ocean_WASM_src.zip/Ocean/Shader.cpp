// Shader.cpp
#include "stdafx.h"
#include "Shader.h"

namespace Shader {

std::string loadFile(const std::string& filename) {
    std::ifstream in(filename, std::ios::in);
    if (!in) {
        return "";
    }

    std::string line;
    std::stringstream str;
    while (std::getline(in, line)) {
        str << line << std::endl;
    }

    return str.str();
}

std::string showProgramError(GLuint shader) {
	std::stringstream str;
    char buffer[512];
    glGetProgramInfoLog(shader, 512, nullptr, buffer);
    str << buffer << std::endl;
    return str.str();
}

std::string showShaderError(GLuint shader) {
	std::stringstream str;
    char buffer[512];
    glGetShaderInfoLog(shader, 512, nullptr, buffer);
    str << buffer << std::endl;
    return str.str();
}

std::string showShaderInfo(GLuint shader) {
    int length;
    std::stringstream str;

    if (length!=GL_TRUE ) {
        str << "No Shader Info";
    }

    return str.str();
}

std::string showProgramInfo(GLuint program) {
    int length;
    std::stringstream str;

    if (length!=GL_TRUE ) {
        str << "No Program Info";
    }

    return str.str();
}

bool createProgram(GLuint& program, GLuint& vertex, GLuint& fragment,
                   const std::string& vertex_shader, const std::string& fragment_shader) {
    std::cout << "Shader Files: " << vertex_shader << " " << fragment_shader << std::endl;

    std::string strVert = loadFile(vertex_shader);
    if (strVert.empty()) {
        std::cout << "Vertex Shader Error : Unable to load file" << std::endl;
        return false;
    }

    std::string strFrag = loadFile(fragment_shader);
    if (strFrag.empty()) {
        std::cout << "Fragment Shader Error : Unable to load file" << std::endl;
        return false;
    }

    return createProgramSource(program, vertex, fragment, strVert, strFrag);
}

bool createProgramSource(GLuint& program, GLuint& vertex, GLuint& fragment,
                             const std::string& vertex_shader, const std::string& fragment_shader) {
    std::cout << "Vertex Shader    : " << vertex_shader.length() << " symbols" << std::endl;
    std::cout << "Fragment Shader  : " << fragment_shader.length() << " symbols" << std::endl;

    GLuint sProgram = 0;
    GLuint vShader = 0;
    GLuint fShader = 0;
    GLint result;

    const GLchar* vertexSource = vertex_shader.c_str();
    const GLchar* fragmentSource = fragment_shader.c_str();
    
    vShader = glCreateShader(GL_VERTEX_SHADER);
    if (!vShader) {
        std::cout << "Unable to Create Vertex Shader" << std::endl;
        goto error;
    }

    fShader = glCreateShader(GL_FRAGMENT_SHADER);
    if (!fShader) {
        std::cout << "Unable to Create Fragment Shader" << std::endl;
        goto error;
    }
	
    glShaderSource(vShader, 1, &vertexSource, nullptr);
    glCompileShader(vShader);
    glGetShaderiv(vShader, GL_COMPILE_STATUS,&result);
    if (!result) {
        std::cout << "Vertex Shader Error : " << showShaderError(vShader) << std::endl;
        goto error;
    }

    glShaderSource(fShader, 1, &fragmentSource, nullptr);
    glCompileShader(fShader);
    glGetShaderiv(fShader, GL_COMPILE_STATUS,&result);
    if (!result) {
        std::cout << "Fragment Shader Error : " << showShaderError(fShader) << std::endl;
        goto error;
    }

    sProgram = glCreateProgram();
    if (!sProgram) {
        std::cout << "Unable to Create Program" << std::endl;
        goto error;
    }

    glAttachShader(sProgram, vShader);
    glAttachShader(sProgram, fShader);

    glLinkProgram(sProgram);
    glGetProgramiv(sProgram, GL_LINK_STATUS, &result);
    if (!result) {
        std::cout << "Linking Shader Error : " << showProgramError(sProgram) << std::endl;
        goto error;
    }
    // show shader info
    std::cout << "Vertex Shader    : " << showShaderInfo(vShader) << std::endl;
    std::cout << "Fragment Shader  : " << showShaderInfo(fShader) << std::endl;
    std::cout << "Shader Program   : " << showProgramInfo(sProgram) << std::endl;
    program = sProgram;
    vertex = vShader;
    fragment = fShader;

    return true;

error:
    releaseProgram(sProgram, vShader, fShader);

    return false;
}

void releaseProgram(GLuint program, GLuint vertex, GLuint fragment) {
    if (program) {
        if (vertex) {
            glDetachShader(program, vertex);
        }
        if (fragment) {
            glDetachShader(program, fragment);
        }

        glDeleteProgram(program);
    }

    if (vertex) {
        glDeleteShader(vertex);
    }

    if (fragment) {
        glDeleteShader(fragment);
    }
}

} // namespace
