#!/bin/sh

#source ../emsdk_env.sh

em++ -Iglm/ Complex.cpp Config.cpp FFT.cpp FPSCounter.cpp main.cpp Ocean.cpp Shader.cpp stdafx.cpp Vector.cpp WorldPosition.cpp --std=c++11 -O3 -lGL -lGLU -lm -lGLEW -s USE_GLFW=3 -s FULL_ES3=1 -s USE_WEBGL2=1 -s WASM=1 -o build/ocean.html --shell-file shell_minimal.html --preload-file ./data

