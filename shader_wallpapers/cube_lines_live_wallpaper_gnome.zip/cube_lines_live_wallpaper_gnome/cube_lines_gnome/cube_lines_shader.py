#!/usr/bin/env python3

"""
simple python GTK application to draw on desktop
"""


# this can be modified to make it work on startup

DISABLE_SHADOW = False
USE_ALPHA = False




import os

# set to False to force x11 on wayland
# look like window.set_type_hint(Gdk.WindowTypeHint.DESKTOP) does not work on wayland
USE_WAYLAND=True

if USE_WAYLAND:
    if 'WAYLAND_DISPLAY' in os.environ and 'PYOPENGL_PLATFORM' not in os.environ:
        os.environ['PYOPENGL_PLATFORM'] = 'egl'
        os.environ['GDK_BACKEND'] = 'wayland'
else:
    if 'WAYLAND_DISPLAY' in os.environ:
        del os.environ['WAYLAND_DISPLAY']
        os.environ['GDK_BACKEND'] = 'x11'


import gi
import sys
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk
from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader
from collections import defaultdict
import numpy as np
import math
import time

iResolution = [640,360]
ALLOW_GTK_ALPHA = False
USER_PAUSED = False

class GLCanvas(Gtk.GLArea):
    def __init__(self):
        Gtk.GLArea.__init__(self)
        self.set_required_version(3, 3)
        self.connect("realize", self.on_initialize)
        self.connect("render", self.on_render)
        self.add_tick_callback(self.tick)
        
        #self.set_auto_render(False) # Wayland still lag even if override draw event
        
        self.iFrame = 0
        self.iTime=0.0
        self.current_frame_time=0
        self.frame_counter = 0
        self.set_start_time = True

        self.vertices = [
            -1.0,  -1.0, 0.0, 1.0,
            -1.0,  1.0, 0.0, 1.0,
            1.0, 1.0, 0.0, 1.0,
            -1.0,  -1.0, 0.0, 1.0,
            1.0,  1.0, 0.0, 1.0,
            1.0, -1.0, 0.0, 1.0
            ]

        self.vertices = np.array(self.vertices, dtype=np.float32)

    def tick(self, widget, frame_clock):
        self.last_frame_time=self.current_frame_time
        if self.set_start_time:
            self.last_frame_time = frame_clock.get_frame_time()
            self.set_start_time = False
        self.current_frame_time = frame_clock.get_frame_time()
        
        global USER_PAUSED
        if USER_PAUSED:
          return True
        
        self.frame_counter += 1
        self.iFrame += 1
        self.iTime += (self.current_frame_time - self.last_frame_time)/1000000
        return True

    def build_program(self):
        VERTEX_SHADER_SOURCE = """
            #version 330
            in vec4 vertex_position;
            void main()
            {
                gl_Position = vertex_position;
            }
        """
        shadertoy_min_template = """
            #version 330
            uniform vec2 iResolution;
            uniform vec4 iMouse;
            uniform int iFrame;
            uniform float iTime;
            uniform sampler2D iChannel0;
            uniform bool use_shadow;
            uniform bool use_alpha;
            out vec4 fragColor;
            
            %s

            void main()
            {
                mainImage(fragColor, gl_FragCoord.xy);
            }
        """
        
        path_dir = os.path.dirname(__file__)
        if not os.path.dirname(__file__)=="":
            path_dir += "/"
        self.main_image = open(path_dir+'Cube_Lines.frag', 'r').read().encode('ascii', errors='ignore').decode()
        
        FRAGMENT_SHADER_SOURCE = shadertoy_min_template % self.main_image
        
        vertex_shader = compileShader(VERTEX_SHADER_SOURCE, GL_VERTEX_SHADER)
        fragment_shader = compileShader(FRAGMENT_SHADER_SOURCE, GL_FRAGMENT_SHADER)
        self.shader = compileProgram(vertex_shader, fragment_shader)
        self.UNIFORM_LOCATIONS = {
            'iResolution': glGetUniformLocation( self.shader, 'iResolution' ),
            'iMouse': glGetUniformLocation( self.shader, 'iMouse' ),
            'iFrame': glGetUniformLocation( self.shader, 'iFrame' ),
            'iTime': glGetUniformLocation( self.shader, 'iTime' ),
            'iChannel0': glGetUniformLocation( self.shader, 'iChannel0' ),
            'use_shadow': glGetUniformLocation( self.shader, 'use_shadow' ),
            'use_alpha': glGetUniformLocation( self.shader, 'use_alpha' ),
        }
    
    def update_uniforms(self):
        global iResolution
        global DISABLE_SHADOW
        global USE_ALPHA
        glUniform2f(self.UNIFORM_LOCATIONS['iResolution'],iResolution[0],iResolution[1])
        glUniform4f(self.UNIFORM_LOCATIONS['iMouse'],0,0,0,0)
        glUniform1i(self.UNIFORM_LOCATIONS['iFrame'],self.iFrame)
        glUniform1f(self.UNIFORM_LOCATIONS['iTime'],self.iTime)
        glBindTexture(GL_TEXTURE_2D, self.iChannel0)
        glUniform1i(self.UNIFORM_LOCATIONS['iChannel0'],0)
        glUniform1i(self.UNIFORM_LOCATIONS['use_shadow'],DISABLE_SHADOW)
        glUniform1i(self.UNIFORM_LOCATIONS['use_alpha'],USE_ALPHA)
        
    def load_emptyTexture(self):
        imageData = np.array([0,0,0,0], np.uint8)
        textureID = glGenTextures(1)
        glPixelStorei(GL_UNPACK_ALIGNMENT, 4)
        glBindTexture(GL_TEXTURE_2D, textureID)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_BASE_LEVEL, 0)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAX_LEVEL, 0)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 1, 1,
           0, GL_RGB, GL_UNSIGNED_BYTE, imageData)
        return textureID
      

    def on_initialize(self, gl_area):
        opengl_context = self.get_context()
        opengl_context.make_current()
        major, minor = opengl_context.get_version()
        print("OpenGL context created successfully.\n-- Using OpenGL Version " + str(major) + "." + str(minor))

        if gl_area.get_error() != None:
            print(gl_area.get_error())

        self.build_program()
        self.iChannel0=self.load_emptyTexture()

        self.vertex_array_object = GLuint()
        glCreateVertexArrays(1, ctypes.byref(self.vertex_array_object))
        glBindVertexArray(self.vertex_array_object)
        self.vertex_attribute_position = glGetAttribLocation(self.shader, 'vertex_position')
        glEnableVertexAttribArray(self.vertex_attribute_position)

        self.vertex_buffer = GLuint()
        glCreateBuffers(1, ctypes.byref(self.vertex_buffer))
        glNamedBufferStorage(self.vertex_buffer, self.vertices.nbytes, self.vertices, GL_MAP_READ_BIT)
        glBindBuffer(GL_ARRAY_BUFFER, self.vertex_buffer)
        glVertexAttribPointer(self.vertex_attribute_position, 4, GL_FLOAT, GL_FALSE, 0, ctypes.c_void_p(0))
        return True

    def on_render(self, gl_area, gl_context):
        global USER_PAUSED
        if USER_PAUSED:
            time.sleep(0.016)
        else:
          colour_vector = [0,0,0,0]
          glClearBufferfv(GL_COLOR, 0, colour_vector)

          glUseProgram(self.shader)
          self.update_uniforms()

          glBindVertexArray(self.vertex_array_object)
          glDrawArrays(GL_TRIANGLES, 0, int(len(self.vertices)/4))
        self.queue_draw()

class RootWindow(Gtk.Application):
    def __init__(self):
        Gtk.Application.__init__(self)
        self.is_fullscreen = False
        self.monitor_num_for_display = 0

    def do_activate(self):
        screen = Gdk.Screen.get_default()
        visual = Gdk.Screen.get_rgba_visual(screen)
        self.window = Gtk.Window(application=self)
        Gtk.Widget.set_visual(self.window, visual)
        global ALLOW_GTK_ALPHA
        global USE_ALPHA
        ALLOW_GTK_ALPHA = self.transparent_setup()
        window = self.window
        window.set_title("Cube Lines Shader")
        global iResolution
        window.set_default_size(iResolution[0], iResolution[1])
        self.is_X = not bool('WAYLAND_DISPLAY' in os.environ)
        self.get_screen_size_wayland = False
        self.once_resize = False
        self.once_undecorate = False
        if self.is_X:
            window.width, window.height = self.monitor_detect()
            window.resize(window.width, window.height)
            print("XDG Desktop")
        else:
            # I do not know how to get screen size in Wayland, this is Wayland "fix" for GTK3
            self.get_screen_size_wayland = True
            window.fullscreen()
            window.width, window.height = iResolution
            print("Wayland Desktop")
        iResolution[0]=window.width
        iResolution[1]=window.height
        window.set_position(Gtk.WindowPosition.NONE)
        window.move(0,0)
        window.connect("delete-event", Gtk.main_quit)
        window.connect("key-release-event", self.on_key_release)
        
        self.gl_widget = GLCanvas()
        self.gl_widget.set_app_paintable(False)
        window.add(self.gl_widget)

        if self.is_fullscreen == True:
            window.fullscreen_on_monitor(Gdk.Screen.get_default(), self.monitor_num_for_display)
        window.set_type_hint(Gdk.WindowTypeHint.DESKTOP)
        window.set_skip_taskbar_hint(True)
        # nan of this works on Wayland
        if not self.is_X:
            window.set_keep_above(False)
            window.set_keep_below(True)
            window.set_accept_focus(False)
        self._build_context_menu()
        if ALLOW_GTK_ALPHA:
            self.gl_widget.set_has_alpha(USE_ALPHA)
        window.connect('button-press-event', self._on_button_press_event)
        if not self.is_X:
            window.connect("draw", self.on_draw)
        window.show_all()
        window.connect("draw", self.on_draw)

    def on_key_release(self, window, event):
        return
        # if event.keyval == Gdk.KEY_Escape:
            # self.quit()
        # elif event.keyval == Gdk.KEY_f:
            # self.fullscreen_mode(window)

    def fullscreen_mode(self, window):
        if self.is_fullscreen == True:
            window.unfullscreen()
            self.is_fullscreen = False
        else:
            window.fullscreen()
            self.is_fullscreen = True
    
    def on_draw(self, wid, cr):
        if self.get_screen_size_wayland:
            self.window.width = self.window.get_size()[0]
            self.window.height = self.window.get_size()[1]
            global iResolution
            iResolution[0]=self.window.width
            iResolution[1]=self.window.height
            self.get_screen_size_wayland=False
            self.window.unfullscreen()
            self.window.resize(self.window.width, self.window.height)
            self.once_resize = True
        else:
            if self.once_resize:
                self.once_resize = False
                self.window.resize(self.window.width, self.window.height)
                self.once_undecorate = True
            else:
                if self.once_undecorate:
                    self.once_undecorate = False
                    self.window.set_decorated(False)
        #self.window.queue_draw() # redraw called from Gl widget
    
    def monitor_detect(self):
        display = Gdk.Display.get_default()
        screen = Gdk.Screen.get_default()
        monitor = display.get_primary_monitor()
        geometry = monitor.get_geometry()
        scale_factor = monitor.get_scale_factor()
        width = scale_factor * geometry.width
        height = scale_factor * geometry.height
        screen.connect('size-changed', self._on_size_changed)
        return width, height

    def _on_use_alpha(self, item):
        alpha = item.get_active()
        global USE_ALPHA
        USE_ALPHA = alpha
        self.gl_widget.set_has_alpha(USE_ALPHA)
    
    def _on_use_shadow(self, item):
        shadows = item.get_active()
        global DISABLE_SHADOW
        DISABLE_SHADOW = shadows

    def _on_user_pause(self, item):
        pause = item.get_active()
        global USER_PAUSED
        USER_PAUSED = pause

    def _on_menuitem_quit(self, *args):
        self.quit()

    def _build_context_menu(self):
        self.window.menu = Gtk.Menu()
        
        items = []
        global ALLOW_GTK_ALPHA
        if ALLOW_GTK_ALPHA:
            items.append(('Use Alpha', self._on_use_alpha, Gtk.CheckMenuItem))
        items.append(('Disable Shadow', self._on_use_shadow, Gtk.CheckMenuItem))
        items.append(('Pause render', self._on_user_pause, Gtk.CheckMenuItem))
        items.append(('Exit', self._on_menuitem_quit, Gtk.MenuItem))
        self.window.menuitem = defaultdict()

        for item in items:
            label, handler, item_type = item
            if item_type == Gtk.SeparatorMenuItem:
                self.window.menu.append(Gtk.SeparatorMenuItem())
            else:
                menuitem = item_type.new_with_label(label)
                menuitem.connect('activate', handler)
                menuitem.set_margin_top(4)
                menuitem.set_margin_bottom(4)
                self.window.menu.append(menuitem)
                self.window.menuitem[label] = menuitem
        self.window.menu.show_all()

    def _on_button_press_event(self, widget, event):
        if event.type == Gdk.EventType.BUTTON_PRESS and event.button == 3:
            self.window.menu.popup_at_pointer()
        return True

    def transparent_setup(self):
        transp_supported = False
        self.window.set_app_paintable(True)
        screen = self.window.get_screen()
        visual = screen.get_rgba_visual()
        if visual != None and screen.is_composited():
            self.window.set_visual(visual)
            transp_supported=True
        return transp_supported

    def _on_size_changed(self, *args):
        self.window.width, self.window.height = self.monitor_detect()
        self.window.resize(self.window.width, self.window.height)
        global iResolution
        iResolution[0]=self.window.width
        iResolution[1]=self.window.height
        

win = RootWindow()
exit_status = win.run(sys.argv)
sys.exit(exit_status)
