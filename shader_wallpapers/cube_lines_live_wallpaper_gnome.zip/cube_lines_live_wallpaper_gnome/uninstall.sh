#!/bin/sh

INSTALL_DIR="$HOME/bin/"
APPLICATIONS_DIR="$HOME/.local/share/applications/"

install() {
  rm -rf "$INSTALL_DIR/cube_lines_gnome"
  rm "$APPLICATIONS_DIR/cube_lines.desktop"
}

echo "=== Uninstaller Script ==="
echo "This script Uninstall Cube Lines Shader from system"
while true; do
  read -r -p "Do you wish to proceed [y/N]?" yn
  case $yn in
  [Yy]*)
    install
    break
    ;;
  *)
    echo "Abort"
    exit
    ;;
  esac
done
