#!/bin/sh

INSTALL_DIR="$HOME/bin/"
APPLICATIONS_DIR="$HOME/.local/share/applications/"

create_dirs() {
  if [ ! -d "$INSTALL_DIR" ]; then
    mkdir "$INSTALL_DIR"
  fi
}

install() {
  create_dirs
  echo "Icon=$(echo ~)/bin/cube_lines_gnome/cube_lines_icon.png" >> res/cube_lines.desktop
  cp -r "cube_lines_gnome" "$INSTALL_DIR"
  cp "res/cube_lines.desktop" "$APPLICATIONS_DIR/cube_lines.desktop"
}

echo "=== Installer Script ==="
echo "This script install Cube Lines Shader to $INSTALL_DIR"
while true; do
  read -r -p "Do you wish to proceed [y/N]?" yn
  case $yn in
  [Yy]*)
    install
    break
    ;;
  *)
    echo "Abort"
    exit
    ;;
  esac
done
