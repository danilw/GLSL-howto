/**@file ColorMap.h
 */
#ifndef COLORMAP_H
#define COLORMAP_H

#include "Texture.h"

// Includes GLM
#include <glm/glm.hpp>

namespace terra {

    class ColorMap {
    public:
        ColorMap();
        ~ColorMap();

        void init();

        GLuint getTextureID()const;


        static glm::vec3 multiply( const glm::vec3& color, float coeff );

    private:

        void addColor( int i, int j, glm::vec3 color );

        int width; 
        int height; 
        UbytePixelBuffer* buffer; 
        Texture* texture; 
    };

}
#endif // COLORMAP_H
