/**@file Geometry.h
 */
#ifndef GEOMETRY_H
#define GEOMETRY_H

// Includes GLM
#include <glm/glm.hpp>


namespace terra {


    struct Plane {

        Plane();
        Plane( const float* arr);
        Plane( float a, float b, float c, float d );
        void set3Points( const glm::vec3& v1,  const glm::vec3& v2,  const glm::vec3& v3 );
        void setCoefficients( float a, float b, float c, float d );
        float distance( const glm::vec3 &p ) const;

        float a, b, c, d;
        glm::vec3 normal;
        glm::vec3 point; 
    };
    enum frustPlanes {
        FAR, NEAR, BOTTOM, TOP, LEFT, RIGHT
    };

    struct Base {
        Base();
        Base( const glm::vec3& O, const glm::vec3& x, const glm::vec3& y, const glm::vec3& z );

        glm::vec3 localToWorld( const glm::vec3& p )const;
        glm::vec3 worldToLocal( const glm::vec3& p )const;

        glm::vec3 axisX; 
        glm::vec3 axisY; 
        glm::vec3 axisZ; 
        glm::vec3 origin; 
        glm::mat4 transitionMatrix; 
        glm::mat4 inverseTransitionMatrix; 
    };
}
#endif // GEOMETRY_H
