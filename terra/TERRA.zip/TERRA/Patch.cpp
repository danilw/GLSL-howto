#include "Patch.h"
#include "cube_utils.h"

using namespace glm;
using namespace terra;

//--------------------------
// Patch
//--------------------------

Patch::Patch( int resolution, float width, const mat4& matrix ) : Renderable() {
    this->matrix = matrix;
    this->resolution = resolution;
    this->width = width;
    texMatrix = mat4(1.0);
    color = vec4( 1.0, 1.0, 1.0, 1.0 );

    verticesCount = resolution * ( ( 2 + resolution * 2 ) * 3 );
    vertices = new float[verticesCount];

    texCoordCount = resolution * ( ( 2 + resolution * 2 ) * 2 );
    texCoord2D = new float[texCoordCount];

    normalCount = resolution * ( ( 2 + resolution * 2 ) * 3 );
    normals = new float[normalCount];
}

void Patch::transform( vec3& v )const  {
    v = vec3( matrix * vec4( v, 1.0f ) );
}

void Patch::build() {
    float cellSize = width / resolution;
    float uvIncrease = 1.0f / resolution;
    float currX, currY, currZ;
    float currS, currT;

    int count = 0;
    int countUV = 0;
    currY = 0.0;
    currZ = -width / 2.0;
    currT = 0.0f;

    vec3 pos;
    vec2 uv;

    for( int j = 0; j < resolution; j++, currZ += cellSize, currT += uvIncrease ) {
        currX = - width / 2.0f;
        currS = 0.0f;
        for( int i = 0; i <= resolution; i++ , currX += cellSize, currS += uvIncrease ) {

            for( int k = 0; k < 2; k++ ) {

                if( k == 0 ) {
                    pos = vec3( currX, currY, currZ );
                    uv = vec2( currS, currT );
                } else {
                    pos = vec3( currX, currY, currZ + cellSize );
                    uv = vec2( currS, currT + uvIncrease );
                }

                transform( pos );

                vertices[count++] = pos.x;
                vertices[count++] = pos.y;
                vertices[count++] = pos.z;

                texCoord2D[countUV++] = uv.x;
                texCoord2D[countUV++] = uv.y;
            }
        }
    }
}

void Patch::buildNormal() {
    int count = 0;
    vec3 N;
    mat3 normalMatrix = ( mat3 )matrix;
    for( int j = 0; j < resolution * ( resolution + 1 ) * 2 ; j++, count += 3 ) {
        N = normalMatrix * vec3( 0.0, 1.0, 0.0 );

        normals[count]      = N.x;
        normals[count + 1]  = N.y;
        normals[count + 2]  = N.z;
    }
}

void Patch::draw()const {
    glBindVertexArray( vaoID );
    for( int i = 0; i < resolution; i++ ) {
        glDrawArrays( GL_TRIANGLE_STRIP, i * ( resolution * 2 + 2 ), resolution * 2 + 2 );
    }

    glBindVertexArray( 0 );
}

void Patch::draw(RenderMode renderMode)const {
    glBindVertexArray( vaoID );
    GLenum geometry = (renderMode== POLYGON? GL_TRIANGLE_STRIP : GL_LINE_STRIP);
    for( int i = 0; i < resolution; i++ ) {
        glDrawArrays( geometry, i * ( resolution * 2 + 2 ), resolution * 2 + 2 );
    }

    glBindVertexArray( 0 );
}


mat4 Patch::getTexMatrix()const {
    return texMatrix;
}

mat4 Patch::getMatrix()const {
    return matrix;
}

void Patch::setTexMatrix( const mat4 &m ) {
    texMatrix = m;
}

void Patch::setMatrix( const mat4 &m ) {
    matrix = m;
}


//--------------------------
// SphericPatch
//--------------------------

SphericPatch::SphericPatch( int resolution, float width, const mat4& matrix, float radius ) : Patch( resolution, width, matrix ) {
    this->radius = radius;
}

void SphericPatch::transform( vec3& v )const  {
    v = vec3( matrix * vec4( v, 1.0f ) );
    v = cubeToSphereMapping( vec3( v ) );
    v = normalize( v ) * radius ;
}

void SphericPatch::buildNormal() {
    normalCount = resolution * ( ( 2 + resolution * 2 ) * 3 );
    if( normals != 0 )
        delete[] normals;
    normals = new float[normalCount];

    int count = 0;
    vec3 N;
    for( int j = 0; j < resolution * ( resolution + 1 ) * 2 ; j++, count += 3 ) {

        N.x = vertices[count];
        N.y = vertices[count + 1];
        N.z = vertices[count + 2];
        N = normalize( N );

        normals[count]      = N.x;
        normals[count + 1]  = N.y;
        normals[count + 2]  = N.z;
    }
}

//--------------------------
// CGPatch
//--------------------------

CGPatch::CGPatch( int resolution, float width ) : Patch( resolution, width, mat4( 1 ) ) {
}

void CGPatch::transform( vec3& v )const  {
}

//--------------------------
// CGSphericPatch
//--------------------------

CGSphericPatch::CGSphericPatch( int resolution, float width ) : SphericPatch( resolution, width, mat4( 1 ), 1.0 ) {
}

void CGSphericPatch::transform( vec3& v )const  {
}


//--------------------------
// PatchFactory
//--------------------------

PatchFactory::PatchFactory() {
    sphericPatch = NULL;
    patch = NULL;
}

PatchFactory::~PatchFactory() {
    if( sphericPatch != NULL ) delete sphericPatch;
    if( patch != NULL ) delete patch;
}

CGSphericPatch* PatchFactory::createdCGSphericPatch( int resolution, float width ) {
    if( sphericPatch != NULL )
        delete sphericPatch;
    sphericPatch = new CGSphericPatch( resolution, width );
    sphericPatch->build();
    sphericPatch->buildNormal();
    sphericPatch->load();
    return sphericPatch;
}

CGSphericPatch* PatchFactory::getCGSphericPatch()const  {
    return sphericPatch;
}

CGPatch* PatchFactory::createdCGPatch( int resolution, float width ) {
    if( patch != NULL )
        delete patch;
    patch = new CGPatch( resolution, width );
    patch->build();
    patch->buildNormal();
    patch->load();
    return patch;
}

CGPatch* PatchFactory::getCGPatch()const  {
    return patch;
}

