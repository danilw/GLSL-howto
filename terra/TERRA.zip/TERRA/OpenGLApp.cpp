#include <iostream>
#include "OpenGLApp.h"
#include "utils.h" //Pour getGLError()


using namespace glm;
using namespace terra;

OpenGLApp::OpenGLApp( const Config* config, std::string windowTitle, int windowWidth, int windowHeigth )
: windowTitle( windowTitle ), windowWidth( windowWidth ), windowHeight( windowHeigth ), config(config) {
    window = NULL;
    OGLContext = NULL;
    renderer = NULL;
    gFullscreen = Pp = false;
    input = Input();
}

OpenGLApp::~OpenGLApp() {
    delete renderer;
    SDL_GL_DeleteContext( OGLContext );
    SDL_DestroyWindow( window );
    SDL_Quit();
}

bool OpenGLApp::windowInit() {
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
        std::cerr << "An error occured while initializing SDL : " << SDL_GetError() << std::endl;
        SDL_Quit();

        return false;
    }

    SDL_GL_SetAttribute( SDL_GL_CONTEXT_MAJOR_VERSION, 3 );
    SDL_GL_SetAttribute( SDL_GL_CONTEXT_MINOR_VERSION, 3 );
    SDL_GL_SetAttribute ( SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE  );
    
    window = SDL_CreateWindow( windowTitle.c_str(), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, windowWidth, windowHeight, SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL );

    if( window == 0 ) {
        std::cerr << "An error occured while creating SDL window : " << SDL_GetError() << std::endl;
        SDL_Quit();

        return false;
    }
    
    renderer_sdl = SDL_CreateRenderer(window, 0, SDL_RENDERER_ACCELERATED);
    
    OGLContext = SDL_GL_CreateContext( window );
    

    if( OGLContext == 0 ) {
        std::cerr << SDL_GetError() << std::endl;
        SDL_DestroyWindow( window );
        SDL_Quit();

        return false;
    }

    return true;
}

bool OpenGLApp::OGLInit() {

    return true;
}

bool OpenGLApp::init(){
    if( windowInit() == false ) {
        return false;
    }

    if( OGLInit() == false ) {
        return false;
    }


    scene.loadConfig( config->sceneConfig, config->planetConfig );

    renderer = new Renderer(config->renderConfig, &scene );
    renderer->init();
    //SDL_WarpMouseInWindow(window, windowWidth/2, windowHeight/2);
    //input.displayCursor( false );
    //input.grapCursor( true );

    return true;
}
Uint32 loopStart = 0 , loopEnd = 0, elapsedTime = 0;

void OpenGLApp::start() {
    
    //while( !input.end() ) {
        loopStart = SDL_GetTicks();

        //if(handleInput(elapsedTime+1) == APP_EXIT)
        //    break;

        handleInput(elapsedTime+1);

        renderer->update();
        Camera* camera = scene.getCamera();
        if(camera->cits)
        camera->nextPos();

        SDL_GL_SwapWindow( window );

        loopEnd = SDL_GetTicks();
        elapsedTime = loopEnd - loopStart;

        computeFPS();

    //}
}

glm::vec2 rotate2d(float originx, float originy, float pointx, float pointy, float radian) {

    float s = std::sin(radian);
    float c = std::cos(radian);
    pointx -= originx;
    pointy -= originy;
    float xnew = pointx * c - pointy * s;
    float ynew = pointx * s + pointy * c;
    glm::vec2 retval;
    retval[0] = xnew + originx;
    retval[1] = ynew + originy;
    return retval;

}

float angle2d(float cx, float cy, float ex, float ey) {
    float dy = ey - cy;
    float dx = ex - cx;
    float theta = std::atan2(dy, dx);
    return theta;
}


int OpenGLApp::handleInput( float elapsedTime){
	elapsedTime=25.;
    input.updateEvents();

    if(input.getKey( SDL_SCANCODE_ESCAPE ))
        return APP_EXIT;

    if( input.getKeyPressed( SDL_SCANCODE_1 ) )
        renderer->nextRenderMode();

    if( input.getKeyPressed( SDL_SCANCODE_2 ) )
        renderer->toggleHDR();

    if( input.getKeyPressed( SDL_SCANCODE_3 ) )
        renderer->toggleCulling();

    if( input.getKeyPressed( SDL_SCANCODE_4 ) )
        renderer->toggleFrustrumUpdate();
        
    if( input.getKeyPressed( SDL_SCANCODE_P ) )
        Pp=!Pp;
        

        
    if( input.getKeyPressed( SDL_SCANCODE_H ) ){
		gFullscreen = !gFullscreen;
        if (gFullscreen) {
            emscripten_run_script("hidec(true)");
        } else {
            emscripten_run_script("hidec(false)");
        }
	}

    static const float radius = config->planetConfig.radius;


    static const float coeff = 0.5f;
    static const float rotCoeff = 0.03f;
    Camera* camera = scene.getCamera();
    if( input.getKeyPressed( SDL_SCANCODE_R ) )
        camera->cameraits();
    float inputScale = (radius / 5000)*(std::max(0.15f,camera->lastsp));
    if( input.getMouseButton( 1 ) || input.getKey( SDL_SCANCODE_SPACE ) )
        inputScale = (radius / 50000.0)*(std::max(0.5f,camera->lastsp));

    if( input.getMouseButton( 3 ) || input.getKey( SDL_SCANCODE_LSHIFT ))
        inputScale = radius / 500000.0;
    if(!Pp){
    static bool warp = false;
    //if( input.mouseMove() )
    {
		if (!warp) {
		int mx,my;
		glm::vec2 rot=rotate2d(0,0,12*std::abs(2.*glm::length(glm::vec2(windowWidth/2-input.getX(),windowHeight/2-input.getY()))/(windowHeight/2)),0,angle2d(windowWidth/2,windowHeight/2,input.getX(),input.getY()));
        mx=rot.x;
        my=rot.y;

        camera->rotate( mx  * rotCoeff, my  * rotCoeff, 0);
        //SDL_WarpMouseInWindow(window, windowWidth/2, windowHeight/2);
    warp = true;
    } else {
        warp = false;
    }}
	}
    if( input.getKey( SDL_SCANCODE_LEFT ) )
        camera->rotate( -elapsedTime * rotCoeff, 0.0f ,  0.0f);

    if( input.getKey( SDL_SCANCODE_RIGHT ) )
        camera->rotate( elapsedTime * rotCoeff, 0.0f ,  0.0f);

    if( input.getKey( SDL_SCANCODE_UP ) )
        camera->rotate( 0.0f, -elapsedTime * rotCoeff,  0.0f);

    if( input.getKey( SDL_SCANCODE_DOWN ) )
        camera->rotate( 0.0f, elapsedTime * rotCoeff,  0.0f);

    if( input.getKey( SDL_SCANCODE_Q ) )
        camera->rotate( 0.0f , 0.0f, - elapsedTime * rotCoeff * 0.5);

    if( input.getKey( SDL_SCANCODE_E ) )
        camera->rotate( 0.0f , 0.0f, elapsedTime * rotCoeff * 0.5);

    if( input.getKey( SDL_SCANCODE_W ) )
        camera->moveViewAxis( elapsedTime * coeff * inputScale );

    if( input.getKey( SDL_SCANCODE_S ) )
        camera->moveViewAxis( - elapsedTime * coeff * inputScale );

    if( input.getKey( SDL_SCANCODE_D ) )
        camera->moveLateralAxis( elapsedTime * coeff * inputScale );

    if( input.getKey( SDL_SCANCODE_A ) )
        camera->moveLateralAxis( - elapsedTime * coeff * inputScale );

    camera->updateMatrix();

    return APP_CONTINUE;
}

void OpenGLApp::computeFPS() {
    static Uint32 currentTime = 0;
    static Uint32 lastTime = 0;
    static Uint32 n = 0;
    Uint32 fps = 0;
    n++;
    char szFrameCount[20];
    currentTime = SDL_GetTicks();
    if( currentTime - lastTime >= 1000.0 ) {
        fps = n;
        n = 0;
        lastTime = currentTime;
        sprintf( szFrameCount, "Terra  %d fps", fps );
        //SDL_SetWindowTitle( window, szFrameCount );
    }
}

