/**@file FrameBuffer.h
 */
#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

#include "Texture.h"


namespace terra {

    class FrameBuffer {
    public:


        FrameBuffer( int width, int height, bool blur, bool useStencilBuffer = false );

        ~FrameBuffer();


        bool load();


        GLuint getID() const;


        GLuint getColorBufferID( unsigned int index=0 ) const;


        int getWidth() const;

        int getHeight() const;


    private:

        FrameBuffer();


        FrameBuffer( const FrameBuffer &toCopyFrameBuffer );


        void createRenderBuffer( GLuint &id, GLenum internalFormat );


        GLuint id; 
        int width; 
        int height;

        Texture* colorBuffer;
        GLuint depthBufferID; 
        bool useStencilBuffer;
        bool blur; 
    };

}
#endif //FRAMEBUFFER_H
