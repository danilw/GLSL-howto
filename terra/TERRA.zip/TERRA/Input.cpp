#include "Input.h"
#include <iostream>

using namespace terra;

Input::Input() : mouseX( 1920/2 ), mouseY( 1080/2 ), mouseXRel( 0 ), mouseYRel( 0 ), mouseLastX(0), mouseLastY(0), endFlag( false ) {
    for( int i( 0 ); i < SDL_NUM_SCANCODES; i++ ) {
        keysPressed[i] = false;
        keysReleased[i] = false;
        keys[i] = false;
    }
    for( int i( 0 ); i < 8; i++ ) 
        mouseButtons[i] = false;
}

Input::~Input() {
}

void Input::updateEvents() {

    mouseXRel = 0;
    mouseYRel = 0;


    while( SDL_PollEvent( &events ) ) {

        switch( events.type ) {
        case SDL_KEYDOWN:
            keysPressed[events.key.keysym.scancode] = true;
            keysReleased[events.key.keysym.scancode] = false;
            keys[events.key.keysym.scancode] = true;
            break;

        case SDL_KEYUP:
            keysReleased[events.key.keysym.scancode] = true;
            keysPressed[events.key.keysym.scancode] = false;
            keys[events.key.keysym.scancode] = false;
            break;


        case SDL_MOUSEBUTTONDOWN:
            mouseButtons[events.button.button] = true;
            break;


        case SDL_MOUSEBUTTONUP:
            mouseButtons[events.button.button] = false;
            break;


        case SDL_MOUSEMOTION:
            mouseX = events.motion.x;
            mouseY = events.motion.y;
            mouseXRel = events.motion.xrel;
            mouseYRel = events.motion.yrel;
            break;


        case SDL_WINDOWEVENT:
            if( events.window.event == SDL_WINDOWEVENT_CLOSE )
                endFlag = true;
            break;

        default:
            break;
        }
    }
}

bool Input::end() const {
    return endFlag;
}

void Input::displayCursor( bool b ) const {
    if( b )
        SDL_ShowCursor( SDL_ENABLE );
    else
        SDL_ShowCursor( SDL_DISABLE );
}

void Input::grapCursor( bool b ) const {
    if( b )
        SDL_SetRelativeMouseMode( SDL_TRUE );
    else
        SDL_SetRelativeMouseMode( SDL_FALSE );
}

// Getters

bool Input::getKeyPressed( const SDL_Scancode key ) {
    if( keysPressed[key] ) {
        keysPressed[key] = false;
        return true;
    }
    return false;
}

bool Input::getKeyReleased( const SDL_Scancode key ) {
    if( keysReleased[key] ) {
        keysReleased[key] = false;
        return true;
    }
    return false;
}

bool Input::getKey( const SDL_Scancode key ) const {
    return keys[key];
}

bool Input::getMouseButton( const Uint8 button ) const {
    return mouseButtons[button];
}

bool Input::mouseMove() const {
    if( mouseXRel == 0 && mouseYRel == 0 )
        return false;
    else
        return true;
}

int Input::getX() const {
    return mouseX;
}

int Input::getY() const {
    return mouseY;
}

int Input::getXRel() const {
    return mouseXRel;
}

int Input::getYRel() const {
    return mouseYRel;
}
