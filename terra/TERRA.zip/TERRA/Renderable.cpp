#include "Renderable.h"
#include "utils.h"

//macro pour le vbo
#ifndef BUFFER_OFFSET
#define BUFFER_OFFSET(offset) ((char*)NULL + (offset))
#endif

using namespace glm;
using namespace terra;

Renderable::Renderable() {
    vertices = 0;
    texCoord2D = 0;
    normals = 0;
    vboID = 0;
    vaoID = 0;
    color = glm::vec4( 1.0 );
    verticesCount = 0;
    texCoordCount = 0;
    normalCount = 0;
}

Renderable::~Renderable() {
    glDeleteBuffers( 1, &vboID );
    glDeleteVertexArrays( 1, &vaoID );

    if( vertices != 0 )
        delete[] vertices;
    if( texCoord2D != 0 )
        delete[] texCoord2D;
    if( normals != 0 )
        delete[] normals;
}

int Renderable::getVerticesSizeInBytes()const {
    return verticesCount * sizeof( float );
}

int Renderable::getTexCoordSizeInBytes()const {
    return texCoordCount * sizeof( float );
}

int Renderable::getNormalSizeInBytes()const {
    return normalCount * sizeof( float );
}

void Renderable::load() {
    if( glIsBuffer( vboID ) == GL_TRUE )
        glDeleteBuffers( 1, &vboID );

    glGenBuffers( 1, &vboID );

    glBindBuffer( GL_ARRAY_BUFFER, vboID );

    int vecticesSizeInBytes = getVerticesSizeInBytes();
    int texCoordSizeInBytes = getTexCoordSizeInBytes();
    int normalSizeInBytes = getNormalSizeInBytes();
    glBufferData( GL_ARRAY_BUFFER, vecticesSizeInBytes + normalSizeInBytes + texCoordSizeInBytes, 0, GL_STATIC_DRAW );

    glBufferSubData( GL_ARRAY_BUFFER, 0, vecticesSizeInBytes, vertices );
    glBufferSubData( GL_ARRAY_BUFFER, vecticesSizeInBytes, normalSizeInBytes, normals );
    glBufferSubData( GL_ARRAY_BUFFER, vecticesSizeInBytes + normalSizeInBytes, texCoordSizeInBytes, texCoord2D );

    glBindBuffer( GL_ARRAY_BUFFER, 0 );

    if( glIsVertexArray( vaoID ) == GL_TRUE )
        glDeleteVertexArrays( 1, &vaoID );

    glGenVertexArrays( 1, &vaoID );

    glBindVertexArray( vaoID );

    glBindBuffer( GL_ARRAY_BUFFER, vboID );

    glVertexAttribPointer( 0, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET( 0 ) );
    glEnableVertexAttribArray( 0 );
    glVertexAttribPointer( 1, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET( vecticesSizeInBytes ) );
    glEnableVertexAttribArray( 1 );
    glVertexAttribPointer( 2, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET( vecticesSizeInBytes + normalSizeInBytes ) );
    glEnableVertexAttribArray( 2 );

    glBindBuffer( GL_ARRAY_BUFFER, 0 );

    glBindVertexArray( 0 );
}
