/**@file Sphere.h
 */
#ifndef SPHERE_H
#define SPHERE_H

#include "Shader.h"
#include "Patch.h"

namespace terra {

    class Sphere {
    public:

        Sphere( float radius );
        ~Sphere();

        void draw()const;

    private:
        SphericPatch* cubeFaces[6];
        void build();
        float radius;
        Shader* shader;
    };
}
#endif // SPHERE_H
