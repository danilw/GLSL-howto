// Includes GLM

#include <glm/gtc/type_ptr.hpp>

#include "Frustrum.h"

using namespace glm;
using namespace terra;

Frustrum::Frustrum() {
}

Frustrum::~Frustrum() {

}

#define ANG2RAD 3.14159265358979323846/180.0f


void Frustrum::setCameraParams( float fov, float ratio, float nearD, float farD ) {
    this->ratio = ratio;
    this->fov = fov;
    this->nearD = nearD;
    this->farD = farD;

    tang = tan( ANG2RAD * fov * 0.5 ) ;
    nh = nearD * tang;
    nw = nh * ratio;
    fh = farD  * tang;
    fw = fh * ratio;
}

void Frustrum::setCameraLookAt( const vec3& position, const vec3& lookAtPoint, const vec3& verticalAxis ) {
    //vec3 dir, nc, fc, X, Y, Z;

    Z = position - lookAtPoint;
    Z = normalize( Z );

    X = cross( verticalAxis, Z );
    X = normalize( X );

    Y = cross( Z, X );

    nc = position - Z * nearD;
    fc = position - Z * farD;

    ntl = nc + Y * nh - X * nw;
    ntr = nc + Y * nh + X * nw;
    nbl = nc - Y * nh - X * nw;
    nbr = nc - Y * nh + X * nw;

    ftl = fc + Y * fh - X * fw;
    ftr = fc + Y * fh + X * fw;
    fbl = fc - Y * fh - X * fw;
    fbr = fc - Y * fh + X * fw;

    planes[TOP].set3Points( ntr, ntl, ftl );
    planes[BOTTOM].set3Points( nbl, nbr, fbr );
    planes[LEFT].set3Points( ntl, nbl, fbl );
    planes[RIGHT].set3Points( nbr, ntr, fbr );
    planes[NEAR].set3Points( ntl, ntr, nbr );
    planes[FAR].set3Points( ftr, ftl, fbl );
}

void Frustrum::updateNearFar(const vec3& position, float nd, float fd){
    nearD = nd;
    farD = fd;

    tang = tan( ANG2RAD * fov * 0.5 ) ;
    nh = nearD * tang;
    nw = nh * ratio;
    fh = farD  * tang;
    fw = fh * ratio;

    nc = position - Z * nearD;
    fc = position - Z * farD;

    ntl = nc + Y * nh - X * nw;
    ntr = nc + Y * nh + X * nw;
    nbl = nc - Y * nh - X * nw;
    nbr = nc - Y * nh + X * nw;

    ftl = fc + Y * fh - X * fw;
    ftr = fc + Y * fh + X * fw;
    fbl = fc - Y * fh - X * fw;
    fbr = fc - Y * fh + X * fw;

    planes[TOP].set3Points( ntr, ntl, ftl );
    planes[BOTTOM].set3Points( nbl, nbr, fbr );
    planes[LEFT].set3Points( ntl, nbl, fbl );
    planes[RIGHT].set3Points( nbr, ntr, fbr );
    planes[NEAR].set3Points( ntl, ntr, nbr );
    planes[FAR].set3Points( ftr, ftl, fbl );
}

const Frustrum::PlaneArray& Frustrum::getPlanes()const {
    return planes;
}
