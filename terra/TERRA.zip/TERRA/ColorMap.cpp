#include <iostream>
#include "ColorMap.h"
#include <random>


using namespace glm;

namespace terra{
	std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<int> uni(0, 125);
    static const vec3 snow = vec3( 255 );  // snow
    static const vec3 rock =  ColorMap::multiply( vec3( 186, 178, 170 ), 0.4 ); // rock
    static const vec3 dirt = ColorMap::multiply( vec3( 152, 113, 98 ), 1.0 );   // dirt
    static const vec3 trees = ColorMap::multiply( vec3( 45,  55, 29 ), 1.5 );   // trees
    static const vec3 yellowGrass = ColorMap::multiply( vec3( 84, 97, 20 ), 1.0 );   // yellowGrass
    static const vec3 shore = ColorMap::multiply( vec3( 0, 128, 255 ), 0.4 );   // shore
    static const vec3 shallow = ColorMap::multiply( vec3( 0, 102, 255 ), 0.3 );   // shallow
    static const vec3 deeps = ColorMap::multiply( vec3( 0, 51, 255 ), 0.2 );   // deeps
    static const vec3 sand = ColorMap::multiply( vec3( 168, 168, 128 ), 1.5 );   // sand
}

using namespace terra;

ColorMap::ColorMap() {
    texture = NULL;
    buffer = NULL;
}

ColorMap::~ColorMap() {
    if( texture != NULL ) delete texture;
    if( buffer != NULL ) delete buffer;
}

void ColorMap::init() {
    width = 128;
    height = 2048;
    buffer = new UbytePixelBuffer( width, height, GL_UNSIGNED_BYTE, 3, GL_RGB, GL_RGB );
    texture = new Texture();

    buffer->clearBuffer();

    for( int i = 0; i < width; i++ ) { //slope
        for( int j = 0; j < height; j++ ) { //height
            addColor( i, j, vec3( 0 ) );
            if( j <= 0.03 * height )
                addColor( i, j, glm::mix( deeps, shallow, j / ( 0.03f * height ) ) );
            if( j <= 0.06 * height && j > 0.03 * height )
                addColor( i, j, glm::mix( shallow, shore, ( j - 0.03f * height ) / ( 0.03f * height ) ) );
            if( j <= 0.1 * height && j > 0.06 * height )
                addColor( i, j, glm::mix( shore, sand, ( j - 0.06f * height ) / ( 0.04f * height ) ) );

            if( j <= 0.2 * height && j > 0.1 * height ) {
                if( i <= 0.5 * width )
                    addColor( i, j, glm::mix( sand, rock, ( j - 0.1f * height ) / ( 0.1f * height ) ) );
                if( i <= 0.76 * width && i > 0.5 * width )
                    addColor( i, j, glm::mix( sand, trees, ( j - 0.1f * height ) / ( 0.1f * height ) ) );
                if( i <= 0.98 * width && i > 0.76 * width )
                    addColor( i, j, glm::mix( sand, trees, ( j - 0.1f * height ) / ( 0.1f * height ) ) );
                if( i > 0.98 * width )
                    addColor( i, j, glm::mix( sand, yellowGrass, ( j - 0.1f * height ) / ( 0.1f * height ) ) );
            }

            if( j <= 0.6 * height && j > 0.2 * height ) {
                if( i <= 0.76 * width )
                    addColor( i, j, rock );
                if( i <= 0.98 * width && i > 0.76 * width )
                    addColor( i, j, trees );
                if( i > 0.98 * width )
                    addColor( i, j, yellowGrass );
            }
            /*
                        if( j<= 0.65*height && j > 0.6*height){
                            if( i <= 0.76*width)
                                addColor( i,j, rock );
                            if( i <= 0.98* width && i > 0.76*width )
                                //addColor( i,j, glm::mix( trees, yellowGrass, (j-0.6f*height )/ (0.05f*height) ) );
                                addColor( i,j, yellowGrass );
                            if( i > 0.98*width )
                                //addColor( i,j, glm::mix( yellowGrass, snow, (j-0.6f*height )/ (0.05f*height) ) );
                                addColor( i,j, yellowGrass );
                        }*/

            if( j <= 0.8 * height && j > 0.6 * height ) {
                if( i <= 0.76 * width )
                    addColor( i, j, rock );
                if( i <= 0.98 * width && i > 0.76 * width )
                    addColor( i, j, rock );
                if( i <= 0.996 * width && i > 0.98 * width )
                    addColor( i, j, yellowGrass );
                if( i > 0.996 * width )
                    addColor( i, j, snow );
            }

            if( j > 0.8 * height ) {
                if( i <= 0.76 * width )
                    addColor( i, j, rock );
                else
                    addColor( i, j, snow );
            }
        }
    }
    texture->load( *buffer );
    std::cout << "ColorMap loaded.\n";
}

void ColorMap::addColor( int i, int j, vec3 color ) {
    ( *buffer )( i, j, 0 ) = color.x;
    ( *buffer )( i, j, 1 ) = color.y;
    ( *buffer )( i, j, 2 ) = color.z;
}

GLuint ColorMap::getTextureID()const {
    return texture->getID();
}

vec3 ColorMap::multiply( const vec3& color, float coeff ) {
    std::uniform_int_distribution<int> uni(0, 125);
    int rndx=uni(rng);
    vec3 c = (color*vec3(rndx/85.f))+vec3(125-rndx,rndx/5,uni(rng)/5);
    return  clamp( c * coeff, vec3( 0 ), vec3( 255 ) );
}
