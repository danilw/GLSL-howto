#include <iostream>
#include "Config.h"
#include <random>

using namespace terra;

Config::Config() {
}

bool Config::loadConfigFile( std::string fileName ) {

    renderConfig.cameraFOV = 45;
    renderConfig.hdrExposure = 2;
    renderConfig.windowWidth = 1920;
    renderConfig.windowHeight = 1080;

    sceneConfig.cameraPos.x = -1.2;
    sceneConfig.cameraPos.y = 1.3;
    sceneConfig.cameraPos.z = -0.8;
    sceneConfig.lightPos.x = 0;
    sceneConfig.lightPos.y = 0;
    sceneConfig.lightPos.z = -1;

    planetConfig.patchDef = 32;
    planetConfig.dmapSize = 33;
    planetConfig.hmapSize = 256;
    planetConfig.nmapSize = 256;
    planetConfig.precisionFactor = 0.5;
    planetConfig.maxLod = 13;
    planetConfig.radius = 1.0;
    planetConfig.maxHeight = 0.02;
    planetConfig.atmInnerRadius = 1;
    planetConfig.atmOuterRadius = 1.025;
    planetConfig.sunDomeRadius = 9;
    std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<int> uni(0, 125);
    planetConfig.fractalScale = 0.58+uni(rng)/195.f;
    planetConfig.position.x = 0;
    planetConfig.position.y = 0;
    planetConfig.position.z = 0;


    std::cout << "version 0.1.9" << std::endl;

    return true;
}
