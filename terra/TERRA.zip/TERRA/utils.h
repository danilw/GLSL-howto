/**@file utils.h
 */
#ifndef UTILS_H
#define UTILS_H

/** @namespace terra
*/
namespace terra {

    /** @enum RenderMode
     * Type de rendu
     */
    enum RenderMode {
        POLYGON,
        LINE,
        OBBOX,
    };

    /** V�rifie si une erreur OpengGL a eu lieu
     * @param verbose 'true' affiche l'erreur, 'false' n'affiche rien
     */
    void getGLError( bool verbose );
}

#endif // UTILS_H
