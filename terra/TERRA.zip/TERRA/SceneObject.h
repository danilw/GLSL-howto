/**@file SceneObject.h
 */
 #ifndef SCENEOBJECT_H
#define SCENEOBJECT_H

// Includes GLM
#include <glm/glm.hpp>

#include "utils.h"

namespace terra {
    class SceneObject {
    public:
        SceneObject( glm::vec3 position );
        virtual ~SceneObject();

        virtual void update() = 0;

        virtual void render( const glm::mat4 &projection, const glm::mat4 &modelview, RenderMode renderMode ) = 0;

    protected:
        glm::vec3 position; 
    };
}
#endif // SCENEOBJECT_H
