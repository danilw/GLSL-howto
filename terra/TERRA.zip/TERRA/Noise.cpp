#include "Noise.h"
#include <iostream>

using namespace glm;
using namespace terra;


vec3 Noise::mod289( const vec3 &x ) {
    return x - glm::floor( x * ( 1.0f / 289.0f ) ) * 289.0f;
}

vec4 Noise::mod289( const vec4 &x ) {
    return x - glm::floor( x * ( 1.0f / 289.0f ) ) * 289.0f;
}

vec4 Noise::permute( const vec4 &x ) {
    return mod289( ( ( x * 34.0f ) + 1.0f ) * x );
}

vec4 Noise::taylorInvSqrt( const vec4 &r ) {
    return 1.79284291400159f - 0.85373472095314f * r;
}

float Noise::simplexNoise( vec3 point ) {

    const vec2 C = vec2( 1.0 / 6.0, 1.0 / 3.0 ) ;
    const vec4 D = vec4( 0.0, 0.5, 1.0, 2.0 );

// First corner
    vec3 i = floor( point + glm::dot( point, vec3( C.y, C.y, C.y ) ) );;
    vec3 x0 = point - i + glm::dot( i, vec3( C.x, C.x, C.x ) ) ;

// Other corners
    vec3 g = step( vec3( x0.y, x0.z, x0.x ), vec3( x0.x, x0.y, x0.z ) );
    vec3 l = 1.0f - g;
    vec3 i1 = min( vec3( g.x, g.y, g.z ), vec3( l.z, l.x, l.y ) );
    vec3 i2 = max( vec3( g.x, g.y, g.z ), vec3( l.z, l.x, l.y ) );

    // x0 = x0 - 0.0 + 0.0 * C.xxx;
    // x1 = x0 - i1 + 1.0 * C.xxx;
    // x2 = x0 - i2 + 2.0 * C.xxx;
    // x3 = x0 - 1.0 + 3.0 * C.xxx;
    //vec3 x1 = x0 - i1 + C.xxx;
    vec3 x1 = x0 - i1 + vec3( C.x, C.x, C.x );
    vec3 x2 = x0 - i2 + vec3( C.y, C.y, C.y );  // 2.0*C.x = 1/3 = C.y
    vec3 x3 = x0 - vec3( D.y, D.y, D.y );  // -1.0+3.0*C.x = -0.5 = -D.y

// Permutations
    i = mod289( i );
    vec4 p = permute( permute( permute(
                                   i.z + vec4( 0.0, i1.z, i2.z, 1.0 ) )
                               + i.y + vec4( 0.0, i1.y, i2.y, 1.0 ) )
                      + i.x + vec4( 0.0, i1.x, i2.x, 1.0 ) );

// Gradients: 7x7 points over a square, mapped onto an octahedron.
// The ring size 17*17 = 289 is close to a multiple of 49 (49*6 = 294)
    float n_ = 0.142857142857; // 1.0/7.0
    vec3 ns = n_ * vec3( D.w, D.y, D.z ) - vec3( D.x, D.z, D.x );

    vec4 j = p - 49.0 * floor( p * ns.z * ns.z );  // mod(p,7*7)

    vec4 x_ = floor( j * ns.z );
    vec4 y_ = floor( j - 7.0 * x_ );  // mod(j,N)

    vec4 x = x_ * ns.x + vec4( ns.y, ns.y, ns.y, ns.y );
    vec4 y = y_ * ns.x + vec4( ns.y, ns.y, ns.y, ns.y );
    vec4 h = 1.0 - abs( x ) - abs( y );

    vec4 b0 = vec4( vec2( x.x, x.y ), vec2( y.x, y.y ) );
    vec4 b1 = vec4( vec2( x.z, x.w ), vec2( y.z, y.w ) );

    //vec4 s0 = vec4(lessThan(b0,0.0))*2.0 - 1.0;
    //vec4 s1 = vec4(lessThan(b1,0.0))*2.0 - 1.0;
    vec4 s0 = floor( b0 ) * 2.0 + 1.0;
    vec4 s1 = floor( b1 ) * 2.0 + 1.0;
    vec4 sh = -step( h, vec4( 0.0 ) );

    vec4 a0 = vec4( b0.x, b0.z, b0.y, b0.w ) + vec4( s0.x, s0.z, s0.y, s0.w ) * vec4( sh.x, sh.x, sh.y, sh.y );
    vec4 a1 = vec4( b1.x, b1.z, b1.y, b1.w ) + vec4( s1.x, s1.z, s1.y, s1.w ) * vec4( sh.z, sh.z, sh.w, sh.w );

    vec3 p0 = vec3( a0.x, a0.y, h.x );
    vec3 p1 = vec3( a0.z, a0.w, h.y );
    vec3 p2 = vec3( a1.x, a1.y, h.z );
    vec3 p3 = vec3( a1.z, a1.w, h.w );

//Normalise gradients
    vec4 norm = taylorInvSqrt( vec4( glm::dot( p0, p0 ), glm::dot( p1, p1 ), glm::dot( p2, p2 ), glm::dot( p3, p3 ) ) );
    p0 *= norm.x;
    p1 *= norm.y;
    p2 *= norm.z;
    p3 *= norm.w;

// Mix final noise value
    vec4 m = max( 0.6 - vec4( glm::dot( x0, x0 ), glm::dot( x1, x1 ), glm::dot( x2, x2 ), glm::dot( x3, x3 ) ), 0.0 );
    m = m * m;
    return 42.0 * glm::dot( m * m, vec4( glm::dot( p0, x0 ), glm::dot( p1, x1 ),
                                    glm::dot( p2, x2 ), glm::dot( p3, x3 ) ) );
}
