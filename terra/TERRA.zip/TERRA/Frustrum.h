/**@file Frustrum.h
 */
#ifndef FRUSTRUM_H
#define FRUSTRUM_H

// Includes GLM
#include <glm/glm.hpp>

#include "Geometry.h"

namespace terra {


    class Frustrum {
        typedef Plane PlaneArray[6];

    public:
        Frustrum();
        ~Frustrum();

        void setCameraParams( float fov, float ratio, float nearD, float farD );
        void setCameraLookAt( const glm::vec3& position, const glm::vec3& lookAtPoint, const glm::vec3& verticalAxis );


        const PlaneArray& getPlanes()const;

        void updateNearFar(const glm::vec3& position, float nd, float fd);

    private:
        glm::vec3 ntl, ntr, nbl, nbr, ftl, ftr, fbl, fbr; 
        float nearD; 
        float farD; 
        float ratio;
        float fov; 
        float tang; 
        float nw; 
        float nh;
        float fw; 
        float fh; 
        Plane planes[6]; 
        glm::vec3 X,Y,Z; 
        glm::vec3 nc, fc;
    };
}
#endif // FRUSTRUM_H
