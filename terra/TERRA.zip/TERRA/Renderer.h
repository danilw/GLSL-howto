/**@file Renderer.h
 */
#ifndef RENDERER_H
#define RENDERER_H

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

// Includes GLM
#include <glm/glm.hpp>

#include <SDL2/SDL.h>
#include "Scene.h"
#include "Config.h"
#include "Quad.h"
#include "FrameBuffer.h"
#include "utils.h"

namespace terra {

    class Renderer {
    public:

        Renderer( const RenderConfig& config, Scene* scene );
        ~Renderer();
        void init();
        void update();
        void toggleCulling();
        void toggleHDR();
        void toggleFrustrumUpdate();
        void nextRenderMode();

    private:
        void render();

        Scene* scene; 
        Camera* camera; 
        Shader* hdrShader; 
        RenderingQuad* hdrQuad; 
        FrameBuffer* frameBuffer; 
        float hdrExposure;
        float fov;
        float viewRatio;
        bool frustrumUpdate;
        bool culling;
        bool hdr;
        int frameBufferWidth;
        int frameBufferHeight;
        GLuint frameBufferID;
        RenderMode renderMode;
        glm::mat4 projection; 
        glm::mat4 modelview; 
    };
}
#endif // RENDERER_H
