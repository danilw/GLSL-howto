/**@file Scene.h
 */
 #ifndef SCENE_H
#define SCENE_H

// Includes GLM
#include <glm/glm.hpp>

#include <vector>

#include "Config.h"
#include "Camera.h"
#include "Planet.h"
#include "utils.h"

namespace terra {

    class Scene {
    public:
        Scene();
        ~Scene();

        void loadConfig( const SceneConfig& sceneConfig, const PlanetConfig& planetConfig );


        void addObject( SceneObject* object );


        void updateScene();

        //void render( const glm::mat4 &projection, const glm::mat4 &modelview )const;


        std::vector<SceneObject*> getSceneObjects() const;

        //void updateCameraProj( float fov, float ratio, float nearD, float farD );
        //void updateCameraView();


        Camera* getCamera();


        const glm::vec3* getLight() const;

    private:
        std::vector<SceneObject*> sceneObjects; 
        Camera camera; 
        glm::vec3 light; 
        terra::RenderMode renderMode;
    };
}
#endif // SCENE_H
