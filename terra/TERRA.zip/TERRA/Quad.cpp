#include <glm/gtx/transform.hpp>

#include "Quad.h"
using namespace glm;
using namespace terra;

Quad::Quad( vec2 topLeftCorner, vec2 bottomRightCorner ) : Renderable() {
    this->topLeftCorner = topLeftCorner;
    this->bottomRightCorner = bottomRightCorner;
    build();
    load();
}

void Quad::addVertex( vec3 vert, vec2 uv, int& count, int& countUV ) {
    vertices[count++] = vert.x;
    vertices[count++] = vert.y;
    vertices[count++] = vert.z;

    texCoord2D[countUV++] = uv.x;
    texCoord2D[countUV++] = uv.y;
}

void Quad::build() {
    verticesCount = 4 * 3;
    vertices = new float[verticesCount];

    texCoordCount = 4 * 2;
    texCoord2D = new float[texCoordCount];

    float width = bottomRightCorner.x - topLeftCorner.x;
    float height = bottomRightCorner.y -  topLeftCorner.y;
    int count = 0;
    int countUV = 0;
    addVertex( vec3( topLeftCorner.x, topLeftCorner.y, 0.0 ), vec2( 0.0, 0.0 ), count, countUV ); //1
    addVertex( vec3( topLeftCorner.x + width, topLeftCorner.y, 0.0 ), vec2( 1.0, 0.0 ), count, countUV ); //3
    addVertex( vec3( topLeftCorner.x, topLeftCorner.y + height, 0.0 ), vec2( 0.0, 1.0 ), count, countUV ); //2
    addVertex( vec3( topLeftCorner.x + width, topLeftCorner.y + height, 0.0 ), vec2( 1.0, 1.0 ), count, countUV ); //4
}

void Quad::draw()const {
    bool cull = glIsEnabled( GL_CULL_FACE );
    //glDisable(GL_CULL_FACE);
    glBindVertexArray( vaoID );
    glDrawArrays( GL_TRIANGLE_STRIP, 0, 4 );
    glBindVertexArray( 0 );
    if( cull )
        glEnable( GL_CULL_FACE );
}


RenderingQuad::RenderingQuad( float exposure, GLuint textureId, const Shader* shader ) {
    this->shader = shader;
    this->textureId = textureId;
    this->exposure = exposure;
    quad = new Quad( vec2( -1, -1 ), vec2( 1, 1 ) );
    shaderID = shader->getProgramID();
}

RenderingQuad::~RenderingQuad() {
    delete quad;
}

void RenderingQuad::render() {
    glUseProgram( shaderID );
    glUniform1f( glGetUniformLocation( shaderID, "exposure" ), exposure );
    glUniform1i( glGetUniformLocation( shaderID, "map" ), 0 );

    glActiveTexture( GL_TEXTURE0 );
    glBindTexture( GL_TEXTURE_2D, textureId );
    quad->draw();

    glBindTexture( GL_TEXTURE_2D, 0 );
    glUseProgram( 0 );
}
