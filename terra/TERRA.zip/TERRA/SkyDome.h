/**@file SkyDome.h
 */
#ifndef SKYDOME_H
#define SKYDOME_H

// Includes GLM
#include <glm/glm.hpp>

#include "Sphere.h"
#include "Camera.h"
#include "ScatteringShader.h"

namespace terra {

    class SkyDome {
    public:

        SkyDome( glm::vec3 position, float minRadius, float maxRadius, const Camera* camera, const glm::vec3* lightPos, const ScatteringShader* shader );
        ~SkyDome();

        void render( const glm::mat4& projection, const glm::mat4& modelview );

    private:
        float minRadius;
        float maxRadius;
        Sphere* skySphere;
        const ScatteringShader* shader;
        const Camera* camera;
        const glm::vec3* lightPos;
        glm::vec3 position;
    };
}
#endif // SKYDOME_H
