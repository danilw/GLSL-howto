/**@file OpenGLApp.h
 */
#ifndef OPENGLAPP_H
#define OPENGLAPP_H

#include <SDL2/SDL.h>
#include <string>

#include "Input.h"
#include "Config.h"
#include "Renderer.h"
#include "utils.h"
#include "emscripten/html5.h"
#include <emscripten.h>

#define APP_EXIT 0
#define APP_CONTINUE 1

namespace terra {

    class OpenGLApp {
    public:

        OpenGLApp( const Config* config, std::string windowTitle, int windowWidth, int windowHeigth );
        ~OpenGLApp();

        bool init();

        void start();

    private:
        bool windowInit();
        bool OGLInit();
        void computeFPS();

        int handleInput( float elapsedTime );

        std::string windowTitle; 
        int windowWidth; 
        int windowHeight; 
        SDL_Window* window; 
        SDL_GLContext OGLContext; 
        SDL_Renderer* renderer_sdl;
        bool Pp,gFullscreen;
        Input input; 
        const Config* config;  
        Scene scene; 
        Renderer* renderer; 
    };
}
#endif // OPENGLAPP_H
