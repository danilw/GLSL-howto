#include "Camera.h"
#include <iostream>

using namespace glm;
using namespace terra;

Camera::Camera() : eye( 1, 1, 1 ), yAxis( 0, 1, 0 ) , lookAtPoint( 0, 0, 0 ), frustrumUpdate( true ) {
    lookAt( eye, lookAtPoint, yAxis );
    eyeOldPos=eye;
    needreset=false;
    cits=true;
    lastsp=1;
    //updateViewMatrix();
}

Camera::Camera( const vec3& position, const vec3& lookAtPoint, const vec3& verticalAxis ) : eye( position ), lookAtPoint( lookAtPoint ), frustrumUpdate( true ) {
    lookAt( position, lookAtPoint, verticalAxis );
    eyeOldPos=eye;
    needreset=false;
    cits=true;
    lastsp=1;
    //updateViewMatrix();
}

Camera::~Camera() {

}

void Camera::updateProjection( float fov, float viewRatio, float nearD, float farD ) {
    this->fov = fov;
    this->viewRatio = viewRatio;
    this->nearD = nearD;
    this->farD = farD;
    projMatrix = perspective( fov, viewRatio, nearD, farD );
    frustrum.setCameraParams( fov, viewRatio, nearD, farD );
}

void Camera::updateProjectionNearFar( float nearD, float farD ) {
    this->nearD = nearD;
    this->farD = farD;
    frustrum.setCameraParams( fov, viewRatio, nearD, farD );
    //projMatrix = perspective( fov, viewRatio, nearD, farD );
}

void Camera::lookAt( const vec3& position, const vec3& lookAtPoint, const vec3& verticalAxis ) {

    eye = position;
    this->lookAtPoint = lookAtPoint;

    zAxis = normalize( eye - lookAtPoint );
    yAxis = normalize( verticalAxis );
    xAxis = normalize( cross( yAxis, zAxis ) );
    yAxis = cross( zAxis, xAxis );

    viewDir = -zAxis;

    viewMatrix = dmat4( 1.0 );
    viewMatrix[0][0] = xAxis.x;
    viewMatrix[1][0] = xAxis.y;
    viewMatrix[2][0] = xAxis.z;
    viewMatrix[3][0] = -dot( xAxis, eye );

    viewMatrix[0][1] = yAxis.x;
    viewMatrix[1][1] = yAxis.y;
    viewMatrix[2][1] = yAxis.z;
    viewMatrix[3][1] = -dot( yAxis, eye );

    viewMatrix[0][2] = zAxis.x;
    viewMatrix[1][2] = zAxis.y;
    viewMatrix[2][2] = zAxis.z;
    viewMatrix[3][2] = -dot( zAxis, eye );

    //viewMatrix = lookAt(eye, lookAtPoint, yAxis);
    orientation = quat_cast( viewMatrix );
    normalize( orientation );

    updateFrustrum();
}

void Camera::setLookAtPoint( const vec3& point ) {
    lookAtPoint = point;
    lookAt( eye, lookAtPoint, yAxis );
}

void Camera::resetPos() {
	needreset=true;
}

void Camera::cameraits() {
    cits = !cits;
    if( cits )
        std::cout << "collision : ON" << std::endl;
    else
        std::cout << "collision : OFF" << std::endl;
}

void Camera::nextPos() {
	if(needreset)setPosition(eyeOldPos);
	else eyeOldPos=eye;
	needreset=false;
	
}

void Camera::setPosition( const vec3& point ) {
    eye = point;
    lookAtPoint = eye + viewDir;
    lookAt( eye, lookAtPoint, yAxis );
}

void Camera::rotate( float x, float y, float z ) {

    //std::cout<<headingAngle<<std::endl;
    if( z > 360.0 ) {
        z -= 360.0;
    } else if( z < -360.0 ) {
        z += 360.0;
    }

    if( x > 360.0 ) {
        x -= 360.0;
    } else if( x < -360.0 ) {
        x += 360.0;
    }

    if( y > 360.0 ) {
        y -= 360.0;
    } else if( y < -360.0 ) {
        y += 360.0;
    }

    quat rotationQuaternion, headingQuaternion, pitchQuaternion, rollQuaternion;

    pitchQuaternion = angleAxis( y, xAxis );
    headingQuaternion = angleAxis( x, yAxis );
    rollQuaternion = angleAxis( z, zAxis );
    rotationQuaternion = pitchQuaternion * headingQuaternion * rollQuaternion;

    //On pivote aussi le point cible
    lookAtPoint = eye + ( lookAtPoint - eye ) * rotationQuaternion;
    orientation = orientation * rotationQuaternion;
    normalize( orientation );

}

void Camera::moveLateralAxis( float amount ) {
    vec3 eyeOldPos = eye;
    eye = eye + xAxis * amount;
    lookAtPoint = lookAtPoint - ( eyeOldPos - eye );
}

void Camera::moveViewAxis( float amount ) {
    vec3 eyeOldPos = eye;
    eye = eye + viewDir * amount;
    lookAtPoint = lookAtPoint - ( eyeOldPos - eye );
}

void Camera::updateFrustrum() {
    if( frustrumUpdate )
        frustrum.setCameraLookAt( eye, lookAtPoint, yAxis );
}

void Camera::updateViewMatrix() {
    viewMatrix = mat4_cast( orientation );
    //viewMatrix = viewMatrix;

    xAxis = vec3( viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0] );
    yAxis = vec3( viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1] );
    zAxis = vec3( viewMatrix[0][2], viewMatrix[1][2], viewMatrix[2][2] );
    viewDir = -zAxis;

    viewMatrix[3][0] = -dot( xAxis, eye );
    viewMatrix[3][1] = -dot( yAxis, eye );
    viewMatrix[3][2] = -dot( zAxis, eye );
}
void Camera::updateMatrix() {
    updateViewMatrix();
    updateFrustrum();
}

const mat4& Camera::getViewMatrix()const {
    return viewMatrix;
}

const mat4& Camera::getProjMatrix()const {
    return projMatrix;
}

Frustrum Camera::getFrustrum()const {
    return frustrum;
}

/*vec3 Camera::getLookAtPoint() const {
    return lookAtPoint;
}*/

/*vec3 Camera::getUpAxis() const {
    return yAxis;
}*/

vec3 Camera::getPosition() const {
    return eye;
}

void Camera::setFrustrumUpdate( bool update ) {
    frustrumUpdate = update;
}
