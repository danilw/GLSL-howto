/**@file OBB.h
 */
#ifndef OBB_H
#define OBB_H

// Includes GLM
#include <glm/glm.hpp>

#include "Box.h"
#include "Geometry.h"
#include "cube_utils.h"

namespace terra {


    class OBB : public Box {
    public:
        enum IntersectType {
            IT_Outside,
            IT_Intersect,
            IT_Inside
        };
        OBB( const Base& base, const glm::vec3& minP, const glm::vec3 &maxP, const glm::vec3* patchCorners, const Shader* shader );
        ~OBB();

        void setColor( const glm::vec4& color );

        glm::vec3 getMin()const;

        glm::vec3 getMax()const;

        IntersectType testInBoundingPlanes( const Plane planes[] )const;

        float minDistanceFromPointSq( const glm::vec3& p )const;

        float minDistanceFromPoint( const glm::vec3& p )const;

        Base getBase()const;

        glm::vec3 getProxyPoint()const;

        bool isBehindHorizon( glm::vec3 observerPos );

        static OBB* createOBB( const glm::vec3& O, cubeFace face, float width, float maxHeight, float fractalScale, float radius, Shader* shader );
    protected:
        void init8Points( glm::vec3& a0, glm::vec3& a1, glm::vec3& a2, glm::vec3& a3, glm::vec3& b0, glm::vec3& b1, glm::vec3& b2, glm::vec3& b3 )const;
    private:
        OBB();
        static float getHeight( glm::vec3 pos, float maxHeight, float fractalScale );
        glm::vec3 getMinLocal()const;
        glm::vec3 getMaxLocal()const;
        glm::vec3 localToWorld( const glm::vec3& p )const;
        glm::vec3 worldToLocal( const glm::vec3& p )const;
        glm::vec3 computeProxyPoint();

        glm::vec3 getVertexP( const glm::vec3& normal )const;

        glm::vec3 getVertexN( const glm::vec3& normal )const;
        Base base; 
        float x, y, z; 
        float radius; 
        glm::vec3 PP; 
        const glm::vec3* patchCorners; 

    };

}//namespace terra

#endif // OBB_H
