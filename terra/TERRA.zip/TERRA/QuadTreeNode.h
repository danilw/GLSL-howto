/**@file QuadTreeNode.h
 */
#ifndef QUADTREENODE_H
#define QUADTREENODE_H

// Includes GLM
#include <glm/glm.hpp>

#include "TerrainTile.h"
#include "Shader.h"
#include "ScatteringShader.h"
#include "Config.h"
#include "OBB.h"
#include "utils.h"

namespace terra {

    class LODQuadTree;

    class QuadTreeNode {
    public:

        QuadTreeNode( const PlanetConfig* config, const TileInfos* tileInfos, Camera* camera );
        ~QuadTreeNode();

        void updateNode();

        void render( const glm::mat4 &projection, const glm::mat4 &modelview, terra::RenderMode renderMode );

    private:

        bool split();


        void merge();

        bool isLeaf;
        OBB* obBox; 
        QuadTreeNode* childNodes[4]; 
        const TileInfos* tileInfos;
        int level;
        TerrainTile* patch;
        Camera* camera;
        const PlanetConfig* config;
        //Box* b1;
    };

    class LODQuadTree {
    public:

        LODQuadTree( const PlanetConfig& config, Camera* camera, const glm::vec3* lightPos, TerrainShaders* tileShaders );
        ~LODQuadTree();
        void render( const glm::mat4 &projection, const glm::mat4 &modelview, terra::RenderMode renderMode );
        void updateTree();
    private:
        Shader* pBoxShader;
        PatchFactory patchFactory;
        ColorMap colorMap;
        QuadTreeNode* rootNodes[6];
        Camera* camera;
    };
}
#endif // QUADTREENODE_H
