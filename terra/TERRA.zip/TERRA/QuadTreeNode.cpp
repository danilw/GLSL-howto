#include <SDL2/SDL.h>
#include "QuadTreeNode.h"
#include "Geometry.h"
#include "Noise.h"

int nbNodes = 0;
extern int nbPatches;

using namespace terra;
using namespace glm;

LODQuadTree::LODQuadTree( const PlanetConfig& config, Camera* camera, const vec3* lightPos, TerrainShaders* tileShaders ) {
    this->camera = camera;
    pBoxShader  = new Shader( "Shaders/default.vert", "Shaders/default.frag" );

    patchFactory.createdCGSphericPatch( config.patchDef, 2.0f );
    patchFactory.createdCGPatch( 1, 2.0f );

    colorMap.init();
    Base worldBase( vec3( 0.0f, 1.0f, 0.0f ), vec3( 1.0f, 0.0f, 0.0f ), vec3( 0.0f, 1.0f, 0.0f ), vec3( 0.0f, 0.0f, 1.0f ) );

    TileInfos* tileInfos[6];
    for( int i = 0; i < 6; i++ ) {
        tileInfos[i] = new TileInfos();
        //tileInfos[i]->localBase = worldBase;
        tileInfos[i]->worldBase = worldBase;
        tileInfos[i]->tileShaders.shader = tileShaders->shader;
        tileInfos[i]->tileShaders.heightMapShader = tileShaders->heightMapShader;
        tileInfos[i]->tileShaders.displacementMapShader = tileShaders->displacementMapShader;
        tileInfos[i]->tileShaders.normalMapShader = tileShaders->normalMapShader;
        tileInfos[i]->boxShader = pBoxShader;
        tileInfos[i]->patchFactory = &patchFactory;
        tileInfos[i]->colorMap = &colorMap;
        tileInfos[i]->face = (cubeFace)i;
        tileInfos[i]->level = 0;
        tileInfos[i]->width = 2.0f;
        rootNodes[i] = new QuadTreeNode( &config, tileInfos[i], camera );
    }
}

LODQuadTree::~LODQuadTree() {
    std::cout << "LODQuadTree destructor... " << std::endl;
    for( int i = 0; i < 6; i++ ) {
        delete rootNodes[i];
    }
    std::cout << "nbNodes : " << nbNodes << std::endl;
    std::cout << "nbPatches : " << nbPatches << std::endl;
    delete pBoxShader;
}

void LODQuadTree::updateTree() {
    for( int i = 0; i < 6; i++ ) {
        rootNodes[i]->updateNode();
    }
}

void LODQuadTree::render( const mat4 &projection, const mat4 &modelview, RenderMode renderMode ) {

    for( int i = 0; i < 6; i++ ) {
        rootNodes[i]->render( projection, modelview, renderMode );
    }
}

QuadTreeNode::QuadTreeNode( const PlanetConfig* config, const TileInfos* tileInfos, Camera* camera ) {
    this->config = config;
    this->tileInfos = tileInfos;
    this->camera = camera;
    level = tileInfos->level;
    for( int i = 0; i < 4 ; i++ )
        childNodes[i] = NULL;
    patch = NULL;
    isLeaf = true;
    obBox = OBB::createOBB( tileInfos->worldBase.origin, tileInfos->face, tileInfos->width, config->maxHeight, config->fractalScale, config->radius, tileInfos->boxShader);
    obBox->build();
    //vec3 proxyPoint = obBox->getProxyPoint();
    //b1 = new Box( proxyPoint, 0.025 * tileInfos->width , vec4 ( 1.0, 0.0, 0.0, 1.0 ), tileInfos->boxShader );
    //b1->build();
    nbNodes++;
}

QuadTreeNode::~QuadTreeNode() {
    if( patch != NULL )
        delete patch;
    delete obBox;
    //delete b1;
    delete tileInfos;
    for( int i = 0; i < 4 ; i++ ) {
        if( childNodes[i] != 0 ) {
            delete childNodes[i];
        }
    }
    nbNodes--;
}

void QuadTreeNode::updateNode() {
    vec3 cameraPos = camera->getPosition();

    OBB::IntersectType intersect = obBox->testInBoundingPlanes( camera->getFrustrum().getPlanes() );
    bool behindHorizon = true;
    if( intersect != OBB::IT_Outside )
        behindHorizon = obBox->isBehindHorizon( cameraPos );


    if( intersect == OBB::IT_Outside )
        obBox->setColor( vec4( 0.0, 0.0, 1.0, 1.0 ) );
    else if( intersect == OBB::IT_Intersect )
        obBox->setColor( vec4( 1.0, 1.0, 0.0, 1.0 ) );
    else if( intersect == OBB::IT_Inside )
        obBox->setColor( vec4( 0.0, 1.0, 0.0, 1.0 ) );

    /*if( behindHorizon )
        obBox->setColor( vec4( 1.0, 0.0, 0.0, 1.0 ) );*/

	if(camera->cits){
	if( intersect == OBB::IT_Outside){
	float tval=obBox->minDistanceFromPoint( cameraPos );
	if( tval<0.0015 ){
	camera->resetPos();camera->lastsp=0;
	}else{
		camera->lastsp=std::min(camera->lastsp,tval);
		}
	}}else camera->lastsp=1;

    if( intersect == OBB::IT_Outside || behindHorizon == true ) {
        isLeaf = false;
        merge();
        if( patch != NULL ) {
            delete patch;
            patch = NULL;
        }
        return;
    }

    float distanceToEdge = obBox->minDistanceFromPoint( cameraPos );
    float errorFactor = config->precisionFactor * tileInfos->width * config->radius / ( distanceToEdge );
    if( errorFactor > 1.0f ) {  
        if( split() ) {  
            isLeaf = false;
            if( patch != NULL ) {
                delete patch;
                patch = NULL;
            }
            for( int i = 0; i < 4; i++ ) {
                if( childNodes[i] != NULL ) {
                    childNodes[i]->updateNode( );
                }
            }
        }
    } else {
        isLeaf = true;
        if( patch == NULL ) {
            patch = new TerrainTile( tileInfos, config );
            patch->build();
        }
        merge();
    }
}

void QuadTreeNode::merge() {
    for( int i = 0; i < 4; i ++ ) {
        if( childNodes[i] != 0 ) {
            delete childNodes[i];
            childNodes[i] = NULL;
        }
    }
}

bool QuadTreeNode::split() {
    if( level + 1 > config->maxLod )
        return false;

    //Base currBase = tileInfos->base;
    vec3 center = tileInfos->worldBase.origin;
    float width = tileInfos->width;
    vec3 cornerPoint[4];
    //getSplitFaceOrigins(size/2.0, origin, origins[4]);
    cornerPoint[0] = vec3( center.x - width / 2.0, center.y, center.z + width / 2.0 );  //TOP LEFT
    cornerPoint[1] = vec3( center.x + width / 2.0, center.y, center.z + width / 2.0 );  //TOP RIGHT
    cornerPoint[2] = vec3( center.x - width / 2.0, center.y, center.z - width / 2.0 );  //BOTTOM LEFT
    cornerPoint[3] = vec3( center.x + width / 2.0, center.y, center.z - width / 2.0 );  //BOTTOM RIGHT
    TileInfos* newpatchInfos[4];
    for( int i = 0; i < 4; i++ ) {
        if( childNodes[i] == NULL ) { 
            vec3 childCenterPoint = vec3( ( cornerPoint[i].x  + center.x ) / 2.0, center.y, ( cornerPoint[i].z  + center.z ) / 2.0 );
            //Base localBase = tileInfos->localBase;
            //localBase.origin = childCenterPoint;
            Base worldBase = tileInfos->worldBase;
            worldBase.origin = childCenterPoint;
            newpatchInfos[i] = new TileInfos();
            *newpatchInfos[i] = *tileInfos;
            //newpatchInfos[i]->localBase = localBase;
            newpatchInfos[i]->worldBase = worldBase;
            newpatchInfos[i]->width = width / 2.0;
            newpatchInfos[i]->level = tileInfos->level + 1;
            childNodes[i] = new QuadTreeNode( config, newpatchInfos[i], camera );
        }
    }
    return true;
}


void QuadTreeNode::render( const mat4 &projection, const mat4 &modelview, RenderMode renderMode ) {

    for( int i = 0; i < 4; i ++ ) {
        if( childNodes[i] != NULL ) {
            childNodes[i]->render( projection, modelview, renderMode );
            isLeaf = false;
        }
    }

    if( !isLeaf )
        return;

    //Is a leaf ? -> effectuer le rendu
    if( renderMode == OBBOX ) {
        //glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
        obBox->render( projection, modelview );
        //b1->render( projection, modelview);
    }
    if( patch != NULL ) 
        patch->render( projection, modelview, renderMode);
}

