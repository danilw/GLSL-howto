/**@file Camera.h
 */
#ifndef CAMERA_H
#define CAMERA_H

// Includes GLM

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Input.h"
#include "Frustrum.h"

#define ROT_COEFF
#define MOVE_COEFF

namespace terra {

    class Camera {
    public:

        Camera();

        Camera( const glm::vec3& position, const glm::vec3& lookAtPoint, const glm::vec3& verticalAxis );
        ~Camera();


        void lookAt( const glm::vec3& position, const glm::vec3& lookAtPoint, const glm::vec3& verticalAxis );

        void updateProjection( float fov, float viewRatio, float nearD, float farD );

        void updateProjectionNearFar( float nearD, float farD );
        //glm::vec3 getLookAtPoint()const;
        //glm::vec3 getUpAxis()const;

        const glm::mat4 &getViewMatrix()const;

        const glm::mat4 &getProjMatrix()const;

        Frustrum getFrustrum()const;

        glm::vec3 getPosition()const;

        void setPosition( const glm::vec3& point );

        void setFrustrumUpdate( bool update );

        void setLookAtPoint( const glm::vec3& point );

        void updateMatrix();
        void resetPos();
        void nextPos();
        void cameraits();
        
        void rotate( float x, float y, float z );

        void moveLateralAxis( float amount );

        void moveViewAxis( float amount );
        float lastsp;
        bool cits;

    private:
        void updateViewMatrix();

        void updateFrustrum();
        //void move( Input const &input,  Uint32 elapsedTime, float scale );

        float viewRatio; 
        float nearD; 
        float farD; 
        float fov;
        Frustrum frustrum; 
        glm::vec3 eye;
        glm::vec3 xAxis; 
        glm::vec3 eyeOldPos;
        bool needreset;
        glm::vec3 yAxis;
        glm::vec3 zAxis; 
        glm::vec3 viewDir;  
        glm::vec3 lookAtPoint;
        glm::quat orientation; 
        glm::mat4 viewMatrix; 
        glm::mat4 projMatrix;
        bool frustrumUpdate; 
        //float inputScale;
    };
}
#endif // CAMERA_H
