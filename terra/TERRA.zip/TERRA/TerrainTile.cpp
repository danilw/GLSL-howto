#include "TerrainTile.h"

using namespace glm;
using namespace terra;

int nbPatches = 0;

TerrainTile::TerrainTile( const TileInfos* infos, const PlanetConfig* config ){
    this->config = config;
    this->patchFactory = infos->patchFactory;
    this->shader = infos->tileShaders.shader;
    this->hMapShader = infos->tileShaders.heightMapShader;
    this->nMapShader = infos->tileShaders.normalMapShader;
    this->dMapShader = infos->tileShaders.displacementMapShader;
    this->colorMap = infos->colorMap;
    this->center = infos->worldBase.origin;
    this->face = infos->face;
    this->width = infos->width;
    this->level = infos->level;
    sphericPatch = NULL;
    heightMap = NULL;
    normalMap = NULL;
    displacementMap = NULL;
    overlap = 0;
    computeOverlap( level );
    shaderID = shader->getProgramID();
    nbPatches++;
}

TerrainTile::~TerrainTile() {
    if( heightMap != NULL )
        delete heightMap;
    if( normalMap != NULL )
        delete normalMap;
    if( displacementMap != NULL )
        delete displacementMap;
    //if ( sphericPatch != NULL )
        //delete sphericPatch;
    nbPatches--;
}
void TerrainTile::computeOverlap( int level ) {
    switch( level ) {
    case 0:
    case 1:
    case 2:
        overlap = 0.005 * width;
        break;
        /*case 3:
        case 4:
        case 5:
            overlap = 0.05 * width;
            break;*/
    default:
        //overlap = 0.08 * width;
        overlap = 0.5 / config->patchDef * width;
    }

    width += overlap;


}
void TerrainTile::computeMatrix() {
    float scale = width / 2.0;
    transformMatrix = getCubeFaceMatrix( face );
    transformMatrix = glm::translate( transformMatrix, center.x, center.y, center.z );
    transformMatrix = glm::scale( transformMatrix, scale, scale, scale );

    float mapSize = config->dmapSize;
    float border = 1.0f;
    float s =  1.0 - border / ( mapSize );
    dmapMatrix = glm::translate( dmapMatrix, border / 2.0f / ( mapSize ), border / 2.0f / ( mapSize ), 0.0f );
    dmapMatrix = glm::scale( dmapMatrix, s, s, 1.0f );
    
}

void TerrainTile::build() {
    computeMatrix();

    /*sphericPatch = new SphericPatch ( config->patchDef, 2.0, transformMatrix, config->radius );
    sphericPatch->build();
    sphericPatch->buildNormal();
    sphericPatch->load();*/
    sphericPatch = patchFactory->getCGSphericPatch();
    hmapMatrix = sphericPatch->getTexMatrix();
    nmapMatrix = sphericPatch->getTexMatrix();
    dmapMatrix = sphericPatch->getTexMatrix() * dmapMatrix;

    CGPatch* cgPatch = patchFactory->getCGPatch();
    displacementMap = new LODCubeMap( config, cgPatch, center, level, face, width, config->dmapSize, 1, 0, dMapShader, false );
    displacementMap->build();
    displacementMap->renderToTexture();
    heightMap = new LODCubeMap( config, cgPatch, center, level, face, width, config->hmapSize, 0, 0, hMapShader, true );
    heightMap->build();
    heightMap->renderToTexture();
    normalMap = new NormalMap( config, cgPatch, center, level, face, width, config->nmapSize, 0, heightMap->getColorBufferId(), nMapShader );
    normalMap->build();
    normalMap->renderToTexture();
}



void TerrainTile::render( const mat4& projection, const mat4& modelview, RenderMode renderMode)const {
    glUseProgram( shaderID );

    glUniformMatrix4fv( glGetUniformLocation( shaderID, "projection" ), 1, GL_FALSE, value_ptr( projection ) );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "modelview" ), 1, GL_FALSE, value_ptr( modelview ) );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "transform" ), 1, GL_FALSE, value_ptr( transformMatrix ) );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "hmapMatrix" ), 1, GL_FALSE, value_ptr( hmapMatrix ) );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "nmapMatrix" ), 1, GL_FALSE, value_ptr( nmapMatrix ) );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "dmapMatrix" ), 1, GL_FALSE, value_ptr( dmapMatrix ) );


    glUniform1i( glGetUniformLocation( shaderID, "plane" ), face );
    glUniform1i( glGetUniformLocation( shaderID, "level" ), level );
    glUniform1f( glGetUniformLocation( shaderID, "width" ), width );
    glUniform1f( glGetUniformLocation( shaderID, "radius" ), config->radius );
    glUniform1i( glGetUniformLocation( shaderID, "heightmap" ), 0 );
    glUniform1i( glGetUniformLocation( shaderID, "normalmap" ), 1 );
    glUniform1i( glGetUniformLocation( shaderID, "displacementmap" ), 2 );
    glUniform1i( glGetUniformLocation( shaderID, "colormap" ), 3 );
    glUniform1i( glGetUniformLocation( shaderID, "hmapSize" ), config->hmapSize );
    glUniform1i( glGetUniformLocation( shaderID, "nmapSize" ), config->nmapSize );
    glUniform1i( glGetUniformLocation( shaderID, "dmapSize" ), config->dmapSize );
    glUniform1f( glGetUniformLocation( shaderID, "maxHeight" ), config->maxHeight );

    shader->sendScatteringUniforms();

    glActiveTexture( GL_TEXTURE0 );
    glBindTexture( GL_TEXTURE_2D, heightMap->getColorBufferId() );
    glActiveTexture( GL_TEXTURE1 );
    glBindTexture( GL_TEXTURE_2D, normalMap->getColorBufferId() );
    glActiveTexture( GL_TEXTURE2 );
    glBindTexture( GL_TEXTURE_2D, displacementMap->getColorBufferId() );
    glActiveTexture( GL_TEXTURE3 );
    glBindTexture( GL_TEXTURE_2D, colorMap->getTextureID() );

    if( sphericPatch != 0 ) {
        sphericPatch->draw(renderMode);
    }

    glBindTexture( GL_TEXTURE_2D, 0 );
    glUseProgram( 0 );
}
