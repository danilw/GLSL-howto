#include "Planet.h"

using namespace terra;
using namespace glm;

Planet::Planet( const PlanetConfig& config, Camera* camera, glm::vec3* light )
    : SceneObject( config.position ) {
    atmosphereShader = new ScatteringShader( "Shaders/sky.vert", "Shaders/sky.frag", config.atmInnerRadius, config.atmOuterRadius, camera, light );
    sunDomeShader = new ScatteringShader( "Shaders/sun.vert", "Shaders/sun.frag", config.atmOuterRadius, config.sunDomeRadius, camera, light );
    terrainShaders.shader = new ScatteringShader( "Shaders/terrain.vert", "Shaders/terrain.frag", config.radius, config.atmOuterRadius, camera, light );
    //terrainShaders.shader = new ScatteringShader( "Shaders/default.vert", "Shaders/default.frag", config.radius, config.atmOuterRadius, camera, light );
    terrainShaders.displacementMapShader = new Shader( "Shaders/displacementMap.vert", "Shaders/displacementMap.frag" );
    terrainShaders.heightMapShader = new Shader( "Shaders/heightmap.vert", "Shaders/heightmap.frag" );
    terrainShaders.normalMapShader = new Shader( "Shaders/normalmap.vert", "Shaders/normalmap.frag" );

    quadTree = new LODQuadTree( config, camera, light, &terrainShaders );
    atmosphere = new SkyDome( config.position, config.atmInnerRadius, config.atmOuterRadius, camera, light, atmosphereShader );
    sunDome = new SkyDome( config.position, config.atmOuterRadius, config.sunDomeRadius, camera, light, sunDomeShader );
}

Planet::~Planet() {
    delete terrainShaders.shader;
    delete terrainShaders.displacementMapShader;
    delete terrainShaders.heightMapShader;
    delete terrainShaders.normalMapShader;
    delete quadTree;
    delete atmosphereShader;
    delete atmosphere;
    delete sunDomeShader;
    delete sunDome;
}

void Planet::update() {
    quadTree->updateTree();
}

void Planet::render( const mat4 &projection, const mat4 &modelview, RenderMode renderMode  ) {
    quadTree->render( projection, modelview, renderMode );
    atmosphere->render( projection, modelview );
    sunDome->render( projection, modelview );
}
