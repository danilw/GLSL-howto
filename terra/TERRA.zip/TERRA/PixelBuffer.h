/**@file PixelBuffer.h
 */
#ifndef PIXELBUFFER_H
#define PIXELBUFFER_H

#include <string.h>

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

namespace terra {
    template <typename T>
    class PixelBuffer {

    public:

        PixelBuffer( int nWidth, int nHeight, GLuint nDataType = GL_UNSIGNED_BYTE, int nChannels = 3, GLuint nFormat = GL_RGB, GLuint nInternalFormat = GL_RGB );
        ~PixelBuffer();

        T& operator[]( int n );

        T& operator()( int x, int y, int k );

        int getWidth() const; 
        int getHeight() const; 
        GLuint getDataType() const; 
        int getChannels() const; 
        size_t getBufferSize() const; 
        T* getBuffer() const;
        GLuint getFormat() const; 
        GLuint getInternalFormat() const; 
        void clearBuffer(); 
    private:
        void init( int nWidth, int nHeight, int nDataType, int nChannels );
        void cleanup();
        int width;
        int height;
        GLuint dataType;
        int channels;
        size_t elementSize;
        GLuint format;
        GLuint internalFormat;
        T *buffer; 
    };

    typedef PixelBuffer<GLubyte> UbytePixelBuffer;
    typedef PixelBuffer<GLfloat> FloatPixelBuffer;
}
#endif // PIXELBUFFER_H
