#include "Scene.h"

using namespace glm;
using namespace terra;

Scene::Scene() {

}

Scene::~Scene() {
    for( std::size_t i = 0; i < sceneObjects.size(); i++ ) {
        delete sceneObjects[i];
    }
}

void Scene::loadConfig( const SceneConfig& sceneConfig, const PlanetConfig& planetConfig ) {
    light = sceneConfig.lightPos;
    camera.lookAt( sceneConfig.cameraPos, vec3( 0.0 ), vec3( 0.0, 1.0, 0.0 ) );
    addObject( new Planet(  planetConfig, &camera, &light ) );
    std::cout << "Scene loaded.\n";
}

void Scene::updateScene() {
    for( std::size_t i = 0; i < sceneObjects.size(); i++ ) {
        sceneObjects[i]->update();
    }
}
/*
void Scene::updateCameraProj( float fov, float ratio, float nearD, float farD ) {
    camera.updateProjection( fov, ratio, nearD, farD );
}
*/
/*
void Scene::updateCameraView() {
}
*/
/*
void Scene::render( const glm::mat4 &projection, const glm::mat4 &modelview )const {
    for( std::size_t i = 0; i < sceneObjects.size(); i++ ) {
        sceneObjects[i]->render( projection, modelview );
    }
}*/

void Scene::addObject( SceneObject* object ) {
    sceneObjects.push_back( object );
}

std::vector<SceneObject*> Scene::getSceneObjects()const {
    return sceneObjects;
}

Camera* Scene::getCamera(){
    return &camera;
}

const glm::vec3* Scene::getLight()const {
    return &light;
}


