#include "ScatteringShader.h"

#define PI  3.14159f

using namespace glm;
using namespace terra;
ScatteringShader::ScatteringShader( std::string vertexSource, std::string fragmentSource, float minRadius, float maxRadius, const Camera* camera, const vec3* light )
    : Shader( vertexSource, fragmentSource ) {
    this->light = light;
    this->camera = camera;

    samples = 2;     
    Kr = 0.0025f;
    Kr4PI = Kr * 8.0f * PI; //4.0f
    Km = 0.0015f;    
    Km4PI = Km * 8.0f * PI; //4.0f
    ESun = 15.0f;     
    g = -0.95f;       

    innerRadius = minRadius; //10.0f;
    outerRadius = maxRadius; //10.25f;
    scale = 1 / ( outerRadius - innerRadius );

    wavelength[0] = 0.650f;      // 650 nm for red
    wavelength[1] = 0.570f;      // 570 nm for green
    wavelength[2] = 0.475f;      // 475 nm for blue
    wavelength4[0] = glm::pow( wavelength[0], 4.0f );
    wavelength4[1] = glm::pow( wavelength[1], 4.0f );
    wavelength4[2] = glm::pow( wavelength[2], 4.0f );
    invWavelength4.x = 1.0f / wavelength4[0];
    invWavelength4.y = 1.0f / wavelength4[1];
    invWavelength4.z = 1.0f / wavelength4[2];
    rayleighScaleDepth = 0.25f;
    mieScaleDepth = 0.1f;
}

void ScatteringShader::sendScatteringUniforms()const {
    vec3 c = camera->getPosition();
    float lc = length( c );
    glUniform3fv( glGetUniformLocation( programID, "v3CameraPos" ), 1, value_ptr( c ) );
    glUniform3fv( glGetUniformLocation( programID, "v3LightPos" ), 1, value_ptr( normalize(*light ) ) );
    glUniform3fv( glGetUniformLocation( programID, "v3InvWavelength" ), 1, value_ptr( invWavelength4 ) );

    glUniform1f( glGetUniformLocation( programID, "fCameraHeight" ), lc );
    glUniform1f( glGetUniformLocation( programID, "fCameraHeight2" ), lc * lc );
    glUniform1f( glGetUniformLocation( programID, "fInnerRadius" ), innerRadius );
    glUniform1f( glGetUniformLocation( programID, "fInnerRadius2" ), innerRadius * innerRadius );
    glUniform1f( glGetUniformLocation( programID, "fOuterRadius" ), outerRadius );
    glUniform1f( glGetUniformLocation( programID, "fOuterRadius2" ), outerRadius * outerRadius );
    glUniform1f( glGetUniformLocation( programID, "fKrESun" ), Kr * ESun );
    glUniform1f( glGetUniformLocation( programID, "fKmESun" ), Km * ESun );
    glUniform1f( glGetUniformLocation( programID, "fKr4PI" ), Kr4PI );
    glUniform1f( glGetUniformLocation( programID, "fKm4PI" ), Km4PI );
    glUniform1f( glGetUniformLocation( programID, "fScale" ), 1.0f / ( outerRadius - innerRadius ) );
    glUniform1f( glGetUniformLocation( programID, "fScaleDepth" ), rayleighScaleDepth );
    glUniform1f( glGetUniformLocation( programID, "fScaleOverScaleDepth" ), ( 1.0f / ( outerRadius - innerRadius ) ) / rayleighScaleDepth );
    glUniform1f( glGetUniformLocation( programID, "g" ), g );
    glUniform1f( glGetUniformLocation( programID, "g2" ), g * g );
    glUniform1i( glGetUniformLocation( programID, "nSamples" ), samples );
    glUniform1f( glGetUniformLocation( programID, "fSamples" ), samples );
}
