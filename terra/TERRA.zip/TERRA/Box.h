/**@file Box.h
 */
#ifndef BOX_H
#define BOX_H

// Includes
#include "Shader.h"
#include "Renderable.h"

namespace terra {

    class AbstractBox : public Renderable {
    public:
        AbstractBox( const Shader* shader, const glm::vec4& color );

        virtual glm::vec3 getMin()const = 0;

        virtual glm::vec3 getMax()const = 0;

        void render( const glm::mat4 &projection, const glm::mat4 &modelview )const;

        void draw()const;

        glm::vec3 getCenter()const;

        glm::vec3 getSize()const;

        //void setMatrix( const glm::mat4& matrix );

    protected:
        const Shader* shader;

    private:
        AbstractBox();
    };

    class Box : public AbstractBox {
    public:
        Box( const glm::vec3& minP, const glm::vec3& maxP, const glm::vec4& color, const Shader* shader );

        Box( const glm::vec3& center, float size, const glm::vec4& color, const Shader* shader );

        virtual glm::vec3 getMin()const;

        virtual glm::vec3 getMax()const;

        void build();

    protected:
        virtual void init8Points( glm::vec3& a0, glm::vec3& a1, glm::vec3& a2, glm::vec3& a3, glm::vec3& b0, glm::vec3& b1, glm::vec3& b2, glm::vec3& b3 )const;

        glm::vec3 minP;

        glm::vec3 maxP;
    };
}
#endif // BOX_H
