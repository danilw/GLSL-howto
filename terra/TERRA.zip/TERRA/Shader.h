/**@file Shader.h
 */
#ifndef SHADER_H
#define SHADER_H

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

// Includes GLM

#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <string>

namespace terra {
    class Shader {
    public:
        Shader( std::string vertexSource, std::string fragmentSource );
        virtual ~Shader();
        GLuint getProgramID() const;

    protected:
        bool load();

        bool compileShader( GLuint &shader, GLenum type, std::string const &sourceFile );

        GLuint vertexID;
        GLuint fragmentID;
        GLuint programID;

        std::string vertexSource;
        std::string fragmentSource;
    private:
        Shader();
        bool init( std::string vertexSource, std::string fragmentSource );
    };

}
#endif // SHADER_H
