/**@file HeightMap.h
 */
#ifndef HEIGHTMAP_H
#define HEIGHTMAP_H

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

// Includes GLM
#include <glm/glm.hpp>

// Includes
#include "Shader.h"
#include "FrameBuffer.h"
#include "Config.h"
#include "cube_utils.h"

namespace terra {
    class Patch;
    class CGPatch;

    class RenderingMap {
    public:

        RenderingMap( const glm::vec3& center, float patchSize, int mapSize, GLuint textureID, const Shader* shader, bool blur );
        virtual ~RenderingMap();


        void renderToTexture()const;


        GLuint getColorBufferId() const;

        void build();

    protected:

        virtual void computeViewProMatrix() = 0;

        virtual void computePatchMatrix() = 0;
        //virtual void buildPatch() = 0;

        virtual void defineUniforms()const = 0;


        glm::vec3 center; 
        //int border;
        int mapSize;
        float patchSize; 
        const Shader *shader; 
        Patch* patch; 
        glm::mat4 patchMatrix; 
        glm::mat4 texMatrix; 
        glm::mat4 modelviewRTT;
        glm::mat4 projectionRTT;
        GLuint shaderID;
    private:
        GLuint textureID; 
        FrameBuffer* renderingFrameBuffer;
    };

    /*
    struct LODCubeMapInfos{
        CGPatch* patch;
        glm::vec3 center;
        int level;
        cubeFace face;
        float patchSize;
        int mapSize;
        int overlap;
        GLuint textureID;
        Shader *shader;
        bool blur;
    };
    */

    class LODCubeMap : public RenderingMap {
    public:

        LODCubeMap( const PlanetConfig* config, CGPatch* patch, const glm::vec3& center, int level, cubeFace face,
                    float patchSize, int mapSize, int overlap, GLuint textureID, const Shader* shader, bool blur );
        virtual ~LODCubeMap();
    protected:

        virtual void computeViewProMatrix();

        virtual void computePatchMatrix();
        //virtual void buildPatch();

        virtual void defineUniforms()const ;

        void computeOverlap();

    protected:

        int level; 
        cubeFace face;
        float overlap; 
        const PlanetConfig* config; 
    };


    class NormalMap : public LODCubeMap {
    public:

        NormalMap( const PlanetConfig* config, CGPatch* patch, const glm::vec3& center, int level, cubeFace face,
                   float patchSize, int mapSize, int overlap, GLuint textureID, const Shader* shader );
    protected:

        virtual void defineUniforms()const ;
    };
}
#endif //HEIGHTMAP_H
