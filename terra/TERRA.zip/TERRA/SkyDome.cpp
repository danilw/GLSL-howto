#include "SkyDome.h"

using namespace glm;
using namespace terra;

SkyDome::SkyDome( glm::vec3 position, float minRadius, float maxRadius, const Camera* camera, const glm::vec3* lightPos, const ScatteringShader* shader ) {
    this->position = position;
    this->camera = camera;
    this->lightPos = lightPos;
    this->minRadius = minRadius;
    this->maxRadius = maxRadius;
    this->shader = shader;
    skySphere = new Sphere( maxRadius );
}

SkyDome::~SkyDome() {
    delete skySphere;
}

void SkyDome::render( const mat4& projection, const mat4& modelview ) {
    glUseProgram( shader->getProgramID() );

    glUniformMatrix4fv( glGetUniformLocation( shader->getProgramID(), "projection" ), 1, GL_FALSE, value_ptr( projection ) );
    glUniformMatrix4fv( glGetUniformLocation( shader->getProgramID(), "modelview" ), 1, GL_FALSE, value_ptr( modelview ) );

    shader->sendScatteringUniforms();
    glDepthMask( GL_FALSE );
    glFrontFace( GL_CW );
    glEnable( GL_BLEND );
    glBlendFunc( GL_ONE, GL_ONE );
    //glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    skySphere->draw();
    glDisable( GL_BLEND );
    glFrontFace( GL_CCW );
    glDepthMask( GL_TRUE );
    glUseProgram( 0 );
}
