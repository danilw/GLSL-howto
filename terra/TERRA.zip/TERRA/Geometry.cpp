#include <iostream>
#include "Geometry.h"
#include "cube_utils.h"

using namespace terra;
using namespace glm;

Plane::Plane() {
    a = b = c = d = 0;
}

Plane::Plane( const float* arr ) {

    a = arr[0];
    b = arr[1];
    c = arr[2];
    d = arr[3];
}

Plane::Plane( float fa, float fb, float fc, float fd ) {
    a = fa;
    b = fb;
    c = fc;
    d = fd;
}

void Plane::set3Points( const vec3& v1,  const vec3& v2,  const vec3& v3 ) {

    vec3 A, B;

    A = v1 - v2;
    B = v3 - v2;

    normal = glm::cross( B, A );
    normal = glm::normalize( normal );

    point = v2;
    d = -glm::dot( normal, point ); //
}

void Plane::setCoefficients( float a, float b, float c, float d ) {

    normal = vec3( a, b, c );
    normal = glm::normalize( normal );
    float l = glm::length( normal );
    this->d = d / l;
}

float Plane::distance( const vec3 &p )const {
    return ( d + glm::dot( normal, p ) );
}

Base::Base() {}

Base::Base( const vec3& O, const vec3& x, const vec3& y, const vec3& z ) {
    origin = O;
    axisX = x;
    axisY = y;
    axisZ = z;
    transitionMatrix[0] = vec4( axisX.x, axisX.y, axisX.z, 0.0f );
    transitionMatrix[1] = vec4( axisY.x, axisY.y, axisY.z, 0.0f );
    transitionMatrix[2] = vec4( axisZ.x, axisZ.y, axisZ.z, 0.0f );
    transitionMatrix[3] = vec4( origin.x, origin.y, origin.z, 1.0f );

    inverseTransitionMatrix = glm::inverse( transitionMatrix );

    return;
}

vec3 Base::localToWorld( const vec3& p )const {
    return vec3( transitionMatrix * vec4( p, 1.0f ) );
}

vec3 Base::worldToLocal( const vec3& p )const {
    return vec3( inverseTransitionMatrix * vec4( p, 1.0f ) );
}


