/**@file Noise.h
 */
#ifndef NOISE_H
#define NOISE_H

// Includes GLM
#include <glm/glm.hpp>

#define MAX_OCTAVES 20

namespace terra {
    class Noise {
    public:
        static float fBm( glm::vec3 point, float H, float lacunarity, float octaves );

        static float multifractal( glm::vec3 point, float H, float lacunarity, float octaves, float offset );

        static float heteroTerrain( glm::vec3 point, float H, float lacunarity, float octaves, float offset );

        static float hybridMultifractal( glm::vec3 point, float H, float lacunarity, float octaves, float offset );

        static float ridgedMultifractal( glm::vec3 point, float H, float lacunarity, float octaves, float offset, float gain );

        //static float fBmTest( glm::vec3 point, float H, float lacunarity, float octaves, float offset, float gain );


        static float simplexNoise( glm::vec3 point );

        static glm::vec3 mod289( const glm::vec3 &x );
        static glm::vec4 mod289( const glm::vec4 &x );
        static glm::vec4 permute( const glm::vec4 &x );
        static glm::vec4 taylorInvSqrt( const glm::vec4 &r );
    };
}//namespace terra

#endif // NOISE_H
