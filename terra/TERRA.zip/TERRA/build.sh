#!/bin/sh

files="Box.cpp Camera.cpp ColorMap.cpp Config.cpp cube_utils.cpp Fractals.cpp FrameBuffer.cpp Frustrum.cpp Geometry.cpp HeightMap.cpp Input.cpp main.cpp Noise.cpp OBB.cpp OpenGLApp.cpp Patch.cpp PixelBuffer.cpp Planet.cpp Quad.cpp QuadTreeNode.cpp Renderable.cpp Renderer.cpp ScatteringShader.cpp Scene.cpp SceneObject.cpp Shader.cpp SkyDome.cpp Sphere.cpp TerrainTile.cpp Texture.cpp utils.cpp"

em++ -Iinclude/ $files -O3 -lGL -lGLU -lSDL2 -lm -s FULL_ES3=1 -s USE_SDL=2 -s USE_WEBGL2=1 -s WASM=1 -o build/terra.html --shell-file shell_minimal.html --preload-file ./Shaders

