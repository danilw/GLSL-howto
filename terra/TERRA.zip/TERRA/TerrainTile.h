/**@file TerrainTile.h
 */
#ifndef TERRAINTILE_H
#define TERRAINTILE_H

#include "HeightMap.h"
#include "ScatteringShader.h"
#include "ColorMap.h"
#include "Config.h"
#include "Patch.h"
#include "utils.h"

namespace terra{

    struct TerrainShaders {
        ScatteringShader* shader; 
        Shader* heightMapShader; 
        Shader* normalMapShader;
        Shader* displacementMapShader;
    };

    struct TileInfos {
        terra::Base worldBase;
        cubeFace face; 
        float width;
        int level; 
        PatchFactory* patchFactory;
        TerrainShaders tileShaders; 
        ColorMap* colorMap; 
        Shader* boxShader;

    };

    class TerrainTile {
    public:

        TerrainTile( const TileInfos* tileInfos, const PlanetConfig* config );
        ~TerrainTile();

        void build();

        void render( const glm::mat4& projection, const glm::mat4& modelview, RenderMode renderMode )const;
    private:
        void computeMatrix();
        void computeOverlap( int level );

        glm::vec3 center;
        cubeFace face;
        int level;
        float width;
        float overlap;
        const PatchFactory* patchFactory;
        ScatteringShader* shader;
        Shader* hMapShader;
        Shader* nMapShader;
        Shader* dMapShader;
        SphericPatch* sphericPatch; 
        glm::mat4 transformMatrix;
        glm::mat4 hmapMatrix;
        glm::mat4 nmapMatrix;
        glm::mat4 dmapMatrix;
        LODCubeMap* heightMap;
        LODCubeMap* normalMap; 
        LODCubeMap* displacementMap; 
        ColorMap* colorMap;
        glm::vec4 color;
        GLuint shaderID;
        const PlanetConfig* config;
    };
}

#endif // TERRAINTILE_H
