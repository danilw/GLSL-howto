#include "PixelBuffer.h"

using namespace terra;

template <typename T>
PixelBuffer<T>::PixelBuffer( int nWidth, int nHeight, GLuint nDataType, int nChannels, GLuint nFormat, GLuint nInternalFormat ) {
    buffer = NULL;
    format = nFormat;
    internalFormat = nInternalFormat;
    init( nWidth, nHeight, nDataType, nChannels );
}

template <typename T>
PixelBuffer<T>::~PixelBuffer() {
    cleanup();
}

template <typename T>
T& PixelBuffer<T>::operator[]( int n ) {
    return buffer[n];
}

template <typename T>
T& PixelBuffer<T>::operator()( int x, int y, int k ) {
    return buffer[ channels * ( width * y  + x ) + k];
}

template <typename T>
void PixelBuffer<T>::init( int nWidth, int nHeight, int nDataType, int nChannels ) {
    cleanup();
    width = nWidth;
    height = nHeight;
    dataType = nDataType;
    channels = nChannels;
    elementSize =  sizeof( T );

    buffer = new T[width * height  * channels];
}

template <typename T>
void PixelBuffer<T>::cleanup() {
    if( buffer != NULL )
        delete  buffer;
}

template <typename T>
int PixelBuffer<T>::getWidth() const {
    return width;
}

template <typename T>
int PixelBuffer<T>::getHeight() const {
    return height;
}

template <typename T>
GLuint PixelBuffer<T>::getDataType() const {
    return dataType;
}

template <typename T>
int PixelBuffer<T>::getChannels() const {
    return channels;
}

template <typename T>
size_t PixelBuffer<T>::getBufferSize() const {
    return width * height * channels * sizeof( T );
}

template <typename T>
T* PixelBuffer<T>::getBuffer() const {
    return buffer;
}

template <typename T>
GLuint PixelBuffer<T>::getFormat() const {
    return format;
}

template <typename T>
GLuint PixelBuffer<T>::getInternalFormat() const {
    return internalFormat;
}


template <typename T>
void PixelBuffer<T>::clearBuffer() {
    memset( buffer, 0, getBufferSize() );
}

// instantiations explicites
template class terra::PixelBuffer<GLubyte>;
template class terra::PixelBuffer<GLfloat>;
