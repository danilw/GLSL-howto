/**@file Config.h
 */
#ifndef CONFIG_H
#define CONFIG_H

// Includes GLM
#include <glm/glm.hpp>

#include <string>

namespace terra {

    struct PlanetConfig {
        int patchDef; 
        int dmapSize; 
        int hmapSize; 
        int nmapSize; 
        int maxLod; 
        float precisionFactor; 
        float radius; 
        float maxHeight; 
        float atmInnerRadius; 
        float atmOuterRadius; 
        float sunDomeRadius; 
        float fractalScale; 
        glm::vec3 position; 
    };

    struct SceneConfig {
        glm::vec3 cameraPos; 
        glm::vec3 lightPos; 
    };


    struct RenderConfig {
        float hdrExposure; 
        int windowWidth; 
        int windowHeight; 
        float cameraFOV; 
    };


    class Config {
    public:
        Config();

        bool loadConfigFile( std::string fileName );

        RenderConfig renderConfig; 
        SceneConfig sceneConfig; 
        PlanetConfig planetConfig; 
    };

}
#endif // CONFIG_H
