/**@file Input.h
 */
#ifndef INPUT_H
#define INPUT_H

#include <SDL2/SDL.h>

namespace terra {

    class Input {
    public:
        Input();
        ~Input();


        void updateEvents();

        bool end() const;

        void displayCursor( bool b ) const;
        void grapCursor( bool b ) const;
        bool getKeyReleased( const SDL_Scancode key );
        bool getKeyPressed( const SDL_Scancode key );
        bool getKey( const SDL_Scancode key ) const;
        bool getMouseButton( const Uint8 button ) const;
        bool mouseMove() const;
        int getX() const;
        int getY() const;
        int getXRel() const;
        int getYRel() const;


    private:

        SDL_Event events;
        bool keysPressed[SDL_NUM_SCANCODES];
        bool keysReleased[SDL_NUM_SCANCODES];
        bool keys[SDL_NUM_SCANCODES];
        bool mouseButtons[8]; 


        int mouseX; 
        int mouseY; 
        int mouseXRel; 
        int mouseYRel; 
        int mouseLastX, mouseLastY;
        bool endFlag; 
    };

}
#endif // INPUT_H

