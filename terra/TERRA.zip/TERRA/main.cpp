#include "OpenGLApp.h"
#include "Config.h"
#include <emscripten.h>

//ORIGINAL SOURCE https://sourceforge.net/projects/terraumlv/

terra::OpenGLApp *app;

void mainloop() {
    app->start();
}

void hidecanvas() {

    emscripten_run_script("document.getElementById('spinner').hidden = false;document.getElementById('imloader').style.display=\"\"");
}

void displaycanvas() {

    emscripten_run_script("resize_glfw_wasm()");
    emscripten_run_script("document.getElementById('spinner').hidden = true;document.getElementById('imloader').style.display=\"none\"");
}

int main( int argc, char **argv ) {
    terra::Config config;
    if( config.loadConfigFile( "" ) == false ){
        return -1;
    }
    
    app=new terra::OpenGLApp( &config, "Terra", config.renderConfig.windowWidth, config.renderConfig.windowHeight );

    if( app->init() == false ) {
        return -1;
    }
    
    std::cout << std::endl << std::endl << "Controls :" << std::endl;
    std::cout << "H hide console, R toggle Camera-Ground collision, P stop mouse rotation"<< std::endl;
    std::cout << "1 render mode, 2 toggleHDR, 3 toggleCulling, 4 toggleFrustrumUpdate, W/A/S/D movement" << std::endl << std::endl;

    displaycanvas();
    emscripten_set_main_loop(mainloop, 0, 1);

    return 0;
}
