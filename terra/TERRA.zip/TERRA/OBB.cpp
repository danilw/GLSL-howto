#include <glm/gtx/transform.hpp>
#include "OBB.h"
#include "Noise.h"

using namespace terra;
using namespace glm;

OBB::OBB( const Base& base, const vec3& minP, const vec3& maxP, const vec3* patchCorners, const Shader* pShader )
    : Box( minP, maxP, vec4( 0.0f, 1.0f, 0.0f, 1.0f ), pShader ) {

    this->base  = base;
    this->patchCorners = patchCorners;
    x = glm::abs( maxP.x - minP.x );
    y = glm::abs( maxP.y - minP.y );
    z = glm::abs( maxP.z - minP.z );
    PP = computeProxyPoint();
}

OBB::~OBB()
{}

//source http://cesiumjs.org/2013/05/09/Computing-the-horizon-occlusion-point/
vec3 OBB::computeProxyPoint() {
    vec3 OV[4];
    vec3 OP[4];
    vec3 C = base.localToWorld( ( maxP + minP ) / 2.0f );
    vec3 directionP = normalize( C );

    for( int i = 0; i < 4; i++ ) {
        OV[i] = base.worldToLocal( patchCorners[i] );
        OV[i].y = maxP.y;
        OV[i] = base.localToWorld( OV[i] );
        float lengthV = max( 1.0f, length( OV[i] ) );
        float lengthSquaredV = lengthV * lengthV;
        vec3 directionV = normalize( OV[i] );

        float cosAlpha = dot( directionV, directionP );
        float sinAlpha = length( cross( directionV, directionP ) );
        float cosBeta = 1.0f / lengthV;
        float sinBeta = sqrt( lengthSquaredV - 1.0f ) * cosBeta;

        OP[i] = directionP / ( cosAlpha * cosBeta - sinAlpha * sinBeta );
    }
    vec3 P;
    P = OP[0];
    for( int i = 1; i < 4; i++ )
        P = max( P, OP[i] );
    return P;
}

//http://cesium.agi.com/2013/04/25/Horizon-culling/
bool OBB::isBehindHorizon( vec3 cameraPos ) {
    vec3 proxyPoint = PP;
    vec3 viewPosToSphereCenter = cameraPos; //cameraPos - spherecenter
    vec3 viewPosToBoxProxyPoint = cameraPos - proxyPoint;
    float distanceToBoxCenterSq = glm::length( viewPosToBoxProxyPoint ) * glm::length( viewPosToBoxProxyPoint );
    float distanceToSphereCenterSq = glm::length( viewPosToSphereCenter ) * glm::length( viewPosToSphereCenter );

    float dot = glm::dot( viewPosToBoxProxyPoint, viewPosToSphereCenter );
    float result1 = dot - distanceToSphereCenterSq + 1; 
    dot = glm::dot( viewPosToBoxProxyPoint, viewPosToSphereCenter );
    float result2 = ( dot * dot ) / distanceToBoxCenterSq - distanceToSphereCenterSq + 1;
    return ( result1 > 0 && result2 > 0 );
}

vec3 OBB::getProxyPoint()const {
    return PP;
}

void OBB::setColor( const vec4& color ) {
    this->color = color;
}

Base OBB::getBase()const {
    return base;
}

vec3 OBB::getMinLocal()const {
    return minP;
}

vec3 OBB::getMaxLocal()const {
    return maxP;
}

vec3 OBB::getMin()const {
    return base.localToWorld( minP );
}

vec3 OBB::getMax()const {
    return base.localToWorld( maxP );
}

void OBB::init8Points( vec3& a0, vec3& a1, vec3& a2, vec3& a3, vec3& b0, vec3& b1, vec3& b2, vec3& b3 )const {
    vec3 mi = getMinLocal();
    vec3 ma = getMaxLocal();

    a0 = vec3( mi.x, mi.y, mi.z );
    a1 = vec3( ma.x, mi.y, mi.z );
    a2 = vec3( ma.x, ma.y, mi.z );
    a3 = vec3( mi.x, ma.y, mi.z );
    b0 = vec3( mi.x, mi.y, ma.z );
    b1 = vec3( ma.x, mi.y, ma.z );
    b2 = vec3( ma.x, ma.y, ma.z );
    b3 = vec3( mi.x, ma.y, ma.z );

    a0 = base.localToWorld( a0 );
    a1 = base.localToWorld( a1 );
    a2 = base.localToWorld( a2 );
    a3 = base.localToWorld( a3 );
    b0 = base.localToWorld( b0 );
    b1 = base.localToWorld( b1 );
    b2 = base.localToWorld( b2 );
    b3 = base.localToWorld( b3 );

}

float OBB::minDistanceFromPoint( const vec3& p )const {
    return glm::sqrt( minDistanceFromPointSq( p ) );
}

float OBB::minDistanceFromPointSq( const vec3& p )const {
    float dist = 0.0f;

    vec3 point = base.worldToLocal( p );
    vec3 minPoint = getMinLocal();
    vec3 maxPoint = getMaxLocal();

    if( point.x < minPoint.x ) {
        float d = point.x - minPoint.x;
        dist += d * d;
    } else if( point.x > maxPoint.x ) {
        float d = point.x - maxPoint.x;
        dist += d * d;
    }

    if( point.y < minPoint.y ) {
        float d = point.y - minPoint.y;
        dist += d * d;
    } else if( point.y > maxPoint.y ) {
        float d = point.y - maxPoint.y;
        dist += d * d;
    }

    if( point.z < minPoint.z ) {
        float d = point.z - minPoint.z;
        dist += d * d;
    } else if( point.z > maxPoint.z ) {
        float d = point.z - maxPoint.z;
        dist += d * d;
    }

    return dist;
}

vec3 OBB::getVertexP( const vec3& normal )const {
    vec3 n;
    n.x = glm::dot( normal, base.axisX );
    n.y = glm::dot( normal, base.axisY );
    n.z = glm::dot( normal, base.axisZ );

    vec3 res = minP;
    if( n.x > 0.0f )
        res.x = maxP.x;
    if( n.y > 0.0f )
        res.y = maxP.y;
    if( n.z > 0.0f )
        res.z = maxP.z;

    res = base.localToWorld( res );
    return( res );
}

vec3 OBB::getVertexN( const vec3& normal )const {
    vec3 n;
    n.x = glm::dot( normal, base.axisX );
    n.y = glm::dot( normal, base.axisY );
    n.z = glm::dot( normal, base.axisZ );

    vec3 res = maxP;
    if( n.x > 0.0f )
        res.x = minP.x;
    if( n.y > 0.0f )
        res.y = minP.y;
    if( n.z > 0.0f )
        res.z = minP.z;

    res = base.localToWorld( res );
    return( res );
}

///http://www.lighthouse3d.com/tutorials/view-frustum-culling/geometric-approach-testing-boxes-ii/
OBB::IntersectType OBB::testInBoundingPlanes( const Plane planes[] )const {
    IntersectType result = IT_Inside;

    //float size = glm::length(getSize());
    //size/=4.0;
    for( int i = 0; i < 6; i++ ) {
        if( planes[i].distance( getVertexP( planes[i].normal ) ) < 0.0f )
            return IT_Outside;
        else if( planes[i].distance( getVertexN( planes[i].normal ) ) < 0.0f )
            result = IT_Intersect;
    }
    return( result );
}



OBB* OBB::createOBB(const vec3& O, cubeFace face, float width, float maxHeight, float fractalScale, float radius, Shader* shader ) {
    int resolution = 5;//minimum resolution=2;

    static float minH = 20.0f;
    static float maxH = -20.0f;

    //cubeFace face = tileInfos->face;

    mat4 matrixOrigin = getCubeFaceMatrix( face );
    mat4 matrix = glm::translate( matrixOrigin, O );
    //float width = tileInfos->width;
    float cellSize = width / resolution;
    float currX, currY, currZ;
    vec3 pos, P;
    vec3 maxOBB, minOBB;
    vec3 patchVert[4];

    patchVert[0] = cubeToSphereMapping( vec3( matrix * vec4( -width / 2.0, 0.0, -width / 2.0, 1.0 ) ) );
    patchVert[1] = cubeToSphereMapping( vec3( matrix * vec4( width / 2.0, 0.0, -width / 2.0, 1.0 ) ) );
    patchVert[2] = cubeToSphereMapping( vec3( matrix * vec4( -width / 2.0, 0.0,  width / 2.0, 1.0 ) ) );
    patchVert[3] = cubeToSphereMapping( vec3( matrix * vec4( width / 2.0, 0.0,  width / 2.0, 1.0 ) ) );

    vec3 origin;
    vec3 newAxisX, newAxisZ, newNormal;
    mat4 transitionMatrix, inverseTransitionMatrix;
    Base base;
    origin = O;
    origin = vec3( matrixOrigin * vec4( origin, 1.0 ) );
    origin = cubeToSphereMapping( origin );
    origin = normalize( origin ) * radius;

    newAxisX = normalize( patchVert[1] - patchVert[0] );

    newNormal = normalize( origin );
    newAxisZ = cross( newAxisX, newNormal );

    //newAxisZ = normalize(patchVert[3] - patchVert[1]);
    //newNormal = cross(newAxisX, newAxisZ);

    base = Base( origin, newAxisX, newNormal, newAxisZ );
    inverseTransitionMatrix = base.inverseTransitionMatrix;
    transitionMatrix = base.transitionMatrix;
    vec3 vert[4];
    currY = 0.0;
    currZ = -width / 2.0;
    for( int j = 0; j < resolution; j++, currZ += cellSize ) {
        currX = - width / 2.0f;
        for( int i = 0; i <= resolution; i++ , currX += cellSize ) {
            for( int k = 0; k < 2; k++ ) {
                if( k == 0 )
                    pos = vec3( currX, currY, currZ );
                else
                    pos = vec3( currX, currY, currZ + cellSize );

                pos = vec3( matrix * vec4( pos, 1.0f ) );
                float h = getHeight( pos, maxHeight, fractalScale );
                pos = cubeToSphereMapping( vec3( pos ) );
                pos = normalize( pos ) * radius;

                maxH = glm::max( h, maxH );
                minH = glm::min( h, minH );

                //h = 0.0f;

                pos = normalize( pos ) * h + pos;
                P = vec3( inverseTransitionMatrix * vec4( pos, 1.0 ) );

                if( i == 0 && j == 0 && k == 0 ) {
                    maxOBB = minOBB = P;
                }
                maxOBB = glm::max( P, maxOBB );
                minOBB = glm::min( P, minOBB );

                if( i == 0 && j == 0 && k == 0 )
                    vert[0] = pos;
                if( i == resolution && j == 0 && k == 0 )
                    vert[1] = pos;
                if( i == 0 && j == resolution - 1 && k == 1 )
                    vert[2] = pos;
                if( i == resolution && j == resolution - 1 && k == 1 )
                    vert[3] = pos;

            }
        }
    }
    //std::cout<<"minH = "<<minH<<" , maxH = "<<maxH<<std::endl;


    //obBox = new OBB( base, minOBB,  maxOBB, vert, shader );
    //obBox->build();
    return new OBB( base, minOBB,  maxOBB, vert, shader );
}

static const float octave = 8.0f;
static const float offset = 1.0f;
static const float gain = 1.6f;
static const float fH = 0.87f;
static const float lacunarity = 2.5f;
static const float minAlt = 0.008f;
static const float maxAlt = 1.75f;
//static const float noiseScale = 1.0f; // 0.8/RADIUS
//static const float maxHeight = RADIUS * 0.08f;//RADIUS * 0.04; // 0.00133333 = 1/750
static float minH = 20.0f;
static float maxH = -20.0f;

float OBB::getHeight( vec3 pos, float maxHeight, float fractalScale ) {
    float h = Noise::ridgedMultifractal( pos * fractalScale, fH, lacunarity, octave, offset, gain );

    maxH = glm::max( h, maxH );
    minH = glm::min( h, minH );

    h = ( h  + minAlt ) / ( minAlt + maxAlt );
    h = glm::pow( h, 3.0f );
    h = glm::clamp( h, 0.1f, 1.0f );
    h -= 0.1f;

    h *= maxHeight;
    //std::cout<<"minH = "<<minH<<" , maxH = "<<maxH<<std::endl;
    return h;
}
