#include "FrameBuffer.h"

using namespace terra;

FrameBuffer::FrameBuffer() : id( 0 ), width( 0 ), height( 0 ), colorBuffer(), depthBufferID( 0 ), useStencilBuffer( false ) {

}

FrameBuffer::FrameBuffer( int width, int height, bool blur, bool useStencilBuffer ) : id( 0 ), width( width ), height( height ),
    colorBuffer( 0 ), depthBufferID( 0 ),
    useStencilBuffer( useStencilBuffer ), blur( blur ) {

}

FrameBuffer::FrameBuffer( const FrameBuffer &toCopyFrameBuffer ) {
    width = toCopyFrameBuffer.width;
    height = toCopyFrameBuffer.height;
    useStencilBuffer = toCopyFrameBuffer.useStencilBuffer;

    load();
}

FrameBuffer::~FrameBuffer() {

    glDeleteFramebuffers( 1, &id );
    glDeleteRenderbuffers( 1, &depthBufferID );
    if( colorBuffer != 0 )
        delete colorBuffer;
}

bool FrameBuffer::load() {

    if( glIsFramebuffer( id ) == GL_TRUE ) {

        glDeleteFramebuffers( 1, &id );
    }


    glGenFramebuffers( 1, &id );

    glBindFramebuffer( GL_FRAMEBUFFER, id );


    colorBuffer = new Texture( width, height, GL_RGBA, GL_RGBA32F, true, blur );
    //colorBuffer = new Texture(width, height, GL_RGBA, GL_RGBA16F, true, blur);
    //colorBuffer = new Texture(width, height, GL_RGBA, GL_RGBA, true, blur);
    colorBuffer->loadEmptyTexture();


    if( useStencilBuffer == true )
        createRenderBuffer( depthBufferID, GL_DEPTH24_STENCIL8 );

    else
        createRenderBuffer( depthBufferID, GL_DEPTH_COMPONENT24 );


    glFramebufferTexture2D( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, colorBuffer->getID(), 0 );


    if( useStencilBuffer == true )
        glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_DEPTH_STENCIL_ATTACHMENT, GL_RENDERBUFFER, depthBufferID );
    else
        glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depthBufferID );


    if( glCheckFramebufferStatus( GL_FRAMEBUFFER ) != GL_FRAMEBUFFER_COMPLETE ) {

        glDeleteFramebuffers( 1, &id );
        glDeleteRenderbuffers( 1, &depthBufferID );


        std::cerr << "Error: an error occured while creating the framebuffer" << std::endl;

        return false;
    }

    glBindFramebuffer( GL_FRAMEBUFFER, 0 );

    return true;
}

void FrameBuffer::createRenderBuffer( GLuint &id, GLenum internalFormat ) {
    if( glIsRenderbuffer( id ) == GL_TRUE )
        glDeleteRenderbuffers( 1, &id );

    glGenRenderbuffers( 1, &id );

    glBindRenderbuffer( GL_RENDERBUFFER, id );

    glRenderbufferStorage( GL_RENDERBUFFER, internalFormat, width, height );

    glBindRenderbuffer( GL_RENDERBUFFER, 0 );
}


GLuint FrameBuffer::getID() const {
    return id;
}

GLuint FrameBuffer::getColorBufferID( unsigned int index ) const {
    return colorBuffer->getID();
}

int FrameBuffer::getWidth() const {
    return width;
}

int FrameBuffer::getHeight() const {
    return height;
}
