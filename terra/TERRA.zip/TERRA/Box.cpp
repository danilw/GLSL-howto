#include "Box.h"

using namespace terra;
using namespace glm;

AbstractBox::AbstractBox() : Renderable() {
    shader = NULL;
    color = vec4( 1.0 );
}

AbstractBox::AbstractBox( const Shader* shader, const vec4& color ) : Renderable() {
    this->shader = shader;
    this->color = color;
}
/*
void AbstractBox::setMatrix( const glm::mat4& matrix ) {
    this->matrix = matrix;
}*/

vec3 AbstractBox::getCenter()const {
    return ( getMin() + getMax() ) * 0.5f;
}

vec3 AbstractBox::getSize()const {
    return getMax() - getMin();
}

void AbstractBox::draw()const {
    glBindVertexArray( vaoID );

    glDrawArrays( GL_TRIANGLES, 0, 36 );

    glBindVertexArray( 0 );
}

void AbstractBox::render( const mat4 &projection, const mat4 &modelview )const {
    glUseProgram( shader->getProgramID() );

    glBindVertexArray( vaoID );

    glUniformMatrix4fv( glGetUniformLocation( shader->getProgramID(), "projection" ), 1, GL_FALSE, value_ptr( projection ) );
    glUniformMatrix4fv( glGetUniformLocation( shader->getProgramID(), "modelview" ), 1, GL_FALSE, value_ptr( modelview ) );
    glUniform4fv( glGetUniformLocation( shader->getProgramID(), "uniform_color" ), 1, value_ptr( color ) );

    glDrawArrays( GL_LINE_STRIP, 0, 36 );

    glBindVertexArray( 0 );

    glUseProgram( 0 );
}

Box::Box( const vec3& minP, const vec3& maxP, const vec4& color, const Shader* shader )
    : AbstractBox( shader , color ) {
    this->minP = minP;
    this->maxP = maxP;
}

Box::Box( const vec3& center, float size, const vec4& color, const Shader* shader )
    : AbstractBox( shader , color ) {
    minP = center - size / 2.0f;
    maxP = center + size / 2.0f;
}

vec3 Box::getMin()const {
    return minP;
}

vec3 Box::getMax()const {
    return maxP;
}

void Box::init8Points( vec3& a0, vec3& a1, vec3& a2, vec3& a3, vec3& b0, vec3& b1, vec3& b2, vec3& b3 )const {
    vec3 mi = getMin();
    vec3 ma = getMax();

    a0 = vec3( mi.x, mi.y, mi.z );
    a1 = vec3( ma.x, mi.y, mi.z );
    a2 = vec3( ma.x, ma.y, mi.z );
    a3 = vec3( mi.x, ma.y, mi.z );
    b0 = vec3( mi.x, mi.y, ma.z );
    b1 = vec3( ma.x, mi.y, ma.z );
    b2 = vec3( ma.x, ma.y, ma.z );
    b3 = vec3( mi.x, ma.y, ma.z );
}

void Box::build() {
    vec3 a0, a1, a2, a3, b0, b1, b2, b3;

    init8Points( a0, a1, a2, a3, b0, b1, b2, b3 );
    vec3 vert[36];
    int index = 0;

    vert[index++] = vec3( a0 );
    vert[index++] = vec3( a3 );
    vert[index++] = vec3( a2 );
    vert[index++] = vec3( a2 );
    vert[index++] = vec3( a1 );
    vert[index++] = vec3( a0 );

    vert[index++] = vec3( b0 );
    vert[index++] = vec3( b1 );
    vert[index++] = vec3( b2 );
    vert[index++] = vec3( b2 );
    vert[index++] = vec3( b3 );
    vert[index++] = vec3( b0 );

    vert[index++] = vec3( a0 );
    vert[index++] = vec3( a1 );
    vert[index++] = vec3( b1 );
    vert[index++] = vec3( b1 );
    vert[index++] = vec3( b0 );
    vert[index++] = vec3( a0 );

    vert[index++] = vec3( a1 );
    vert[index++] = vec3( a2 );
    vert[index++] = vec3( b2 );
    vert[index++] = vec3( b2 );
    vert[index++] = vec3( b1 );
    vert[index++] = vec3( a1 );

    vert[index++] = vec3( a2 );
    vert[index++] = vec3( a3 );
    vert[index++] = vec3( b3 );
    vert[index++] = vec3( b3 );
    vert[index++] = vec3( b2 );
    vert[index++] = vec3( a2 );

    vert[index++] = vec3( a3 );
    vert[index++] = vec3( a0 );
    vert[index++] = vec3( b0 );
    vert[index++] = vec3( b0 );
    vert[index++] = vec3( b3 );
    vert[index++] = vec3( a3 );

    verticesCount = 108;
    vertices = new float[108];
    index = 0;
    for( int i = 0; i < 36; i++ ) {
        vertices[index++] = vert[i].x;
        vertices[index++] = vert[i].y;
        vertices[index++] = vert[i].z;
    }
    load();
}
