/**@file Renderable.h
 */
#ifndef RENDERABLE_H
#define RENDERABLE_H

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

// Includes GLM
#include <glm/glm.hpp>

namespace terra {

    class Renderable {
    public:
        Renderable();
        virtual ~Renderable();

        virtual void load();

        virtual void draw()const = 0;
    protected:

        GLuint vboID;

        GLuint vaoID;

        float *vertices;

        float *normals;

        float *texCoord2D;

        int verticesCount;

        int texCoordCount;

        int normalCount;

        glm::vec4 color;
    private:
        int getVerticesSizeInBytes()const;
        int getTexCoordSizeInBytes()const;
        int getNormalSizeInBytes()const;
    };
}
#endif // RENDERABLE_H
