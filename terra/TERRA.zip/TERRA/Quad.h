/**@file Quad.h
 */
#ifndef QUAD_H
#define QUAD_H

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

// Includes GLM
#include <glm/glm.hpp>

#include "Renderable.h"
#include "Shader.h"

namespace terra {

    class Quad : public terra::Renderable {
    public:

        Quad( glm::vec2 topLeftCorner, glm::vec2 bottomRightCorner );


        void draw()const;
    private:

        void addVertex( glm::vec3 vert, glm::vec2 uv, int& count, int& countUV );
        void build();
        glm::vec2 topLeftCorner;
        glm::vec2 bottomRightCorner;
    };


    class RenderingQuad {
    public:
        RenderingQuad( float exposure, GLuint textureId, const Shader* shader );
        ~RenderingQuad();

        void render();

    private:
        // membres
        GLuint textureId;
        GLuint shaderID;
        float exposure;
        const Shader* shader;
        Quad* quad;
    };

}
#endif // QUAD_H
