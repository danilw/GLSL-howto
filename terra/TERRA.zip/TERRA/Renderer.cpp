#include "Renderer.h"
#include <iostream>

using namespace terra;
using namespace glm;

Renderer::Renderer( const RenderConfig& config, Scene* scene ) {

    this->scene = scene;
    frameBufferHeight = config.windowHeight;
    frameBufferWidth = config.windowWidth;
    hdrExposure = config.hdrExposure;
    fov = config.cameraFOV;

    frustrumUpdate = true;
    culling = true;
    hdr = true;
    renderMode = POLYGON;
    hdrShader = NULL;
    frameBuffer = NULL;
    hdrQuad = NULL;
}

Renderer::~Renderer() {
    delete hdrShader;
    delete frameBuffer;
    delete hdrQuad;
}

void Renderer::init() {
    hdrShader = new Shader( "Shaders/HDR.vert", "Shaders/HDR.frag" );

    frameBuffer = new FrameBuffer( frameBufferWidth, frameBufferHeight, true );
    if( ! frameBuffer->load() )
        std::cerr << "FrameBuffer HDR failed to load" << std::endl;
    frameBufferID = frameBuffer->getID();

    hdrQuad = new RenderingQuad( hdrExposure, frameBuffer->getColorBufferID( 0 ), hdrShader );

    camera = scene->getCamera();
    viewRatio = ( float )frameBufferWidth / ( float )frameBufferHeight;
    camera->updateProjection( fov, viewRatio, 0.00001f, 20.0f );

    modelview = camera->getViewMatrix();
    projection = camera->getProjMatrix();

    glEnable( GL_DEPTH_TEST );

    glEnable( GL_CULL_FACE );

    std::cout << "Renderer init OK.\n";
}

void Renderer::update() {
    camera->setFrustrumUpdate( frustrumUpdate );
    modelview = camera->getViewMatrix();
    projection = camera->getProjMatrix();

    if( frustrumUpdate ) {
        scene->updateScene();
    }
    getGLError( true );

    render();
}

void Renderer::render() {
    if( hdr )
        glBindFramebuffer( GL_FRAMEBUFFER, frameBufferID );
/*
    if( renderMode == terra::POLYGON )
        glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
    else
        glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
*/
    if( culling )
        glEnable( GL_CULL_FACE );
    else
        glDisable( GL_CULL_FACE );

    glViewport( 0, 0, frameBufferWidth, frameBufferHeight );

    glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    std::vector<SceneObject*> sceneObjects = scene->getSceneObjects();
    for( std::size_t i = 0; i < sceneObjects.size(); i++ ) {
        sceneObjects[i]->render( projection, modelview, renderMode );
    }
    //scene->render( projection, modelview );

    getGLError( true );

    if( hdr ) {
        glBindFramebuffer( GL_FRAMEBUFFER, 0 );
        glClearColor( 0.0, 0.0, 0.0, 0.0 );
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
        //glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
        hdrQuad->render();
    }
}

void Renderer::toggleCulling() {
    culling = !culling;
    if( culling )
        std::cout << "culling : ON" << std::endl;
    else
        std::cout << "culling : OFF" << std::endl;
}

void Renderer::toggleHDR() {
    hdr = !hdr;
    if( hdr )
        std::cout << "HDR : ON" << std::endl;
    else
        std::cout << "HDR : OFF" << std::endl;
}

void Renderer::toggleFrustrumUpdate() {
    frustrumUpdate = !frustrumUpdate;
    if( frustrumUpdate )
        std::cout << "frustrum update : ON" << std::endl;
    else
        std::cout << "frustrum update : OFF" << std::endl;
}

void Renderer::nextRenderMode() {
    renderMode = ( RenderMode )( ( renderMode + 1 ) % 3 );
}

