/**@file cube_utils.h
 * Fonctions utilitaires pour g�rer les faces d'un cubes.
 */

#ifndef CUBE_UTILS_H
#define CUBE_UTILS_H

// Includes GLM
#include <glm/glm.hpp>

/** @namespace terra
*/
namespace terra {

    enum cubeFace {
        CUBE_TOP, CUBE_BOTTOM, CUBE_LEFT, CUBE_RIGHT, CUBE_FRONT, CUBE_BACK
    };

    glm::mat4 getRTTViewMatrix( cubeFace face );

    glm::mat4 getCubeFaceMatrix( cubeFace face );

    glm::vec3 cubeToSphereMapping( const glm::vec3 &v );

}
#endif // CUBE_UTILS_H
