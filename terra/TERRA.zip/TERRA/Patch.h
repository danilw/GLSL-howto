/**@file Patch.h
 */
#ifndef PATCH_H
#define PATCH_H

// Includes GLM
#include <glm/glm.hpp>

#include "Renderable.h"
#include "utils.h"

namespace terra {

    class Patch : public terra::Renderable {
    public:

        Patch( int resolution, float width, const glm::mat4& matrix );
        void build();
        void buildNormal();
        void draw()const;
        void draw(RenderMode renderMode)const;
        glm::mat4 getTexMatrix()const;
        void setTexMatrix( const glm::mat4 &m );
        glm::mat4 getMatrix()const;
        void setMatrix( const glm::mat4 &m );
    protected:
        virtual void transform( glm::vec3 &v )const ;

        glm::mat4 matrix; 
        glm::mat4 texMatrix; 
        int resolution;
        float width; 
    };
    class CGPatch : public Patch {
    public:
        CGPatch( int resolution, float width );

    protected:
        virtual void transform( glm::vec3 &v )const;
    };

    class SphericPatch : public Patch {
    public:
        SphericPatch( int resolution, float width, const glm::mat4& matrix, float radius );
        void buildNormal();

    protected:
        virtual void transform( glm::vec3 &v )const ;

    private:
        float radius;
    };
    class CGSphericPatch : public SphericPatch {
    public:
        CGSphericPatch( int resolution, float width );

    protected:
        virtual void transform( glm::vec3 &v )const ;
    };

    class PatchFactory {
    public:
        PatchFactory();
        ~PatchFactory();
        CGSphericPatch* createdCGSphericPatch( int resolution, float width );
        CGPatch* createdCGPatch( int resolution, float width );
        CGSphericPatch* getCGSphericPatch()const;
        CGPatch* getCGPatch()const;
    private:
        CGSphericPatch* sphericPatch; 
        CGPatch* patch; 
    };


}
#endif // PATCH_H
