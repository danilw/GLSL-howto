#include "SceneObject.h"

using namespace terra;

SceneObject::SceneObject( glm::vec3 position ) : position( position ) {
}

SceneObject::~SceneObject() {
}
