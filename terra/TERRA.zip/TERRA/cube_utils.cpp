// Includes GLM
#include <glm/gtx/transform.hpp>

#include "cube_utils.h"

using namespace glm;

mat4 terra::getRTTViewMatrix( cubeFace face ) {
    mat4 modelviewFBO( 1.0 );
    switch( face ) {
    case CUBE_TOP:
        modelviewFBO = rotate( modelviewFBO, -90.0f, 1.0f, 0.0f, 0.0f ); 
        break;
    case CUBE_BOTTOM:
        modelviewFBO = rotate( modelviewFBO, 90.0f, 1.0f, 0.0f, 0.0f ); 
        break;
    case CUBE_LEFT:
        modelviewFBO = rotate( modelviewFBO, -90.0f, 0.0f, 1.0f, 0.0f ); 
        break;
    case CUBE_RIGHT:
        modelviewFBO = rotate( modelviewFBO, 90.0f, 0.0f, 1.0f, 0.0f ); 
        break;
    case CUBE_FRONT:
        modelviewFBO = rotate( modelviewFBO, 180.0f, 0.0f, 1.0f, 0.0f ); 
        break;
    case CUBE_BACK:
        break;
    }
    return modelviewFBO;
}

mat4 terra::getCubeFaceMatrix( cubeFace face ) {
    mat4 matrix( 1.0 );
    switch( face ) {
    case CUBE_TOP:
        break;
    case CUBE_BOTTOM:
        matrix = rotate( matrix, 180.0f, 1.0f, 0.0f, 0.0f );
        break;
    case CUBE_LEFT:
        matrix = rotate( matrix, -90.0f, 1.0f, 0.0f, 0.0f ); 
        matrix = rotate( matrix, 90.0f, 0.0f, 0.0f, 1.0f );
        break;
    case CUBE_RIGHT:
        matrix = rotate( matrix, -90.0f, 1.0f, 0.0f, 0.0f ); 
        matrix = rotate( matrix, -90.0f, 0.0f, 0.0f, 1.0f );
        break;
    case CUBE_FRONT:
        matrix = rotate( matrix, 180.0f, 0.0f, 0.0f, 1.0f ); 
        matrix = rotate( matrix, 90.0f, 1.0f, 0.0f, 0.0f );
        break;
    case CUBE_BACK:
        matrix = rotate( matrix, -90.0f, 1.0f, 0.0f, 0.0f );
        break;
    }
    return matrix;
}

///Philip Nowell: cube-to-sphere mapping
///http://mathproofs.blogspot.fr/2005/07/mapping-cube-to-sphere.html
vec3 terra::cubeToSphereMapping( const vec3 &v ) {
    vec3 res;
    res.x = v.x * sqrt( 1 - ( v.y * v.y ) / 2.0 - ( v.z * v.z ) / 2.0 + ( v.y * v.y * v.z * v.z ) / 3.0 );
    res.y = v.y * sqrt( 1 - ( v.z * v.z ) / 2.0 - ( v.x * v.x ) / 2.0 + ( v.x * v.x * v.z * v.z ) / 3.0 );
    res.z = v.z * sqrt( 1 - ( v.x * v.x ) / 2.0 - ( v.y * v.y ) / 2.0 + ( v.y * v.y * v.x * v.x ) / 3.0 );

    return res;
}

