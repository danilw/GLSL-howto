#include "Texture.h"
#include "utils.h" //getGLError()

using namespace terra;

Texture::Texture() : id( 0 ), width( 0 ), height( 0 ), m_format( 0 ), internalFormat( 0 ), emptyTexture( false ), blur( true ) {

}


Texture::Texture( int width, int height, GLenum format, GLenum internalFormat, bool emptyTexture, bool blur ) : id( 0 ), width( width ),
    height( height ), m_format( format ), internalFormat( internalFormat ), emptyTexture( emptyTexture ), blur( blur ) {

}

Texture::Texture( const UbytePixelBuffer& buffer ) {
    load( buffer );
}


Texture::~Texture() {

    if( glIsTexture( id ) == GL_TRUE )
        glDeleteTextures( 1, &id );
}


bool Texture::load( const UbytePixelBuffer& buffer ) {
    width = buffer.getWidth();
    height = buffer.getHeight();
    m_format = buffer.getFormat();
    internalFormat = buffer.getChannels();

    if( glIsTexture( id ) == GL_TRUE )
        glDeleteTextures( 1, &id );

    glGenTextures( 1, &id );

    glBindTexture( GL_TEXTURE_2D, id );

    //glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, m_format, pBuffer->GetDataType(), pBuffer->GetBuffer());
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, m_format, GL_UNSIGNED_BYTE, buffer.getBuffer() );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );

    glBindTexture( GL_TEXTURE_2D, 0 );
    return true;
}


GLuint Texture::getID() const {
    return id;
}



void Texture::loadEmptyTexture() {
    if( glIsTexture( id ) == GL_TRUE )
        glDeleteTextures( 1, &id );


    glGenTextures( 1, &id );

    glBindTexture( GL_TEXTURE_2D, id );

    glTexImage2D( GL_TEXTURE_2D, 0, internalFormat, width, height, 0, m_format, GL_FLOAT, 0 );
    //glTexImage2D(GL_TEXTURE_2D, 0, internalFormat, width, height, 0, m_format, GL_UNSIGNED_BYTE, 0);

    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
    float borderColor[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glTexParameterfv( GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, borderColor );
    if( blur ) {
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST ); //GL_NEAREST
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR ); //GL_LINEAR
    } else {
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST ); //GL_NEAREST
        glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST ); //GL_LINEAR
    }

    glBindTexture( GL_TEXTURE_2D, 0 );
}
