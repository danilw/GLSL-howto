// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif
#include <iostream>

#include "utils.h"

void terra::getGLError( bool verbose ) {
    GLenum glErr = glGetError();
    if( glErr != GL_NO_ERROR ) {
        switch( glErr ) {
        case GL_INVALID_ENUM:
            if( verbose )
                std::cerr << "GL_INVALID_ENUM" << std::endl;
            break;
        case GL_INVALID_VALUE:
            if( verbose )
                std::cerr << "GL_INVALID_VALUE" << std::endl;
            break;
        case GL_INVALID_OPERATION:
            if( verbose )
                std::cerr << "GL_INVALID_OPERATION" << std::endl;
            break;
        case GL_INVALID_FRAMEBUFFER_OPERATION:
            if( verbose )
                std::cerr << "GL_INVALID_FRAMEBUFFER_OPERATION" << std::endl;
            break;
        case GL_OUT_OF_MEMORY:
            if( verbose )
                std::cerr << "GL_OUT_OF_MEMORY" << std::endl;
            break;
/*        case GL_STACK_UNDERFLOW:
            if( verbose )
                std::cerr << "GL_STACK_UNDERFLOW" << std::endl;
            break;
        case GL_STACK_OVERFLOW:
            if( verbose )
                std::cerr << "GL_STACK_OVERFLOW" << std::endl;
            break;
*/
        default:
            if( verbose )
                std::cerr << "UNDEFINED GL_ERROR" << std::endl;
        }
    }
}
