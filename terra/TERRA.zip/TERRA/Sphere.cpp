#include <glm/gtx/transform.hpp>

#include "Sphere.h"
#include "cube_utils.h"

using namespace glm;
using namespace terra;

Sphere::Sphere( float radius ) {
    this->radius = radius;
    //this->shader = shader;
    build();
}

Sphere::~Sphere() {
    for( int i = 0; i < 6; i++ ) {
        delete cubeFaces[i];
    }
}

void Sphere::build() {
    mat4 matrix;
    for( int i = 0; i < 6; i++ ) {
        matrix = getCubeFaceMatrix( (cubeFace) i );
        matrix = translate( matrix, 0.0f, 1.0f, 0.0f );
        cubeFaces[i] = new SphericPatch( 32, 2.0f, matrix, radius );
        cubeFaces[i]->build();
        //cubeFaces[i]->buildNormal ( i );
        cubeFaces[i]->load();
    }
}

void Sphere::draw()const {
    for( int i = 0; i < 6; i++ ) {
        cubeFaces[i]->draw();
    }
}
