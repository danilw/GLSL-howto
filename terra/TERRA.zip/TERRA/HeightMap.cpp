#include <iostream>

#include <glm/gtx/transform.hpp>

#include "HeightMap.h"
#include "Patch.h"

using namespace terra;
using namespace glm;
RenderingMap::RenderingMap( const vec3& center, float patchSize, int mapSize, GLuint textureID, const Shader* shader, bool blur ) {

    renderingFrameBuffer = new FrameBuffer( mapSize, mapSize, blur );
    patch = NULL;
    this->center = center;
    this->patchSize = patchSize;
    this->mapSize = mapSize;
    this->shader = shader;
    this->textureID = textureID;
    patchMatrix = mat4( 1.0 );
    texMatrix = mat4( 1.0 );
    modelviewRTT = mat4( 1.0 );
    projectionRTT = mat4( 1.0 );
    shaderID = shader->getProgramID();
}

RenderingMap::~RenderingMap() {
    delete renderingFrameBuffer;
}

void RenderingMap::build() {
    computePatchMatrix();
    //buildPatch();
    computeViewProMatrix();
    texMatrix = patch->getTexMatrix();
    if( ! renderingFrameBuffer->load() )
        std::cerr << "FrameBuffer " << std::endl;
}

void RenderingMap::renderToTexture()const {
    glBindFramebuffer( GL_FRAMEBUFFER, renderingFrameBuffer->getID() );

    glViewport( 0, 0, renderingFrameBuffer->getWidth(), renderingFrameBuffer->getHeight() );
    glClearColor( 0.0, 0.0, 0.0, 0.0 );
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    //glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
    bool cull = glIsEnabled( GL_CULL_FACE );
    glDisable( GL_CULL_FACE );

    glUseProgram( shaderID );

    glUniformMatrix4fv( glGetUniformLocation( shaderID, "projection" ), 1, GL_FALSE, value_ptr( projectionRTT ) );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "modelview" ), 1, GL_FALSE, value_ptr( modelviewRTT ) );

    defineUniforms();
    glActiveTexture( GL_TEXTURE0 );
    glBindTexture( GL_TEXTURE_2D, textureID );
    patch->draw();

    glBindTexture( GL_TEXTURE_2D, 0 );

    glUseProgram( 0 );

    /*if( renderMode != terra::POLYGON )
        glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );*/

    if( cull )
        glEnable( GL_CULL_FACE );
    //glBindFramebuffer( GL_FRAMEBUFFER, 0 );
}

GLuint RenderingMap::getColorBufferId() const {
    return( renderingFrameBuffer->getColorBufferID( 0 ) );
}

LODCubeMap::LODCubeMap( const PlanetConfig* config, CGPatch* patch, const vec3& center, int level, cubeFace face,
                       float patchSize, int mapSize, int overlap, GLuint textureID, const Shader* shader, bool blur )
    : RenderingMap( center, patchSize, mapSize, textureID, shader, blur ) {
    this->config = config;
    this->level = level;
    this->face = face;
    this->overlap = overlap;
    this->patch = patch;
    //border = 0;
    computeOverlap();
}

LODCubeMap::~LODCubeMap() {
    //if(patch!=NULL) delete patch;
}

void LODCubeMap::computeOverlap() {

    float over = ( float )overlap / ( float )( mapSize - overlap ) * patchSize;
    this->patchSize += over;
}

void LODCubeMap::computePatchMatrix() {
    float scale = patchSize / 2.0; //patchSize/originalPatchSize
    patchMatrix = getCubeFaceMatrix( face );
    patchMatrix = glm::translate( patchMatrix, center.x, center.y, center.z );
    patchMatrix = glm::scale( patchMatrix, scale, scale, scale );

    //float s = (mapSize - border) / (float)mapSize;
    //texMatrix = glm::translate(texMatrix, border/2.0f/mapSize, border/2.0f/mapSize, 0.0f);
    //texMatrix = glm::scale(texMatrix, s, s, 1.0f);
}

void LODCubeMap::computeViewProMatrix() {
    modelviewRTT = getRTTViewMatrix( face );
    projectionRTT = glm::ortho( center.x - patchSize / 2.0f, center.x + patchSize / 2.0f , center.z - patchSize / 2.0f, center.z + patchSize / 2.0f, -10 * config->radius, 10 * config->radius );
}

/*
void LODCubeMap::buildPatch() {
        patch = new Patch(1, patchSize, patchMatrix, shader);
        patch->build();
        patch->buildNormal();
        patch->load();

}
*/
void LODCubeMap::defineUniforms()const {
    glUniform1f( glGetUniformLocation( shaderID, "scale" ), config->fractalScale );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "texMatrix" ), 1, GL_FALSE, value_ptr( texMatrix ) );
    glUniformMatrix4fv( glGetUniformLocation( shaderID, "transform" ), 1, GL_FALSE, value_ptr( patchMatrix ) );
}

NormalMap::NormalMap( const PlanetConfig* config, CGPatch* patch, const vec3& center, int level, cubeFace face,
                     float patchSize, int mapSize, int overlap, GLuint textureID, const Shader* shader )
    : LODCubeMap( config, patch, center, level, face, patchSize, mapSize, overlap, textureID, shader, true ) {
}

void NormalMap::defineUniforms()const {
    LODCubeMap::defineUniforms();
    glUniform1i( glGetUniformLocation( shaderID, "level" ), level );
    glUniform1i( glGetUniformLocation( shaderID, "plane" ), face );
    glUniform1i( glGetUniformLocation( shaderID, "mapSize" ), mapSize );
    glUniform1f( glGetUniformLocation( shaderID, "width" ), patchSize );
}

