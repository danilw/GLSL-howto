#include "Shader.h"
#include <iostream>
#include <fstream>

using namespace glm;
using namespace terra;

Shader::Shader() : vertexID( 0 ), fragmentID( 0 ), programID( 0 ), vertexSource(), fragmentSource() {
}


Shader::Shader( std::string vertexSource, std::string fragmentSource ) : vertexID( 0 ), fragmentID( 0 ), programID( 0 ),
    vertexSource( vertexSource ), fragmentSource( fragmentSource ) {
    load();
}

Shader::~Shader() {
    std::cout << "Shader destructor... " << vertexSource << " " << fragmentSource << std::endl;
    glDeleteShader( vertexID );
    glDeleteShader( fragmentID );
    glDeleteProgram( programID );
}


bool Shader::init( std::string vertexSource, std::string fragmentSource ) {

    vertexSource = vertexSource;
    fragmentSource = fragmentSource;
    return ( load() );
}

bool Shader::load() {
    if( glIsShader( vertexID ) == GL_TRUE )
        glDeleteShader( vertexID );

    if( glIsShader( fragmentID ) == GL_TRUE )
        glDeleteShader( fragmentID );

    if( glIsProgram( programID ) == GL_TRUE )
        glDeleteProgram( programID );

    if( !compileShader( vertexID, GL_VERTEX_SHADER, vertexSource ) )
        return false;

    if( !compileShader( fragmentID, GL_FRAGMENT_SHADER, fragmentSource ) )
        return false;

    programID = glCreateProgram();

    glAttachShader( programID, vertexID );
    glAttachShader( programID, fragmentID );

    glBindAttribLocation( programID, 0, "in_Vertex" );
    glBindAttribLocation( programID, 1, "in_Normal" );
    glBindAttribLocation( programID, 2, "in_TexCoord0" );

    glLinkProgram( programID );

    GLint linkError( 0 );
    glGetProgramiv( programID, GL_LINK_STATUS, &linkError );

    if( linkError != GL_TRUE ) {

        GLint errorSize( 0 );
        glGetProgramiv( programID, GL_INFO_LOG_LENGTH, &errorSize );

        char *errorSz = new char[errorSize + 1];

        glGetProgramInfoLog( programID, errorSize, &errorSize, errorSz );
        errorSz[errorSize] = '\0';

        std::cerr << "Files: " << vertexSource << "  " << fragmentSource << std::endl << errorSz << std::endl;

        delete[] errorSz;
        glDeleteProgram( programID );

        return false;
    }

    else {
        std::cout << "Shader loaded : " << vertexSource << "  " << fragmentSource << std::endl;
        return true;
    }
}


bool Shader::compileShader( GLuint &shader, GLenum type, std::string const &sourceFile ) {
    shader = glCreateShader( type );

    if( shader == 0 ) {
        std::cout << "E shader (" << type << ") " << std::endl;
        return false;
    }

    std::ifstream file( sourceFile.c_str() );

    if( !file ) {
        std::cout << "E " << sourceFile << " " << std::endl;
        glDeleteShader( shader );

        return false;
    }

    std::string line;
    std::string sourceCode;

    while( getline( file, line ) )
        sourceCode += line + '\n';

    file.close();

    const GLchar* sourceCodeString = sourceCode.c_str();

    glShaderSource( shader, 1, &sourceCodeString, 0 );

    glCompileShader( shader );

    GLint compileError( 0 );
    glGetShaderiv( shader, GL_COMPILE_STATUS, &compileError );

    if( compileError != GL_TRUE ) {

        GLint errorSize( 0 );
        glGetShaderiv( shader, GL_INFO_LOG_LENGTH, &errorSize );

        char *errorSz = new char[errorSize + 1];

        glGetShaderInfoLog( shader, errorSize, &errorSize, errorSz );
        errorSz[errorSize] = '\0';

        std::cerr << "Fichier: " << sourceFile << std::endl << errorSz << std::endl;

        delete[] errorSz;
        glDeleteShader( shader );

        return false;
    }

    else
        return true;
}

GLuint Shader::getProgramID() const {
    return programID;
}
