/**@file Texture.h
 */
#ifndef TEXTURE_H
#define TEXTURE_H

// Includes OpenGL
#ifdef WIN32
#include <GL/glew.h>

#else
#define GL3_PROTOTYPES 1
#include <GL3/gl3.h>

#endif

#include <SDL2/SDL.h>
#include <iostream>
#include <string>

#include "PixelBuffer.h"

namespace terra {

    class Texture {
    public:

        Texture();


        Texture( int width, int height, GLenum format, GLenum internalFormat, bool emptyTexture, bool blur );


        Texture( const UbytePixelBuffer& buffer );

        ~Texture();


        bool load( const UbytePixelBuffer& buffer );


        void loadEmptyTexture();


        GLuint getID() const;


    private:

        GLuint id;
        int width;
        int height;
        GLenum m_format;
        GLenum internalFormat;
        bool emptyTexture;
        bool blur;
    };
}
#endif //TEXTURE_H
