/**@file Planet.h
 */
#ifndef PLANET_H
#define PLANET_H

// Includes GLM
#include <glm/glm.hpp>

#include "QuadTreeNode.h"
#include "SkyDome.h"
#include "Camera.h"
#include "Patch.h"
#include "SceneObject.h"
#include "Config.h"
#include "utils.h"

namespace terra {

    class Planet : public SceneObject {
    public:
        Planet( const PlanetConfig& config, Camera* camera, glm::vec3* light );
        ~Planet();
        void update();
        void render( const glm::mat4 &projection, const glm::mat4 &modelview, RenderMode renderMode );

    private:
        LODQuadTree* quadTree; 
        SkyDome* atmosphere; 
        SkyDome* sunDome; 
        TerrainShaders terrainShaders;
        ScatteringShader* atmosphereShader;
        ScatteringShader* sunDomeShader;
    };
}
#endif // PLANET_H
