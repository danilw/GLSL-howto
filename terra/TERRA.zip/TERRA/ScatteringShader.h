/**@file ScatteringShader.h
 */
#ifndef SCATTERINGSHADER_H
#define SCATTERINGSHADER_H

// Includes GLM
#include <glm/glm.hpp>

#include "Shader.h"
#include "Camera.h"
namespace terra {

    class ScatteringShader : public Shader {
    public:

        ScatteringShader( std::string vertexSource, std::string fragmentSource, float minRadius, float maxRadius, const Camera* camera, const glm::vec3* light );

        virtual void sendScatteringUniforms()const;
    protected:
        const Camera* camera;
        const glm::vec3* light;
        int samples;
        float Kr, Kr4PI;
        float Km, Km4PI;
        float ESun;
        float g;
        float innerRadius;
        float outerRadius;
        float scale;
        float wavelength[3];
        float wavelength4[3];
        glm::vec3 invWavelength4;
        float rayleighScaleDepth;
        float mieScaleDepth;
    };
}
#endif // SCATTERINGSHADER_H
