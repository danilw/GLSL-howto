#!/bin/sh

source /home/danil/2018_projects/wasm_sdk_bin/em_upd3/emsdk/emsdk_env.sh

em++ utils.cpp transform-feedback.cpp -DGL_GLEXT_PROTOTYPES -DRELEASE -DWEB_BUILD --std=c++11 -Oz -lGL -lGLEW -lm -lSDL2 -s USE_SDL=2 -s ALLOW_MEMORY_GROWTH=0 -s FULL_ES3=1 -s USE_WEBGL2=2 -s WASM=1 -o build/test.html
