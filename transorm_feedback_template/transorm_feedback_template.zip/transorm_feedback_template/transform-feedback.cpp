
#include <iomanip>
#include <cstdlib>
#include <thread>
#include <chrono>
#include <random>
#include <iostream>

#ifdef WEB_BUILD
#include <emscripten.h>
#endif

#include "utils.h"

// to launch shaders from vertexshaderart.com 
// with working transform feedback in/out (to advance shaders)
// GLES3 with WebGL2 support

// example shader https://www.vertexshaderart.com/art/nL6YpkW8YvGKNEKtj

const GLint draw_type=GL_POINTS; //GL_TRIANGLES //GL_LINES

enum VertexAttribs {
    feedback_data_1,
    feedback_data_2,
};

#define BG_COLOR .098, .098, .12
#define WIN_TITLE "Transform Feedback template"
#define WIN_WIDTH 1280
#define WIN_HEIGHT 720
//particles
#define NUM_PARTICLES 50000
#define NUM_FLOATS_PER_VERTEX 8
#define MAX_ELEMENTS (NUM_PARTICLES * NUM_FLOATS_PER_VERTEX)

GLuint vbo = 0;
GLuint tbo = 0;
GLint uniform_time;
GLint uniform_mouse;
GLint uniform_resolution;
GLint uniform_feedback;
GLint uniform_feedback_time;
GLint uniform_feedback_mouse;
GLint uniform_feedback_resolution;
GLfloat mouseX = WIN_WIDTH / 2;
GLfloat mouseY = WIN_HEIGHT / 2;
unsigned int lastFrameTick = 0;

const GLchar* vShaderSrc = GLSL3(
    in vec4 feedback_data_1;
    in vec4 feedback_data_2;

    uniform vec2 mouse;
    uniform float time;
    uniform vec2 resolution;
    

    out vec4 v_color;


// https://www.vertexshaderart.com/art/nL6YpkW8YvGKNEKtj
/*
   point cloud vs spheres by Kabuto

   Recreated this well-known demo effect. A bit tricky without being able to store history for points, so it's just computed again and again for each render pass
*/

vec3 posf2(float t, float i) {
	return vec3(
      sin(t+i*.9553) +
      sin(t*1.311+i) +
      sin(t*1.4+i*1.53) +
      sin(t*1.84+i*.76),
      sin(t+i*.79553+2.1) +
      sin(t*1.311+i*1.1311+2.1) +
      sin(t*1.4+i*1.353-2.1) +
      sin(t*1.84+i*.476-2.1),
      sin(t+i*.5553-2.1) +
      sin(t*1.311+i*1.1-2.1) +
      sin(t*1.4+i*1.23+2.1) +
      sin(t*1.84+i*.36+2.1)
	)*.2;
}

vec3 posf0(float t) {
  return posf2(t,-1.)*3.5;
}

vec3 posf(float t, float i) {
  return posf2(t*.3,i) + posf0(t);
}

vec3 push(float t, float i, vec3 ofs, float lerpEnd) {
  vec3 pos = posf(t,i)+ofs;
  
  vec3 posf = fract(pos+.5)-.5;
  
  float l = length(posf)*2.;
  return (- posf + posf/l)*(1.-smoothstep(lerpEnd,1.,l));
}

void main() {
  // more or less random movement
  float t = time*.20;
  float i = vertexId+sin(vertexId)*100.;

  vec3 pos = posf(t,i);
  vec3 ofs = vec3(0);
  for (float f = -10.; f < 0.; f++) {
	  ofs += push(t+f*.05,i,ofs,2.-exp(-f*.1));
  }
  ofs += push(t,i,ofs,.999);
  
  pos -= posf0(t);
  
  pos += ofs;
  
  
  pos.yz *= mat2(.8,.6,-.6,.8);
  pos.xz *= mat2(.8,.6,-.6,.8);
  
  pos *= 1.;
  

  pos.z += .7;
  
  pos.xy *= .6/pos.z;
  
  gl_Position = vec4(pos.x, pos.y*resolution.x/resolution.y, pos.z*.1, 1);
  gl_PointSize = 1./pos.z;

  v_color = vec4(abs(ofs/max(length(ofs),1e-9))*.3+.7,1);
}
);

const GLchar* fShaderSrc = GLSL3(
    in vec4 v_color;
    out vec4 fragColor;
    void main()
    {
        fragColor = vec4(v_color);
    }
);

const GLchar* feedback_shader = GLSL3(
    in vec4 feedback_data_1;
    in vec4 feedback_data_2;

    out vec4 feedback_data_1_out;
    out vec4 feedback_data_2_out;

    uniform vec4 uniform_feedback;
    uniform vec2 mouse;
    uniform float time;
    uniform vec2 resolution;

    void main() {
        feedback_data_1_out=feedback_data_1;
        feedback_data_1_out.x+=0.01;
        feedback_data_2_out=feedback_data_2;
        gl_Position = vec4 (0.0, 0.0, 0.0, 0.0);
    }
);

const GLchar* feedback_shader_f = GLSL3(
out vec4 out_color;
void main(void) {
    out_color = vec4(1.0, 1.0, 1.0, 1.0);
}
);

void updateFeedbackBuffer (GLuint program, int width, int height)
{
    glUseProgram (program);
    glUniform4f (uniform_feedback, 0,0,0,0);
    glUniform1f (uniform_feedback_time, (GLfloat) lastFrameTick / 100000.0f);
    glUniform2f (uniform_feedback_mouse, mouseX/((float)WIN_WIDTH), mouseY/((float)WIN_HEIGHT));
    glUniform2f (uniform_feedback_resolution, WIN_WIDTH, WIN_HEIGHT);

    glEnable (GL_RASTERIZER_DISCARD);
    glBindBuffer (GL_ARRAY_BUFFER, vbo);
    glEnableVertexAttribArray (feedback_data_1);
    glEnableVertexAttribArray (feedback_data_2);

    GLchar* offset = 0;
    glVertexAttribPointer (feedback_data_1,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           offset);
    glVertexAttribPointer (feedback_data_2,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           4 * sizeof (GLfloat) + offset);

    glBindBufferBase (GL_TRANSFORM_FEEDBACK_BUFFER, 0, tbo);
    glBeginTransformFeedback (GL_POINTS);
    glDrawArrays (GL_POINTS, 0, NUM_PARTICLES);
    glEndTransformFeedback ();
    glBindBuffer (GL_ARRAY_BUFFER, 0);
    glDisableVertexAttribArray (feedback_data_1);
    glDisableVertexAttribArray (feedback_data_2);
    glDisable (GL_RASTERIZER_DISCARD);

    glFlush ();
}

void initGL (SDL_Window* window, int width, int height)
{
    if (!window) {
        return;
    }

    dumpGLInfo ();

    glClearColor (BG_COLOR, 1.0);
    //glViewport (0, 0, width, height);

    // setup proper GL-blending
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBlendEquation (GL_FUNC_ADD);
    //glEnable (GL_PROGRAM_POINT_SIZE);
}

void resizeGL (SDL_Window* window, int width, int height)
{
    if (!window) {
        return;
    }
    glViewport (0, 0, width, height);
}

void drawGL (SDL_Window* window, GLuint program, GLuint bufferId, int width, int height)
{
    // vbo, uniform, attrib
    static unsigned int fps = 0;
    static unsigned int lastTick = 0;
    static unsigned int currentTick = 0;

    if (!window) {
        return;
    }

    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram (program);
    glBindBuffer (GL_ARRAY_BUFFER, bufferId);

    glUniform1f (uniform_time, (GLfloat) lastFrameTick / 1000.0f);
    glUniform2f (uniform_mouse, mouseX/((float)WIN_WIDTH), mouseY/((float)WIN_HEIGHT));
    glUniform2f (uniform_resolution, width, height);
    
    glEnableVertexAttribArray (feedback_data_1);
    glEnableVertexAttribArray (feedback_data_2);

    GLchar* offset = 0;
    glVertexAttribPointer (feedback_data_1,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           offset);
    glVertexAttribPointer (feedback_data_2,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           4 * sizeof (GLfloat) + offset);

    glDrawArrays (draw_type, 0, NUM_PARTICLES);
    glDisableVertexAttribArray (feedback_data_1);
    glDisableVertexAttribArray (feedback_data_2);
    glBindTexture (GL_TEXTURE_2D, 0);
    glBindBuffer (GL_ARRAY_BUFFER, 0);
    SDL_GL_SwapWindow (window);
    std::swap (vbo, tbo);

    fps++;
    currentTick = SDL_GetTicks ();

    if (currentTick - lastTick > 1000)
    {
        //std::cout << fps << " fps" << std::endl;
        fps = 0;
        lastTick = currentTick;
    }
    lastFrameTick = currentTick;
}


SDL_Window* window;
GLuint feedbackProg;
GLuint particleProg;
GLfloat* data ;

void main_loop(){
  #ifndef WEB_BUILD
  while(true)
  #endif
  {
        SDL_Event event;
        while (SDL_PollEvent (&event)) {
            switch (event.type) {
                case SDL_KEYUP:
                    if (event.key.keysym.sym == SDLK_ESCAPE) {
                        return;
                    }
                    if (event.key.keysym.sym == SDLK_SPACE) {
                        updateVBO (vbo,
                                   MAX_ELEMENTS * sizeof (GLfloat),
                                   data,
                                   GL_DYNAMIC_COPY);
                        updateVBO (tbo,
                                   MAX_ELEMENTS * sizeof (GLfloat),
                                   nullptr,
                                   GL_DYNAMIC_COPY);
                    }
                break;

                case SDL_MOUSEMOTION:
                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_LEFT) || 
                        SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_RIGHT)) {
                        mouseX = (GLfloat) event.motion.x;
                        mouseY = (GLfloat) event.motion.y;
                    }
                break;

                case SDL_MOUSEBUTTONDOWN:
                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_LEFT)) {
                        mouseX = (GLfloat) event.button.x;
                        mouseY = (GLfloat) event.button.y;
                    }

                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_RIGHT)) {
                          
                    }

                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_MIDDLE)) {
                          
                    }
                break;

                case SDL_WINDOWEVENT:
                    if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
                        return;
                    } else if ((event.window.event == SDL_WINDOWEVENT_RESIZED)||(event.window.event == SDL_WINDOWEVENT_SIZE_CHANGED)) {
                        resizeGL (window,
                                  event.window.data1,
                                  event.window.data2);
                    }
                break;

                default:
                break;
            }
        }

        int width = 0;
        int height = 0;
        SDL_GetWindowSize (window, &width, &height);
        updateFeedbackBuffer (feedbackProg, width, height);
        drawGL (window, particleProg, vbo, width, height);
    }
}

int main(int argc, char* argv[]) {
    // initialize SDL
    int result = 0;
    result = SDL_Init (SDL_INIT_VIDEO);
    if (result != 0) {
        std::cout << "SDL_Init() failed: " << SDL_GetError () << std::endl;
        return 1;
    }

    // initialize SDL_image
    int flags = IMG_INIT_PNG | IMG_INIT_JPG;
    result = IMG_Init (flags);
    if ((result & flags) != flags) {
        std::cout << "IMG_Init() failed: " << IMG_GetError () << std::endl;
        return 2;
    }

    SDL_GL_SetAttribute (SDL_GL_RED_SIZE, 8);
    SDL_GL_SetAttribute (SDL_GL_GREEN_SIZE, 8);
    SDL_GL_SetAttribute (SDL_GL_BLUE_SIZE, 8);
    SDL_GL_SetAttribute (SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute (SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute (SDL_GL_MULTISAMPLESAMPLES, 4);
    SDL_GL_SetAttribute (SDL_GL_MULTISAMPLEBUFFERS, 1);
    SDL_GL_SetAttribute (SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute (SDL_GL_CONTEXT_MINOR_VERSION, 0);
    /*SDL_GL_SetAttribute (SDL_GL_CONTEXT_PROFILE_MASK,
                         SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);*/

    // setup window
    window = NULL;
    SDL_ClearError ();
    window = SDL_CreateWindow (WIN_TITLE,
                               SDL_WINDOWPOS_UNDEFINED,
                               SDL_WINDOWPOS_UNDEFINED,
                               WIN_WIDTH,
                               WIN_HEIGHT,
                               SDL_WINDOW_OPENGL |
                               SDL_WINDOW_RESIZABLE);
    if (!window) {
        std::cout << "CreateWindow() failed: " << SDL_GetError () << std::endl;
        IMG_Quit ();
        SDL_Quit ();
        return 3;
    }

    SDL_ClearError ();

    // setup OpenGL-context
    SDL_GLContext context;
    SDL_ClearError ();
    context = SDL_GL_CreateContext (window);
    if (!context) {
        std::cout << "CreateContext() failed: " << SDL_GetError () << std::endl;
        SDL_DestroyWindow (window);
        IMG_Quit ();
        SDL_Quit ();
        return 4;
    }

    int success = glewInit();
    if (success != GLEW_OK) {
        std::cout << "OpenGL initialization failed" << std::endl;
    }

    // create vertex-only shader-program
    feedbackProg = createShaderProgram (feedback_shader, feedback_shader_f, false);
    glBindAttribLocation (feedbackProg, feedback_data_1, "feedback_data_1");
    glBindAttribLocation (feedbackProg, feedback_data_2, "feedback_data_2");

    const GLchar* feedbackVaryings[] = {"feedback_data_1_out", "feedback_data_2_out"};
    glTransformFeedbackVaryings (feedbackProg,
                                 2,
                                 feedbackVaryings,
                                 GL_INTERLEAVED_ATTRIBS);

    linkShaderProgram (feedbackProg);
    glUseProgram (feedbackProg);

    // Create input VBO, vertex format and upload inital data
    data = (GLfloat*) std::calloc (MAX_ELEMENTS, sizeof (GLfloat));

    for (int i = 0; i < MAX_ELEMENTS; i += NUM_FLOATS_PER_VERTEX) {
        data[i]   = 0.0;
        data[i+1] = 0.0;
        data[i+2] = 0.0;
        data[i+3] = 0.0;
        data[i+4] = 0.0;
        data[i+5] = 0.0;
        data[i+6] = 0.0;
        data[i+7] = 0.0;
    }

	vbo = createVBO (MAX_ELEMENTS * sizeof (GLfloat), data, GL_DYNAMIC_COPY);
	tbo = createVBO (MAX_ELEMENTS * sizeof (GLfloat), nullptr, GL_DYNAMIC_COPY);

    glUseProgram (feedbackProg);
    glEnableVertexAttribArray (feedback_data_1);
    glEnableVertexAttribArray (feedback_data_2);

    uniform_feedback = glGetUniformLocation (feedbackProg, "uniform_feedback");
    uniform_feedback_time = glGetUniformLocation (feedbackProg, "time");
    uniform_feedback_mouse = glGetUniformLocation (feedbackProg, "mouse");
    uniform_feedback_resolution = glGetUniformLocation (feedbackProg, "resolution");
    glUniform4f (uniform_feedback, 0,0,0,0);
    glUniform1f (uniform_feedback_time, 0.0);
    glUniform2f (uniform_feedback_mouse, mouseX/((float)WIN_WIDTH), mouseY/((float)WIN_HEIGHT));
    glUniform2f (uniform_feedback_resolution, WIN_WIDTH, WIN_HEIGHT);
    
    particleProg = createShaderProgram (vShaderSrc, fShaderSrc, true);
    
    glBindAttribLocation (particleProg, feedback_data_1, "feedback_data_1");
    glBindAttribLocation (particleProg, feedback_data_2, "feedback_data_2");
    uniform_time = glGetUniformLocation (particleProg, "time");
    uniform_mouse = glGetUniformLocation (particleProg, "mouse");
    uniform_resolution = glGetUniformLocation (particleProg, "resolution");
    glUniform1f (uniform_time, 0.0);
    glUniform2f (uniform_mouse, mouseX/((float)WIN_WIDTH), mouseY/((float)WIN_HEIGHT));
    glUniform2f (uniform_resolution, WIN_WIDTH, WIN_HEIGHT);

    initGL (window, WIN_WIDTH, WIN_HEIGHT);

    // event-loop
    #ifdef WEB_BUILD
    emscripten_set_main_loop(main_loop, 0, 1);
    #else
    main_loop();
    #endif

    // clean up
    glDeleteBuffers (1, &vbo);
    glDeleteBuffers (1, &tbo);
    glDeleteProgram (feedbackProg);
    glDeleteProgram (particleProg);
    SDL_GL_DeleteContext (context);
    SDL_DestroyWindow (window);
    IMG_Quit ();
    SDL_Quit ();
    std::free (data);

    return 0;
}
