#!/bin/sh

g++ utils.cpp transform-feedback.cpp -DGL_GLEXT_PROTOTYPES -Wall -Werror -Ofast -DRELEASE -std=c++11 -Os -pedantic -I/usr/include/SDL2 -D_REENTRANT -L/usr/lib64 -lSDL2 -lSDL2_image -lSDL2 -lGLEW -lX11 -lGLU -lGL -o test_feedback
