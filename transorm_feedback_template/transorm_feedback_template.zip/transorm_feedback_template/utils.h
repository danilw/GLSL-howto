
#ifndef _UTILS_H
#define _UTILS_H

#include <iostream>
#include <list>
#include <sstream>
#include <iterator>
#include <cassert>
#include <cmath>

#ifdef WEB_BUILD
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#else
#include <SDL.h>
#include <SDL_image.h>
#endif
#include <GL/glew.h>

#define GLSL3(src) "#version 300 es\nprecision highp float;\nprecision highp int;\n#define vertexId float(gl_VertexID)\n" #src

void frustum (float a,
              float b,
              float c,
              float d,
              float e,
              float g,
              float* out);
void perspective (float a,
                  float b,
                  float c,
                  float d,
                  float* out);
void ortho (float left,
            float right,
            float bottom,
            float top,
            float nearVal,
            float farVal,
            float* out);
void checkGLError (const char* func);
void dumpGLInfo ();
GLuint createTexture (const char* filename);
GLuint loadShader (const char *src, GLenum type);
GLuint createShaderProgram (const char* vertexShaderSrc,
                            const char* fragmentShaderSrc,
                            bool link);
void linkShaderProgram (GLuint progId);
GLuint createVBO (GLsizeiptr size, const GLvoid* data, GLenum usage);
void updateVBO (GLuint vbo, GLsizeiptr size, const GLvoid* data, GLenum usage);

#endif // _UTILS_H
