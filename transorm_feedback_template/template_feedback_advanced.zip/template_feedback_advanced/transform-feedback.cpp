
#include <iomanip>
#include <cstdlib>
#include <thread>
#include <chrono>
#include <random>
#include <iostream>

#ifdef WEB_BUILD
#include <emscripten.h>
#endif

#include "utils.h"

// to launch shaders from vertexshaderart.com 
// with working transform feedback in/out (to advance shaders)
// GLES3 with WebGL2 support

// example shader https://www.vertexshaderart.com/art/nL6YpkW8YvGKNEKtj

GLint draw_type=GL_TRIANGLES; //GL_TRIANGLES //GL_LINES

enum VertexAttribs {
    feedback_data_1,
    feedback_data_2,
};

#define BG_COLOR .098, .098, .12
#define WIN_TITLE "Transform fedback"
#define WIN_WIDTH 1280
#define WIN_HEIGHT 720
//particles
#define NUM_FLOATS_PER_VERTEX 8
#define NUM_PARTICLES_DEF 5000
int NUM_PARTICLES = NUM_PARTICLES_DEF;
int MAX_ELEMENTS = (NUM_PARTICLES_DEF * NUM_FLOATS_PER_VERTEX);

GLuint vbo = 0;
GLuint tbo = 0;
GLint uniform_time;
GLint uniform_mouse;
GLint uniform_resolution;
GLint uniform_feedback1;
GLint uniform_feedback2;
GLint uniform_feedback3;
GLint uniform_feedback_time;
GLint uniform_feedback_mouse;
GLint uniform_feedback_resolution;
GLint uniform_custom1;
GLint uniform_custom2;
GLint uniform_custom3;
GLfloat mouseX = WIN_WIDTH / 2;
GLfloat mouseY = WIN_HEIGHT / 2;
GLfloat last_resX=WIN_WIDTH;
GLfloat last_resY=WIN_HEIGHT;
GLfloat custom_uniform1[4]={0,0,0,0};
GLfloat custom_uniform2[4]={0,0,0,0};
GLfloat custom_uniform3[4]={0,0,0,0};
GLfloat custom_uniform_feedback1[4]={0,0,0,0};
GLfloat custom_uniform_feedback2[4]={0,0,0,0};
GLfloat custom_uniform_feedback3[4]={0,0,0,0};
unsigned int lastFrameTick = 0;


//template example, vShaderSrc unused
const GLchar* vShaderSrc = GLSL3(
    in vec4 feedback_data_1;
    in vec4 feedback_data_2;

    uniform vec2 mouse;
    uniform float time;
    uniform vec2 resolution;

    uniform vec4 uniform_custom1;
    uniform vec4 uniform_custom2;
    uniform vec4 uniform_custom3;

    out vec4 v_color;

    const float NUM=15.0;
    void main() {
      gl_PointSize = 64.0;
      float col = mod(vertexId, NUM + 1.0);
      float row = mod(floor(vertexId / NUM), NUM + 1.0); 
      float x = col / NUM * 2.0 - 1.0;
      float y = row / NUM * 2.0 - 1.0;
      gl_Position = vec4(x, y, 0, 1);
      v_color = vec4(fract(time + col / NUM + row / NUM), 0, 0, 1);
    }
);

char* vShaderSrc_from_js = NULL;

const GLchar* fShaderSrc = GLSL3(
    in vec4 v_color;
    out vec4 fragColor;
    void main()
    {
        fragColor = vec4(v_color);
    }
);

// template example, feedback_shader unused
const GLchar* feedback_shader = GLSL3(
    in vec4 feedback_data_1;
    in vec4 feedback_data_2;

    out vec4 feedback_data_1_out;
    out vec4 feedback_data_2_out;

    uniform vec4 uniform_feedback1;
    uniform vec4 uniform_feedback2;
    uniform vec4 uniform_feedback3;
    
    uniform vec2 mouse;
    uniform float time;
    uniform vec2 resolution;

    void main() {
        feedback_data_1_out=feedback_data_1;
        feedback_data_1_out.x+=0.01;
        feedback_data_2_out=feedback_data_2;
        gl_Position = vec4 (0.0, 0.0, 0.0, 0.0);
    }
);

char* feedback_shader_from_js = NULL;

const GLchar* feedback_shader_f = GLSL3(
out vec4 out_color;
void main(void) {
    out_color = vec4(1.0, 1.0, 1.0, 1.0);
}
);

void updateFeedbackBuffer (GLuint program, int width, int height)
{
    glUseProgram (program);
    glUniform4f (uniform_feedback1, custom_uniform_feedback1[0],custom_uniform_feedback1[1],custom_uniform_feedback1[2],custom_uniform_feedback1[3]);
    glUniform4f (uniform_feedback2, custom_uniform_feedback2[0],custom_uniform_feedback2[1],custom_uniform_feedback2[2],custom_uniform_feedback2[3]);
    glUniform4f (uniform_feedback3, custom_uniform_feedback3[0],custom_uniform_feedback3[1],custom_uniform_feedback3[2],custom_uniform_feedback3[3]);
    glUniform1f (uniform_feedback_time, (GLfloat) lastFrameTick / 1000.0f);
    glUniform2f (uniform_feedback_mouse, mouseX/((float)WIN_WIDTH), mouseY/((float)WIN_HEIGHT));
    glUniform2f (uniform_feedback_resolution, WIN_WIDTH, WIN_HEIGHT);

    glEnable (GL_RASTERIZER_DISCARD);
    glBindBuffer (GL_ARRAY_BUFFER, vbo);
    glEnableVertexAttribArray (feedback_data_1);
    glEnableVertexAttribArray (feedback_data_2);

    GLchar* offset = 0;
    glVertexAttribPointer (feedback_data_1,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           offset);
    glVertexAttribPointer (feedback_data_2,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           4 * sizeof (GLfloat) + offset);

    glBindBufferBase (GL_TRANSFORM_FEEDBACK_BUFFER, 0, tbo);
    glBeginTransformFeedback (GL_POINTS);
    glDrawArrays (GL_POINTS, 0, NUM_PARTICLES);
    glEndTransformFeedback ();
    glBindBuffer (GL_ARRAY_BUFFER, 0);
    glDisableVertexAttribArray (feedback_data_1);
    glDisableVertexAttribArray (feedback_data_2);
    glDisable (GL_RASTERIZER_DISCARD);

    glFlush ();
}

void initGL (SDL_Window* window, int width, int height)
{
    if (!window) {
        return;
    }

    dumpGLInfo ();

    glClearColor (BG_COLOR, 1.0);
    //glViewport (0, 0, width, height);

    // setup proper GL-blending
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBlendEquation (GL_FUNC_ADD);
    //glEnable (GL_PROGRAM_POINT_SIZE);
}

void resizeGL (SDL_Window* window, int width, int height)
{
    if (!window) {
        return;
    }
    glViewport (0, 0, width, height);
}

void drawGL (SDL_Window* window, GLuint program, GLuint bufferId, int width, int height)
{
    // vbo, uniform, attrib
    static unsigned int fps = 0;
    static unsigned int lastTick = 0;
    static unsigned int currentTick = 0;

    if (!window) {
        return;
    }

    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram (program);
    glBindBuffer (GL_ARRAY_BUFFER, bufferId);

    glUniform1f (uniform_time, (GLfloat) lastFrameTick / 1000.0f);
    glUniform2f (uniform_mouse, mouseX/((float)WIN_WIDTH)-0.5, mouseY/((float)WIN_HEIGHT)-0.5);
    glUniform2f (uniform_resolution, width, height);
    glUniform4f (uniform_custom1, custom_uniform1[0],  custom_uniform1[1], custom_uniform1[2], custom_uniform1[3]);
    glUniform4f (uniform_custom2, custom_uniform2[0],  custom_uniform2[1], custom_uniform2[2], custom_uniform2[3]);
    glUniform4f (uniform_custom3, custom_uniform3[0],  custom_uniform3[1], custom_uniform3[2], custom_uniform3[3]);
    
    glEnableVertexAttribArray (feedback_data_1);
    glEnableVertexAttribArray (feedback_data_2);

    GLchar* offset = 0;
    glVertexAttribPointer (feedback_data_1,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           offset);
    glVertexAttribPointer (feedback_data_2,
                           4,
                           GL_FLOAT,
                           GL_FALSE,
                           NUM_FLOATS_PER_VERTEX * sizeof (GLfloat),
                           4 * sizeof (GLfloat) + offset);

    glDrawArrays (draw_type, 0, NUM_PARTICLES);
    glDisableVertexAttribArray (feedback_data_1);
    glDisableVertexAttribArray (feedback_data_2);
    glBindTexture (GL_TEXTURE_2D, 0);
    glBindBuffer (GL_ARRAY_BUFFER, 0);
    SDL_GL_SwapWindow (window);
    std::swap (vbo, tbo);

    fps++;
    currentTick = SDL_GetTicks ();

    if (currentTick - lastTick > 1000)
    {
        //std::cout << fps << " fps" << std::endl;
        fps = 0;
        lastTick = currentTick;
    }
    lastFrameTick = currentTick;
}

SDL_Window* window;
GLuint feedbackProg;
GLuint particleProg;
GLfloat* data ;

void main_loop(){
  #ifndef WEB_BUILD
  while(true)
  #endif
  {
        SDL_Event event;
        while (SDL_PollEvent (&event)) {
            switch (event.type) {
                case SDL_KEYUP:
                    if (event.key.keysym.sym == SDLK_ESCAPE) {
                        return;
                    }
                    if (event.key.keysym.sym == SDLK_SPACE) {
                      
                    }
                break;

                case SDL_MOUSEMOTION:
                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_LEFT) || 
                        SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_RIGHT)) {
                        mouseX = (GLfloat) event.motion.x;
                        mouseY = (GLfloat) event.motion.y;
                    }
                break;

                case SDL_MOUSEBUTTONDOWN:
                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_LEFT)) {
                        mouseX = (GLfloat) event.button.x;
                        mouseY = (GLfloat) event.button.y;
                    }

                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_RIGHT)) {
                          
                    }

                    if (SDL_GetMouseState (NULL, NULL) &
                        SDL_BUTTON (SDL_BUTTON_MIDDLE)) {
                          
                    }
                break;

                case SDL_WINDOWEVENT:
                    if (event.window.event == SDL_WINDOWEVENT_CLOSE) {
                        return;
                    } else if ((event.window.event == SDL_WINDOWEVENT_RESIZED)||(event.window.event == SDL_WINDOWEVENT_SIZE_CHANGED)) {
                        resizeGL (window,
                                  event.window.data1,
                                  event.window.data2);
                    }
                break;

                default:
                break;
            }
        }

        int width = 0;
        int height = 0;
        SDL_GetWindowSize (window, &width, &height);
        if(((int)last_resX!=width)||((int)last_resY!=height)){
          last_resX = width;
          last_resY = height;
          resizeGL (window,width,height);
        };
        updateFeedbackBuffer (feedbackProg, width, height);
        drawGL (window, particleProg, vbo, width, height);
    }
}

void hidecanvas() {
    emscripten_run_script("document.getElementById('spinner').hidden = false;document.getElementById('imloader').style.display=\"\"");
}

void init_shader_js() {
    emscripten_run_script("init_vshader()");
}

void init_uniforms() {
    emscripten_run_script("init_custom_uniforms()");
}

void displaycanvas() {
    emscripten_run_script("document.getElementById('spinner').hidden = true;document.getElementById('imloader').style.display=\"none\"");
}

extern "C" {

int set_render_mode(int mode){
  if(mode==0) draw_type=GL_TRIANGLES;
  if(mode==1) draw_type=GL_LINES;
  if(mode==2) draw_type=GL_POINTS;
  return 0;
}

int set_number_particles(int num){
  
  NUM_PARTICLES = num;
  MAX_ELEMENTS = (NUM_PARTICLES * NUM_FLOATS_PER_VERTEX);
  
  GLuint vbot = vbo;
  GLuint tbot = tbo;
  
  std::free (data);
  data = (GLfloat*) std::calloc (MAX_ELEMENTS, sizeof (GLfloat));

  for (int i = 0; i < MAX_ELEMENTS; i += NUM_FLOATS_PER_VERTEX) {
      data[i]   = 0.0;
      data[i+1] = 0.0;
      data[i+2] = 0.0;
      data[i+3] = 0.0;
      data[i+4] = 0.0;
      data[i+5] = 0.0;
      data[i+6] = 0.0;
      data[i+7] = 0.0;
  }

	vbo = createVBO (MAX_ELEMENTS * sizeof (GLfloat), data, GL_DYNAMIC_COPY);
	tbo = createVBO (MAX_ELEMENTS * sizeof (GLfloat), nullptr, GL_DYNAMIC_COPY);
  
  glDeleteBuffers (1, &vbot);
  glDeleteBuffers (1, &tbot);
  return 0;
}

int set_custom_uniform(int id, float a, float b, float c, float d){
  if(id==0){custom_uniform1[0]=a;custom_uniform1[1]=b;custom_uniform1[2]=c;custom_uniform1[3]=d;}
  if(id==1){custom_uniform2[0]=a;custom_uniform2[1]=b;custom_uniform2[2]=c;custom_uniform2[3]=d;}
  if(id==2){custom_uniform3[0]=a;custom_uniform3[1]=b;custom_uniform3[2]=c;custom_uniform3[3]=d;}
  return 0;
}

int set_custom_uniform_feedback(int id, float a, float b, float c, float d){
  if(id==0){custom_uniform_feedback1[0]=a;custom_uniform_feedback1[1]=b;custom_uniform_feedback1[2]=c;custom_uniform_feedback1[3]=d;}
  if(id==1){custom_uniform_feedback2[0]=a;custom_uniform_feedback2[1]=b;custom_uniform_feedback2[2]=c;custom_uniform_feedback2[3]=d;}
  if(id==2){custom_uniform_feedback3[0]=a;custom_uniform_feedback3[1]=b;custom_uniform_feedback3[2]=c;custom_uniform_feedback3[3]=d;}
  return 0;
}

int init_shader(char *str,int len, char *str2,int len2) {
    if(str==NULL) return 1;
    if(str2==NULL) return 1;
    if(vShaderSrc_from_js!=NULL)free(vShaderSrc_from_js);
    if(feedback_shader_from_js!=NULL)free(feedback_shader_from_js);
    vShaderSrc_from_js = (char*) malloc(len*sizeof(char));
    feedback_shader_from_js = (char*) malloc(len2*sizeof(char));
    strcpy(vShaderSrc_from_js, str);
    strcpy(feedback_shader_from_js, str2);
    // free(vShaderSrc_from_js); // somewhere if need reload
    return 0;
}

}

int main(int argc, char* argv[]) {
    // initialize SDL
    hidecanvas();
    int result = 0;
    result = SDL_Init (SDL_INIT_VIDEO);
    if (result != 0) {
        std::cout << "SDL_Init() failed: " << SDL_GetError () << std::endl;
        return 1;
    }

    // initialize SDL_image
    int flags = IMG_INIT_PNG | IMG_INIT_JPG;
    result = IMG_Init (flags);
    if ((result & flags) != flags) {
        std::cout << "IMG_Init() failed: " << IMG_GetError () << std::endl;
        return 2;
    }

    SDL_GL_SetAttribute (SDL_GL_RED_SIZE, 8);
    SDL_GL_SetAttribute (SDL_GL_GREEN_SIZE, 8);
    SDL_GL_SetAttribute (SDL_GL_BLUE_SIZE, 8);
    SDL_GL_SetAttribute (SDL_GL_DEPTH_SIZE, 24);
    SDL_GL_SetAttribute (SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute (SDL_GL_MULTISAMPLESAMPLES, 4);
    SDL_GL_SetAttribute (SDL_GL_MULTISAMPLEBUFFERS, 1);
    SDL_GL_SetAttribute (SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute (SDL_GL_CONTEXT_MINOR_VERSION, 0);
    /*SDL_GL_SetAttribute (SDL_GL_CONTEXT_PROFILE_MASK,
                         SDL_GL_CONTEXT_PROFILE_COMPATIBILITY);*/

    // setup window
    window = NULL;
    SDL_ClearError ();
    window = SDL_CreateWindow (WIN_TITLE,
                               SDL_WINDOWPOS_UNDEFINED,
                               SDL_WINDOWPOS_UNDEFINED,
                               WIN_WIDTH,
                               WIN_HEIGHT,
                               SDL_WINDOW_OPENGL |
                               SDL_WINDOW_RESIZABLE);
    if (!window) {
        std::cout << "CreateWindow() failed: " << SDL_GetError () << std::endl;
        IMG_Quit ();
        SDL_Quit ();
        return 3;
    }

    SDL_ClearError ();

    // setup OpenGL-context
    SDL_GLContext context;
    SDL_ClearError ();
    context = SDL_GL_CreateContext (window);
    if (!context) {
        std::cout << "CreateContext() failed: " << SDL_GetError () << std::endl;
        SDL_DestroyWindow (window);
        IMG_Quit ();
        SDL_Quit ();
        return 4;
    }

    int success = glewInit();
    if (success != GLEW_OK) {
        std::cout << "OpenGL initialization failed" << std::endl;
    }

    // create vertex-only shader-program
    init_shader_js();
    
    if(feedback_shader_from_js!=NULL)
      feedbackProg = createShaderProgram (feedback_shader_from_js, feedback_shader_f, false);
    else {
      std::cout << "Error: shader2 emty." << std::endl;
      return 1;
    }
    
    glBindAttribLocation (feedbackProg, feedback_data_1, "feedback_data_1");
    glBindAttribLocation (feedbackProg, feedback_data_2, "feedback_data_2");

    const GLchar* feedbackVaryings[] = {"feedback_data_1_out", "feedback_data_2_out"};
    glTransformFeedbackVaryings (feedbackProg,
                                 2,
                                 feedbackVaryings,
                                 GL_INTERLEAVED_ATTRIBS);

    linkShaderProgram (feedbackProg);
    glUseProgram (feedbackProg);

    // Create input VBO, vertex format and upload inital data
    data = (GLfloat*) std::calloc (MAX_ELEMENTS, sizeof (GLfloat));

    for (int i = 0; i < MAX_ELEMENTS; i += NUM_FLOATS_PER_VERTEX) {
        data[i]   = 0.0;
        data[i+1] = 0.0;
        data[i+2] = 0.0;
        data[i+3] = 0.0;
        data[i+4] = 0.0;
        data[i+5] = 0.0;
        data[i+6] = 0.0;
        data[i+7] = 0.0;
    }
    
    init_uniforms();

    vbo = createVBO (MAX_ELEMENTS * sizeof (GLfloat), data, GL_DYNAMIC_COPY);
    tbo = createVBO (MAX_ELEMENTS * sizeof (GLfloat), nullptr, GL_DYNAMIC_COPY);

    glUseProgram (feedbackProg);
    glEnableVertexAttribArray (feedback_data_1);
    glEnableVertexAttribArray (feedback_data_2);

    uniform_feedback1 = glGetUniformLocation (feedbackProg, "uniform_feedback1");
    uniform_feedback2 = glGetUniformLocation (feedbackProg, "uniform_feedback2");
    uniform_feedback3 = glGetUniformLocation (feedbackProg, "uniform_feedback3");
    uniform_feedback_time = glGetUniformLocation (feedbackProg, "time");
    uniform_feedback_mouse = glGetUniformLocation (feedbackProg, "mouse");
    uniform_feedback_resolution = glGetUniformLocation (feedbackProg, "resolution");
    glUniform1f (uniform_feedback_time, 0.0);
    glUniform2f (uniform_feedback_mouse, mouseX/((float)WIN_WIDTH), mouseY/((float)WIN_HEIGHT));
    glUniform2f (uniform_feedback_resolution, WIN_WIDTH, WIN_HEIGHT);
    glUniform4f (uniform_feedback1, custom_uniform_feedback1[0],custom_uniform_feedback1[1],custom_uniform_feedback1[2],custom_uniform_feedback1[3]);
    glUniform4f (uniform_feedback2, custom_uniform_feedback2[0],custom_uniform_feedback2[1],custom_uniform_feedback2[2],custom_uniform_feedback2[3]);
    glUniform4f (uniform_feedback3, custom_uniform_feedback3[0],custom_uniform_feedback3[1],custom_uniform_feedback3[2],custom_uniform_feedback3[3]);
    
    if(vShaderSrc_from_js!=NULL)
      particleProg = createShaderProgram (vShaderSrc_from_js, fShaderSrc, true);
    else {
      std::cout << "Error: shader emty." << std::endl;
      return 1;
    }
    
    glUseProgram (particleProg);
    glBindAttribLocation (particleProg, feedback_data_1, "feedback_data_1");
    glBindAttribLocation (particleProg, feedback_data_2, "feedback_data_2");
    uniform_time = glGetUniformLocation (particleProg, "time");
    uniform_custom1 = glGetUniformLocation (particleProg, "uniform_custom1");
    uniform_custom2 = glGetUniformLocation (particleProg, "uniform_custom2");
    uniform_custom3 = glGetUniformLocation (particleProg, "uniform_custom3");
    uniform_mouse = glGetUniformLocation (particleProg, "mouse");
    uniform_resolution = glGetUniformLocation (particleProg, "resolution");
    glUniform1f (uniform_time, 0.0);
    glUniform4f (uniform_custom1, custom_uniform1[0],  custom_uniform1[1], custom_uniform1[2], custom_uniform1[3]);
    glUniform4f (uniform_custom2, custom_uniform2[0],  custom_uniform2[1], custom_uniform2[2], custom_uniform2[3]);
    glUniform4f (uniform_custom3, custom_uniform3[0],  custom_uniform3[1], custom_uniform3[2], custom_uniform3[3]);
    glUniform2f (uniform_mouse, mouseX/((float)WIN_WIDTH), mouseY/((float)WIN_HEIGHT));
    glUniform2f (uniform_resolution, WIN_WIDTH, WIN_HEIGHT);

    initGL (window, WIN_WIDTH, WIN_HEIGHT);
    displaycanvas();
    // event-loop
    #ifdef WEB_BUILD
    emscripten_set_main_loop(main_loop, 0, 1);
    #else
    main_loop();
    #endif

    // clean up
    glDeleteBuffers (1, &vbo);
    glDeleteBuffers (1, &tbo);
    glDeleteProgram (feedbackProg);
    glDeleteProgram (particleProg);
    SDL_GL_DeleteContext (context);
    SDL_DestroyWindow (window);
    IMG_Quit ();
    SDL_Quit ();
    std::free (data);

    return 0;
}
