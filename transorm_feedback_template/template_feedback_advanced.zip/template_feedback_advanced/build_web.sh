#!/bin/sh

source /home/danil/2018_projects/wasm_sdk_bin/em_upd3/emsdk/emsdk_env.sh

em++ utils.cpp transform-feedback.cpp -DGL_GLEXT_PROTOTYPES -DRELEASE -DWEB_BUILD --std=c++11 -O2 -lGL -lGLEW -lm -lSDL2 -s USE_SDL=2 -s ALLOW_MEMORY_GROWTH=1 -s FULL_ES3=1 -s USE_WEBGL2=2 -s WASM=1 -o build/feedback_advanced.html --shell-file shell_minimal.html -s EXPORTED_FUNCTIONS='["_main","_set_render_mode","_set_number_particles","_set_custom_uniform","_set_custom_uniform_feedback","_init_shader"]' -s EXPORTED_RUNTIME_METHODS='["ccall","cwrap","allocate","intArrayFromString"]'
