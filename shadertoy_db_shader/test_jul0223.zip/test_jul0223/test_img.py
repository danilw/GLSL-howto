#!/usr/bin/env python3

# usage:
# python3 test_img.py

import numpy as np
import os, sys
import cv2

cube_num_elems_use_sz = 169

def test():
  
  new_db = []
  
  img = cv2.imread("db_scr.png") 
  img_h,img_w,_ = img.shape
  image_data = np.asarray(img)
  ta = []
  for j in range(cube_num_elems_use_sz):
    for i in range(cube_num_elems_use_sz*2):
      if(img[img_h-j-1,i][0]==0):
        continue
      ta.append(chr(img[img_h-j-1,i][2])+chr(img[img_h-j-1,i][1])+chr(img[img_h-j-1,i][0]))
      if ((i+1)%2)==0:
        new_db.append(ta[0]+ta[1])
        ta = []
  
  test_db(new_db)
  
  print("saving Sorted new_db to file new_db.txt")
  with open('new_db.txt', 'w') as f:
    for a in new_db:
      f.write(a)
      f.write('\n')
  print("saving Sorted left and right side to files - to compare to zip/7z compression")
  with open('left.txt', 'w') as f:
    for a in new_db:
      f.write(a[0:3])
      f.write('\n')
  with open('right.txt', 'w') as f:
    for a in new_db:
      f.write(a[3:6])
      f.write('\n')


def test_db(new_db):
  old_db=[]
  with open("data/original_db.txt") as f:
    while True:
        line = f.readline()
        if not line:
            break
        old_db.append(line[0:6])
  
  print("TEST")
  print("new_db len " + str(len(new_db)))
  print("old_db len " + str(len(old_db)))
  new_na = np.array(new_db)
  old_na = np.array(old_db)
  for a in new_db:
    if len(np.where(old_na==a)[0])!=1:
      print("not found new_db " + a)
      exit(1)
  for a in old_db:
    if len(np.where(new_na==a)[0])!=1:
      print("not found old_db " + a)
      exit(1)
  
  print("all true\n")
  
  


def main():
  test()


if __name__ == '__main__': 
    main()












